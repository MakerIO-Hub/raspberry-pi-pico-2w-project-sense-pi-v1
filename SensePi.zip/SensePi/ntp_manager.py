import ntptime
import time
import machine

# Türkiye saat dilimi (UTC+3)
UTC_OFFSET = 3 * 3600

def sync_time():
    """İnternetten saati al ve Pico'nun iç saatini güncelle."""
    print("Saat senkronize ediliyor (NTP)...")
    try:
        ntptime.settime()  # UTC saati ayarlar
        print("UTC Saati alındı.")
        return True
    except Exception as e:
        print("NTP Hatası:", e)
        return False

def get_local_time():
    """Türkiye yerel saatini (yıl, ay, gün, saat, dak, san, haftagünü, yıldıngünü) döner."""
    # ntptime.settime() sonrası time.time() UTC döner.
    # Üzerine offset ekleyip yerel zamanı buluyoruz.
    local_seconds = time.time() + UTC_OFFSET
    return time.localtime(local_seconds)

def format_time():
    """Saati 'SS:DD:SS' formatında döner."""
    t = get_local_time()
    return "{:02d}:{:02d}:{:02d}".format(t[3], t[4], t[5])

def format_date():
    """Tarihi 'GG.AA.YYYY' formatında döner."""
    t = get_local_time()
    return "{:02d}.{:02d}.{:04d}".format(t[2], t[1], t[0])
