from machine import Pin
import time

class KY040:
    def __init__(self, clk_pin, dt_pin, sw_pin):
        self.clk = Pin(clk_pin, Pin.IN, Pin.PULL_UP)
        self.dt = Pin(dt_pin, Pin.IN, Pin.PULL_UP)
        self.sw = Pin(sw_pin, Pin.IN, Pin.PULL_UP)
        
        self.value = 0
        self.raw_value = 0  # Ham encoder degeri
        self.last_status = (self.clk.value() << 1) | self.dt.value()
        
        # Acceleration (ivmelenme) için
        self.last_update_time = time.ticks_ms()
        
        # IRQ handlers
        self.clk.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=self._update)
        self.dt.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=self._update)
        
        # Debounce
        self.last_press_time = 0
        self.button_pressed = False
        
        # SW IRQ
        self.sw.irq(trigger=Pin.IRQ_FALLING, handler=self._button_irq)
        
    def _update(self, pin):
        # Quadrature decoder
        new_status = (self.clk.value() << 1) | self.dt.value()
        if new_status == self.last_status:
            return
        
        # Zaman farkını hesapla (acceleration için)
        current_time = time.ticks_ms()
        time_diff = time.ticks_diff(current_time, self.last_update_time)
        self.last_update_time = current_time
        
        # State transitions ile yön belirle
        direction = 0
        if self.last_status == 0b11:
            if new_status == 0b01:
                direction = 1
            elif new_status == 0b10:
                direction = -1
        elif self.last_status == 0b00:
            if new_status == 0b10:
                direction = 1
            elif new_status == 0b01:
                direction = -1
        
        # ACCELERATION: Hıza göre adım çarpanı
        if direction != 0:
            if time_diff < 20:  # Çok hızlı (< 20ms)
                multiplier = 3  # 3x hızlı
            elif time_diff < 50:  # Hızlı (< 50ms)
                multiplier = 2  # 2x hızlı
            else:  # Normal/yavaş
                multiplier = 1  # 1x normal
            
            self.raw_value += direction * multiplier
                
        self.last_status = new_status
        
        # Direkt kullanici degerine ata
        self.value = self.raw_value
        
    def _button_irq(self, pin):
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, self.last_press_time) > 300:
            self.last_press_time = current_time
            self.button_pressed = True

    def get_value(self):
        return self.value
        
    def is_pressed(self):
        if self.button_pressed:
            self.button_pressed = False
            return True
        return False
