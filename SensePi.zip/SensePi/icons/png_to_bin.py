from PIL import Image
import struct
import os

# DOSYA YOLLARI
KLASOR = r"C:\Users\hteki\ikonu"
GIRIS_DOSYA = os.path.join(KLASOR, "settings.png")  # 50x50 piksel olmalı
CIKIS_DOSYA = os.path.join(KLASOR, "settings.bin")

# DOSYA VAR MI KONTROLÜ
if not os.path.exists(GIRIS_DOSYA):
    print("HATA: settings.png bulunamadı!")
    print("Aranan yol:", GIRIS_DOSYA)
    exit()

# PNG DOSYASINI AÇ (RGBA - Alpha dahil)
img = Image.open(GIRIS_DOSYA).convert("RGBA")
genislik, yukseklik = img.size
piksel = img.load()

print(f"📐 İkon Boyutu: {genislik} x {yukseklik}")

# Arka plan rengi (turuncu 0xdd22'nin RGB karşılığı)
ARKAPLAN_R = 216
ARKAPLAN_G = 164  # DÜZELTİLDİ: 208 → 164 (doğru değer)
ARKAPLAN_B = 16

print(f"🎨 Arka Plan Rengi (Turuncu): RGB({ARKAPLAN_R}, {ARKAPLAN_G}, {ARKAPLAN_B})")

# BIN DOSYASINI OLUŞTUR
debug_count = 0
with open(CIKIS_DOSYA, "wb") as f:
    for y in range(yukseklik):
        for x in range(genislik):
            r, g, b, a = piksel[x, y]
            original_r, original_g, original_b, original_a = r, g, b, a
            
            # Eğer piksel şeffafsa, arka plan rengini kullan
            if a < 128:
                r, g, b = ARKAPLAN_R, ARKAPLAN_G, ARKAPLAN_B
                pixel_type = "ŞEFFAF→Turuncu"
            # YEŞIL RENKLERİ TESPIT ET (Photoshop arka planı yeşilse)
            elif g > r + 30 and g > b + 30:  # Yeşil baskın
                r, g, b = ARKAPLAN_R, ARKAPLAN_G, ARKAPLAN_B
                pixel_type = "YEŞİL→Turuncu"
            # AÇık RENKLER (Beyaz, açık gri vb.) → Turuncu arka plan
            elif r > 200 and g > 200 and b > 200:
                r, g, b = ARKAPLAN_R, ARKAPLAN_G, ARKAPLAN_B
                pixel_type = "AÇIK RENK→Turuncu"
            else:
                # Piksel opak ve renkli (siyah, koyu renkler)
                # Renkleri tersine çevir (beyaz→siyah, siyah→beyaz)
                r = 255 - r
                g = 255 - g
                b = 255 - b
                pixel_type = "RENKLERİ TERSİNE ÇEVRİLDİ"

            # İlk 10 pikseli debug için yazdır
            if debug_count < 10:
                print(f"Piksel [{x},{y}]: RGBA({original_r},{original_g},{original_b},{original_a}) → RGB({r},{g},{b}) [{pixel_type}]")
                debug_count += 1

            # RGB888 → RGB565
            r5 = (r >> 3) & 0x1F
            g6 = (g >> 2) & 0x3F
            b5 = (b >> 3) & 0x1F

            # RGB565 format
            rgb565 = (r5 << 11) | (g6 << 5) | b5

            # Little Endian
            f.write(struct.pack("<H", rgb565))

print("\n✅ DÖNÜŞTÜRME TAMAMLANDI")
print("Oluşturulan dosya:", CIKIS_DOSYA)
print("İkon boyutu:", genislik, "x", yukseklik)
print("\n📝 NOTLAR:")
print("- Şeffaf pikseller → Turuncu arka plan (0xdd22)")
print("- Renkler tersine çevrildi (beyaz→siyah, siyah→beyaz)")
