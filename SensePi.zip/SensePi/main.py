from machine import Pin, SPI, I2C
import lcd_2inch8
import time
import dashboard
import ky040
import touch_xpt2046
import gc  # Added for memory management
import framebuf
import config

# Import new modular drivers
from drivers.wifi_manager_v3 import WiFiManager
from drivers.rtc_driver import RTCDriver
from drivers.ntp_manager import NTPManager
from drivers.timezone_detector import TimezoneDetector
from drivers.holiday_manager import HolidayManager
from modules.clock import ClockModule
from modules.date import DateModule
from modules.alarm import AlarmModule
from modules.weather import WeatherModule
from modules.currency import CurrencyModule
from drivers.buzzer import BuzzerDriver
from drivers.alarm_manager import AlarmManager
from drivers.tcmb_api import TCMBDriver
from modules.sensors import SensorsModule
from modules.screensaver import Screensaver
from modules.settings import SettingsModule
from modules.torch import TorchModule


# LCD SPI Başlatma
spi = SPI(
    1,
    baudrate=10000000,  # 10 MHz (çalışan versiyon)
    sck=Pin(10),
    mosi=Pin(11),
    miso=Pin(12)
)

# LCD Nesnesi
lcd = lcd_2inch8.LCD_2inch8(
    spi,
    cs=Pin(9),
    dc=Pin(8),
    rst=Pin(15),
    bl=machine.PWM(Pin(13))
)

# 1. Aşama: Splash Screen (Logo & Credits)
lcd.fill(0xdd22) # Orange Background
try:
    logo_w, logo_h = 150, 50
    with open("icons/sensepilogo.bin", "rb") as f:
        logo_data = f.read()
    
    if len(logo_data) == logo_w * logo_h * 2:
        # Calculate Y positions for a centered group
        # Group: Logo (50) + Space (15) + V1.0 (8) + Space (8) + Credits (8) = 89px total height
        group_h = logo_h + 15 + 8 + 8 + 8
        start_y = (240 - group_h) // 2
        
        # Draw Logo
        logo_fb = framebuf.FrameBuffer(bytearray(logo_data), logo_w, logo_h, framebuf.RGB565)
        lcd.blit(logo_fb, (320 - logo_w) // 2, start_y)
        
        # Draw Version
        v_str = "Version 1.0"
        v_x = (320 - len(v_str) * 8) // 2
        lcd.text(v_str, v_x, start_y + logo_h + 15, 0xFFFF)
        
        # Draw Credits
        c_str = "Developed by H. Tekin"
        c_x = (320 - len(c_str) * 8) // 2
        lcd.text(c_str, c_x, start_y + logo_h + 15 + 8 + 8, 0xFFFF)
    else:
        lcd.text("SensePi", 120, 110, 0xFFFF)
    
    del logo_data
    gc.collect()
except Exception as e:
    print(f"Splash Logo Error: {e}")
    lcd.text("SensePi", 120, 110, 0xFFFF)

lcd.show()
time.sleep(3) # Show splash for 3 seconds
gc.collect()

# 2. Aşama: Wi-Fi Bağlantısı
lcd.fill(0xdd22)
lcd.text("SensePi Starting...", 68, 100, 0xFFFF)
lcd.text("Initializing WiFi...", 68, 116, 0x039F)
lcd.show()

# Initialize WiFi
wifi_mgr = WiFiManager(ssid=config.WIFI_SSID, password=config.WIFI_PASSWORD)
wifi_ok = wifi_mgr.connect()

# Initialize RTC (use internal Pico RTC for now)
# To use DS3231: rtc = RTCDriver(use_external=True, i2c=I2C(0, scl=Pin(1), sda=Pin(0)))
rtc = RTCDriver(use_external=False)

# Initialize NTP Manager
ntp_mgr = NTPManager(wifi_mgr)

# Initialize Timezone Detector
tz_detector = TimezoneDetector(wifi_mgr)

# Initialize Holiday Manager
holiday_mgr = HolidayManager(wifi_mgr)

# Initialize Alarm System
buzzer = BuzzerDriver(pin_num=14)
alarm_mgr = AlarmManager(rtc, buzzer)

# === INITIALIZE MODULES EARLY (for startup data fetch) ===

# Open-Meteo API Client
from drivers.open_meteo import OpenMeteoClient
open_meteo_client = OpenMeteoClient(wifi_mgr)
weather_module = WeatherModule(lcd, open_meteo_client, tz_detector)

# Currency Module (TCMB)
tcmb_driver = TCMBDriver(wifi_mgr)
currency_module = CurrencyModule(lcd, tcmb_driver)

# Quake API (Global monitoring)
from drivers.quake_driver_v2 import QuakeAPI
quake_api = QuakeAPI(wifi_mgr)

# Clock & Date Modules
clock_module = ClockModule(lcd, rtc, ntp_mgr, tz_detector)
date_module = DateModule(lcd, rtc, tz_detector, holiday_mgr)
alarm_module = AlarmModule(lcd, alarm_mgr)

# Quake Module
from modules.quake_v2 import QuakeModule
quake_module = QuakeModule(lcd, quake_api, buzzer=buzzer)

# Sensors Module
sensors_module = SensorsModule(lcd, buzzer=buzzer)

# Screensaver Module
screensaver = Screensaver(lcd, sensors_module, weather_module)

# Google Calendar Module
from drivers.google_calendar import GoogleCalendarDriver
from modules.calendar import CalendarModule
google_calendar_driver = GoogleCalendarDriver(wifi_mgr, config.GOOGLE_SCRIPT_URL)
calendar_module = CalendarModule(lcd, google_calendar_driver, tz_detector)

# Settings Module
settings_module = SettingsModule(lcd, wifi_mgr, buzzer, rtc)

# Torch Module
from modules.torch import TorchModule
torch_module = TorchModule(lcd, buzzer=buzzer)
gc.collect()

# Measure Module (HC-SR04)
from modules.measure import MeasureModule
measure_module = MeasureModule(lcd, buzzer=buzzer)
gc.collect()

# --- STARTUP DATA FETCH ---
last_weather_update = 0
last_currency_update = 0
last_calendar_update = 0

if wifi_ok:
    lcd.text("Syncing time...", 68, 132, 0x039F)
    lcd.show()
    ntp_mgr.sync_rtc(rtc, timezone_offset=config.DEFAULT_TIMEZONE_OFFSET*3600)
    
    # Pre-fetch Weather and Currency data so screensaver shows them immediately
    lcd.text("Syncing Weather...", 68, 164, 0x039F)
    lcd.show()
    try:
        weather_module.update()
        last_weather_update = time.ticks_ms()
    except: pass
    
    lcd.text("Syncing Currency...", 68, 180, 0x039F)
    lcd.show()
    try:
        currency_module.update()
        last_currency_update = time.ticks_ms()
    except: pass

lcd.text("Ready!", 68, 148, 0x07E0)
lcd.show()
time.sleep(1)


# === DASHBOARD SYSTEM ===

try:
    print("*** SENSEPI SYSTEM V2 STARTED ***")
    # Encoder Pinleri
    # CLK=GP0 (Pin 1), DT=GP1 (Pin 2), SW=GP2 (Pin 4)
    encoder = ky040.KY040(clk_pin=0, dt_pin=1, sw_pin=2)
    
    # Touch Controller
    touch = touch_xpt2046.Touch(spi, cs=Pin(16), irq=Pin(17))

    # Dashboard
    dash = dashboard.Dashboard(lcd)
    
    # View state
    current_view = "dashboard"  # "dashboard", "clock", "date", "alarm", "alarm_ringing", "currency", "screensaver"
    ringing_start_time = 0
    alert_start_time = 0
    
    # Hand Detection State
    hand_trigger_active = False
    last_hand_trigger = 0
    magic_target_view = "screensaver" # Default target for hand detection
    
    # Initial draw
    lcd.fill(0xdd22)
    dash.draw_grid()

    # State
    old_val = encoder.get_value()
    last_clock_update = 0
    last_date_update = 0
    # last_weather_update and last_currency_update are now initialized above
    last_calendar_update = 0
    last_interaction_time = time.ticks_ms()
    print("Sistem Hazir. Dashboard + Clock + Date + Alarm + Weather + Currency + Calendar kullanilabilir.")

    while True:
        # === DASHBOARD MODE ===
        if current_view == "dashboard":
            # --- ENCODER KONTROLU ---
            new_val = encoder.get_value()
            if new_val != old_val:
                direction = 1 if new_val > old_val else -1
                dash.move_selection(direction)
                old_val = new_val
                time.sleep_us(100)
                

            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                x, y = coords
                module_idx = dash.get_module_index_at(x, y)
                
                if module_idx is not None:
                    # Aynı modüle tekrar dokunulursa aç (double-tap)
                    if dash.selected_index == module_idx:
                        # Modül zaten seçili, şimdi açalım
                        selected_mod = dash.get_selected_module()
                        print(f"TOUCH OPENING MODULE: {selected_mod['name']}")
                        
                        # Click effect
                        lcd.rect(0, 0, 320, 240, 0xFFFF)
                        lcd.show()
                        time.sleep(0.05)
                        
                        # Open module
                        if selected_mod['name'] == "Clock":
                            try:
                                print("DEBUG: Touch ile Clock açılıyor...")
                                current_view = "clock"
                                print("DEBUG: clock_module.show() çağrılıyor...")
                                clock_module.show()
                                print("DEBUG: Clock açıldı!")
                                last_clock_update = time.ticks_ms()
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Clock açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Clock ERROR!", 10, 10, 0xFFFF)
                                err_str = str(e)
                                lcd.text(err_str[:40], 10, 30, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Alarm":
                            try:
                                print("DEBUG: Touch ile Alarm açılıyor...")
                                current_view = "alarm"
                                alarm_module.show()
                            except Exception as e:
                                import sys
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Alarm ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Date":
                            try:
                                print("DEBUG: Touch ile Date açılıyor...")
                                current_view = "date"
                                date_module.show()
                                print("DEBUG: Date açıldı!")
                                last_date_update = time.ticks_ms()
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Date açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Date ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Weather":
                            try:
                                print("DEBUG: Touch ile Weather açılıyor...")
                                current_view = "weather"
                                weather_module.show()
                                print("DEBUG: Weather açıldı!")
                                last_weather_update = time.ticks_ms()
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Weather açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Weather ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Currency":
                            try:
                                print("DEBUG: Touch ile Currency açılıyor...")
                                current_view = "currency"
                                currency_module.show() # Ilk acilista show() cagir, update() degil
                                print("DEBUG: Currency açıldı!")
                                last_currency_update = time.ticks_ms()
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Currency açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Currency ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Quake":
                            try:
                                print("DEBUG: Touch ile Quake açılıyor...")
                                current_view = "quake"
                                quake_module.show()
                                print("DEBUG: Quake açıldı!")
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Quake açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Quake ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Sensors":
                            try:
                                print("DEBUG: Touch ile Sensors açılıyor...")
                                current_view = "sensors"
                                sensors_module.show()
                                print("DEBUG: Sensors açıldı!")
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Sensors açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Sensors ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Calendar":
                            try:
                                print("DEBUG: Touch ile Calendar açılıyor...")
                                gc.collect() # Free memory before large allocation
                                current_view = "calendar"
                                calendar_module.show()
                                print("DEBUG: Calendar açıldı!")
                                last_calendar_update = time.ticks_ms()
                            except Exception as e:
                                import sys
                                print("HATA: Touch ile Calendar açılamadı!")
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Calendar ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        elif selected_mod['name'] == "Settings":
                            try:
                                print("DEBUG: Touch ile Settings açılıyor...")
                                current_view = "settings"
                                settings_module.show()
                                last_interaction_time = time.ticks_ms()
                            except Exception as e:
                                import sys
                                sys.print_exception(e)
                                lcd.fill(0xF800)
                                lcd.text("Settings ERROR!", 10, 10, 0xFFFF)
                                lcd.show()
                                time.sleep(2)
                                dash.draw_grid()
                        else:
                            # Diğer modüller henüz implement edilmedi
                            lcd.fill(0xF800)
                            lcd.text("Module Coming Soon!", 70, 110, 0xFFFF)
                            lcd.text(selected_mod['name'], 120, 126, 0xFFFF)
                            lcd.show()
                            time.sleep(1)
                            dash.draw_grid()
                        
                        # Touch debounce
                        time.sleep(0.3)
                    else:
                        # Farklı modül, sadece seç
                        dash.selected_index = module_idx
                        dash.draw_grid()
                        selected_mod = dash.get_selected_module()
                        print(f"TOUCH SELECT: {selected_mod['name']} (X={x}, Y={y})")

                
            # --- ENCODER BUTONU (Module açma) ---
            if encoder.is_pressed():
                selected_mod = dash.get_selected_module()
                print(f"OPENING MODULE: {selected_mod['name']}")
                
                # Click effect
                lcd.rect(0, 0, 320, 240, 0xFFFF)
                lcd.show()
                time.sleep(0.05)
                
                # Open module
                if selected_mod['name'] == "Clock":
                    try:
                        print("DEBUG: Clock açılıyor...")
                        current_view = "clock"
                        print("DEBUG: clock_module.show() çağrılıyor...")
                        clock_module.show()
                        print("DEBUG: Clock açıldı!")
                        last_clock_update = time.ticks_ms()
                    except Exception as e:
                        import sys
                        print("HATA: Clock açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Clock ERROR!", 10, 10, 0xFFFF)
                        err_str = str(e)
                        lcd.text(err_str[:40], 10, 30, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Alarm":
                    try:
                        print("DEBUG: Alarm açılıyor...")
                        current_view = "alarm"
                        alarm_module.show()
                    except Exception as e:
                        import sys
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Alarm ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Date":
                    try:
                        print("DEBUG: Date açılıyor...")
                        current_view = "date"
                        date_module.show()
                        last_date_update = time.ticks_ms()
                    except Exception as e:
                        import sys
                        print("HATA: Date açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Date ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Weather":
                    try:
                        print("DEBUG: Weather açılıyor...")
                        current_view = "weather"
                        weather_module.show()
                        last_weather_update = time.ticks_ms()
                    except Exception as e:
                        import sys
                        print("HATA: Weather açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Weather ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Currency":
                    try:
                        print("DEBUG: Currency açılıyor...")
                        current_view = "currency"
                        currency_module.show()
                        last_currency_update = time.ticks_ms()
                    except Exception as e:
                        import sys
                        print("HATA: Currency açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Currency ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Quake":
                    try:
                        print("DEBUG: Quake açılıyor...")
                        current_view = "quake"
                        quake_module.show()
                    except Exception as e:
                        import sys
                        print("HATA: Quake açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Quake ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                elif selected_mod['name'] == "Sensors":
                    try:
                        print("DEBUG: Sensors açılıyor...")
                        current_view = "sensors"
                        sensors_module.show()
                    except Exception as e:
                        import sys
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Sensors ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()

                elif selected_mod['name'] == "Calendar":
                    try:
                        print("DEBUG: Calendar açılıyor...")
                        gc.collect() # Free memory before large allocation
                        print(f"DEBUG: RAM Free before Calendar: {gc.mem_free()}")
                        current_view = "calendar"
                        calendar_module.show()
                        last_calendar_update = time.ticks_ms()
                    except Exception as e:
                        import sys
                        print("HATA: Calendar açılamadı!")
                        sys.print_exception(e)
                        lcd.fill(0xF800)
                        lcd.text("Calendar ERROR!", 10, 10, 0xFFFF)
                        lcd.show()
                        time.sleep(2)
                        dash.draw_grid()
                
                elif selected_mod['name'] == "Settings":
                        try:
                            print("DEBUG: Settings açılıyor...")
                            current_view = "settings"
                            settings_module.show()
                            last_interaction_time = time.ticks_ms()
                        except Exception as e:
                            import sys
                            sys.print_exception(e)
                            lcd.fill(0xF800)
                            lcd.text("Settings ERROR!", 10, 10, 0xFFFF)
                            lcd.show()
                            time.sleep(2)
                            dash.draw_grid()
                        
                else:
                    # Catch-all for unknown modules
                    print(f"WARNING: No handler for module '{selected_mod['name']}'")
                    lcd.fill(0xF800)
                    lcd.text("UNKNOWN MODULE", 10, 100, 0xFFFF)
                    lcd.text(selected_mod['name'], 10, 120, 0xFFFF)
                    lcd.show()
                    time.sleep(2)
                    dash.draw_grid()


                
                # Buton debounce - butonu bırakmasını bekle
                time.sleep(0.3)
                while encoder.is_pressed():
                    time.sleep(0.01)
                    
        # === CLOCK MODE ===
        elif current_view == "clock":
            # Update clock every second
            if time.ticks_diff(time.ticks_ms(), last_clock_update) > 1000:
                clock_module.update()
                last_clock_update = time.ticks_ms()
                
            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                clock_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = clock_module.handle_encoder_button()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = clock_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
        # === DATE MODE ===
        elif current_view == "date":
            # Update date every hour (3600000 ms)
            if time.ticks_diff(time.ticks_ms(), last_date_update) > 3600000:
                date_module.update()
                last_date_update = time.ticks_ms()
                
            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                date_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = date_module.handle_encoder_button()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = date_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
        # === WEATHER MODE ===
        elif current_view == "weather":
            # Update weather every 30 minutes (1800000 ms)
            if time.ticks_diff(time.ticks_ms(), last_weather_update) > 1800000:
                weather_module.update()
                last_weather_update = time.ticks_ms()
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = weather_module.handle_encoder_button()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = weather_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
        # === CURRENCY MODE ===
        elif current_view == "currency":
            # Update every 60 minutes (3600000 ms) automatically
            if time.ticks_diff(time.ticks_ms(), last_currency_update) > 3600000:
                currency_module.update()
                last_currency_update = time.ticks_ms()

            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                currency_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = currency_module.handle_encoder_button()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = currency_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()

        # === QUAKE MODE ===
        elif current_view == "quake":
             # Update every 5 minutes (300000 ms)
             if time.ticks_diff(time.ticks_ms(), quake_module.last_update) > 300000:
                 if quake_module.update(): # Returns True if alert triggered
                     current_view = "quake_alert"
                     alert_start_time = time.ticks_ms()
                     print("QUAKE ALERT TRIGGERED (In-Module)")
                 
             # --- ENCODER ROTATION (Scroll) ---
             new_val = encoder.get_value()
             if new_val != old_val:
                 last_interaction_time = time.ticks_ms()
                 diff = 1 if new_val > old_val else -1
                 quake_module.handle_encoder(diff)
                 old_val = new_val
                 
             # --- ENCODER BUTTON (Refresh/Back) ---
             if encoder.is_pressed():
                 last_interaction_time = time.ticks_ms()
                 # Geri donus icin basit bir mantik ekleyelim veya modul icinde handle edelim
                 # Simdilik modulun handle_button'u bir sey dondermiyor, dashboard'a donelim
                 current_view = "dashboard"
                 dash.draw_grid()
                 time.sleep(0.5)
                 
             # --- TOUCH KONTROLU ---
             lcd.cs(1)
             time.sleep_us(50)
             
             coords = touch.get_touch()
             if coords:
                 last_interaction_time = time.ticks_ms()
                 x, y = coords
                 result = quake_module.handle_touch(x, y)
                 if result == "dashboard":
                     current_view = "dashboard"
                     dash.draw_grid()
                    
        # === SENSORS MODE ===
        elif current_view == "sensors":
            # Sensors update is handled globally at the bottom of the loop
            
            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                sensors_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                print("EXPERT DEBUG: Encoder Pressed in Sensors Mode")
                result = sensors_module.handle_encoder_button()
                print(f"EXPERT DEBUG: Sensors Module returned -> {result}")
                
                if result == "dashboard":
                    sensors_module.hide()
                    current_view = "dashboard"
                    dash.draw_grid()
                elif result == "torch":
                    sensors_module.hide()
                    current_view = "torch"
                    torch_module.draw()
                elif result == "measure":
                    print("DEBUG: Measure Selected via Encoder")
                    sensors_module.hide()
                    import gc
                    gc.collect()
                    current_view = "measure"
                    # Wait for button release
                    while encoder.is_pressed():
                        time.sleep(0.01)
                    time.sleep(0.1)
                    measure_module.show()
                else:
                    time.sleep(0.3)
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = sensors_module.handle_touch(x, y)
                print(f"EXPERT DEBUG: Sensors Touch at ({x},{y}), result -> {result}")
                
                if result == "dashboard":
                    sensors_module.hide()
                    current_view = "dashboard"
                elif result == "torch":
                    sensors_module.hide()
                    current_view = "torch"
                    torch_module.draw()
                elif result == "measure":
                    print("DEBUG: Measure Selected via Touch")
                    sensors_module.hide()
                    import gc
                    gc.collect()
                    current_view = "measure"
                    # Wait for user to release finger to avoid "instant back"
                    while touch.get_touch():
                        time.sleep(0.01)
                    time.sleep(0.1) 
                    measure_module.show()
                    print("DEBUG: Measure Module Loaded & Finger Released")

        # === TORCH MODE ===
        elif current_view == "torch":
            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                torch_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = torch_module.handle_encoder_button()
                if result == "sensors":
                    current_view = "sensors"
                    sensors_module.show()
                time.sleep(0.3)
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = torch_module.handle_touch(x, y)
                if result == "sensors":
                    current_view = "sensors"
                    sensors_module.show()
                time.sleep(0.3)
                
                if result == "sensors":
                    current_view = "sensors"
                    sensors_module.show() # Return to grid
                time.sleep(0.3)
                
        # === MEASURE MODE ===
        elif current_view == "measure":
            if time.ticks_diff(time.ticks_ms(), last_interaction_time) % 5000 < 100:
                print("DEBUG: Main Loop is in MEASURE view")
            measure_module.update()
            
            # Encoder Rotate (Change Mode)
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                measure_module.handle_encoder(diff)
                old_val = new_val
            
            # Encoder Button
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = measure_module.handle_encoder_button()
                if result == "dashboard": # or sensors
                    current_view = "sensors"
                    sensors_module.show()
                time.sleep(0.3)
                
            # Touch
            lcd.cs(1)
            time.sleep_us(50)
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = measure_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "sensors"
                    sensors_module.show()
                
        # === SCREENSAVER MODE ===
        elif current_view == "screensaver":
             # Update time/temp periodically
             # Update every second for analog clock second hand
             if time.ticks_diff(time.ticks_ms(), last_clock_update) > 1000:
                 sensors_module.update() # Get fresh temp from DHT11
                 screensaver.draw()
                 last_clock_update = time.ticks_ms()
                 
             # Update Weather every 15 minutes
             if time.ticks_diff(time.ticks_ms(), last_weather_update) > 900000: # 15 min
                 print("Screensaver: Updating Weather...")
                 weather_module.update()
                 last_weather_update = time.ticks_ms()
             
             # Any encoder activity returns to dashboard
             if encoder.get_value() != old_val or encoder.is_pressed():
                 current_view = "dashboard"
                 dash.draw_grid()
                 old_val = encoder.get_value()
                 time.sleep(0.3)

             # Note: Hand detection is DISABLED here per user request ("sensor calısmasın")
             # Any touch also returns to dashboard
             coords = touch.get_touch()
             if coords:
                 current_view = "dashboard"
                 dash.draw_grid()
                 time.sleep(0.3)
        elif current_view == "alarm":
            # --- ENCODER KONTROLU (Rotation) ---
            new_val = encoder.get_value()
            if new_val != old_val:
                last_interaction_time = time.ticks_ms()
                diff = 1 if new_val > old_val else -1
                alarm_module.handle_encoder(diff)
                old_val = new_val
                
            # --- ENCODER BUTONU (Action) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                try:
                    print("DEBUG: Calling alarm_module.handle_button()")
                    # Alarm modülündeki aksiyonu çalıştır
                    result = alarm_module.handle_button()
                    print(f"DEBUG: Result = {result}")
                    # Eğer modül "dashboard" dönerse çıkış yap
                    if result == "dashboard":
                        current_view = "dashboard"
                        dash.draw_grid()
                    
                    # Debounce: Butonun bırakılmasını bekle
                    time.sleep(0.05) # Reduced latency
                    while encoder.is_pressed():
                        time.sleep(0.01)
                except Exception as e:
                    import sys
                    sys.print_exception(e)
                    lcd.fill(0xF800)
                    lcd.text("BTN ERROR", 10, 10, 0xFFFF)
                    lcd.text(str(e), 10, 30, 0xFFFF)
                    lcd.show()
                    time.sleep(2)
                    alarm_module.draw()

            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = alarm_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                
        # === CALENDAR MODE ===
        elif current_view == "calendar":
            # Update every 15 minutes (900000 ms)
            if time.ticks_diff(time.ticks_ms(), last_calendar_update) > 900000:
                calendar_module.update()
                last_calendar_update = time.ticks_ms()
                
            # --- ENCODER BUTONU (Geri) ---
            if encoder.is_pressed():
                last_interaction_time = time.ticks_ms()
                result = calendar_module.handle_encoder_button()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            
            coords = touch.get_touch()
            if coords:
                last_interaction_time = time.ticks_ms()
                x, y = coords
                result = calendar_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()

        # === SETTINGS MODE ===
        elif current_view == "settings":
            # --- ENCODER KONTROLU ---
            new_val = encoder.get_value()
            if new_val != old_val:
                diff = 1 if new_val > old_val else -1
                settings_module.handle_encoder(diff)
                old_val = new_val
                last_interaction_time = time.ticks_ms()
                
            # --- ENCODER BUTONU ---
            if encoder.is_pressed():
                result = settings_module.handle_button()
                last_interaction_time = time.ticks_ms()
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                time.sleep(0.3)
                    
            # --- TOUCH KONTROLU ---
            lcd.cs(1)
            time.sleep_us(50)
            coords = touch.get_touch()
            if coords:
                x, y = coords
                last_interaction_time = time.ticks_ms()
                result = settings_module.handle_touch(x, y)
                if result == "dashboard":
                    current_view = "dashboard"
                    dash.draw_grid()
                time.sleep(0.3)

        # === QUAKE ALERT MODE ===
        elif current_view == "quake_alert":
            # Play sound pattern (same as alarm)
            buzzer.play_alarm_step(1)
            
            # Quake Info
            event = quake_module.latest_alert_event
            country, city = quake_module.parse_location(event.location)
            
            # Draw blinking background (Orange/White)
            now_ms = time.ticks_ms()
            if ((now_ms - alert_start_time) // 500) % 2 == 0:
                lcd.fill(0xFD20) # Orange
                text_color = 0xFFFF # White
            else:
                lcd.fill(0xFFFF) # White
                text_color = 0xF800 # Red-ish (from alarm logic)
            
            # Helper for centering
            def draw_centered(text, y, color):
                text_width = len(text) * 8
                x = (320 - text_width) // 2
                lcd.text(text, x, y, color)
            
            draw_centered("!! DEPREM !!", 30, text_color)
            draw_centered(f"Magnitude: {event.magnitude:.1f}", 70, text_color)
            draw_centered(f"Country: {country}", 100, text_color)
            draw_centered(f"City: {city}", 130, text_color)
            
            t = time.localtime(event.timestamp + 10800)
            details = "Depth: {:.1f}km - Time: {:02d}:{:02d}".format(event.depth, t[3], t[4])
            draw_centered(details, 170, text_color)
            
            draw_centered("Touch to STOP", 210, text_color)
            lcd.show()
            
            # Check for STOP (Any Touch or Encoder Button)
            lcd.cs(1)
            time.sleep_us(50)
            coords = touch.get_touch()
            if coords or encoder.is_pressed():
                print("QUAKE ALERT STOPPED BY USER")
                buzzer.stop()
                current_view = "quake" # Go to list
                quake_module.show() # Refresh list
                time.sleep(0.5)

        # === ALARM RINGING MODE ===
        elif current_view == "alarm_ringing":
            # Play sound pattern
            buzzer.play_alarm_step(1)
            
            # Draw blinking background
            now_ms = time.ticks_ms()
            if ((now_ms - ringing_start_time) // 500) % 2 == 0:
                lcd.fill(0xF800) # Red
                text_color = 0xFFFF
            else:
                lcd.fill(0xFFFF) # White
                text_color = 0xF800
                
            lcd.text("!! ALARM !!", 110, 80, text_color)
            lcd.text("Touch screen to STOP", 80, 160, text_color)
            lcd.show()
            
            # Check for STOP (Any Touch or Encoder Button)
            lcd.cs(1)
            time.sleep_us(50)
            coords = touch.get_touch()
            
            if coords or encoder.is_pressed():
                # Stop alarm
                print("ALARM STOPPED BY USER")
                buzzer.stop()
                current_view = "dashboard"
                dash.draw_grid()
                time.sleep(0.5)


        # === GLOBAL QUAKE CHECK ===
        if current_view not in ["alarm_ringing", "quake_alert", "quake"]:
            if quake_module.check_background():
                current_view = "quake_alert"
                alert_start_time = time.ticks_ms()
                print("QUAKE ALERT TRIGGERED")

        # === GLOBAL EARTHQUAKE MONITORING ===
        # Always update sensors module for earthquake detection (even when not visible)
        sensors_module.update()
        
        # Check if earthquake alarm triggered and switch to Sensors module
        # DISABLED TEMPORARILY TO DEBUG MEASURE MODULE OPENING
        if False and sensors_module.alarm_active and current_view != "sensors":
            print(f"DEBUG: FORCED SWITCH TO SENSORS BY ALARM. Magnitude: {sensors_module.shake_magnitude}")
            
            # Hide current module to prevent screen conflicts
            if current_view == "clock":
                clock_module.hide()
            elif current_view == "date":
                date_module.hide()
            elif current_view == "alarm":
                alarm_module.hide()
            elif current_view == "weather":
                weather_module.hide()
            elif current_view == "currency":
                currency_module.hide()
            elif current_view == "quake" or current_view == "quake_alert":
                quake_module.hide()
            
            # Switch to sensors module
            current_view = "sensors"
            sensors_module.show()
        
        # === GLOBAL ALARM CHECK ===
        # Check alarm every loop if NOT already ringing
        if current_view != "alarm_ringing" and current_view != "quake_alert":
            check_res = alarm_mgr.check_alarms()
            if check_res:
                print(f"ALARM TRIGGERED VIEW SWITCH: ID {check_res['id']}")
                current_view = "alarm_ringing"
                ringing_start_time = time.ticks_ms()
                buzzer.start()
        
        # === GLOBAL HAND DETECTION (MAGIC TRIGGER) ===
        # Sadece screensaver'da değilsek sensör çalışsın (Kullanıcı talebi)
        if sensors_module.hand_sensor and current_view != "screensaver":
            is_detected = sensors_module.hand_sensor.read()
            if is_detected and not hand_trigger_active:
                # 80ms stabilite kontrolü (Hassasiyeti biraz daha azalttık)
                time.sleep_ms(80)
                if sensors_module.hand_sensor.read():
                    print(f"GLOBAL MAGIC TRIGGER: Switching to {magic_target_view}")
                    
                    # Hide current active module if any
                    if current_view == "clock": clock_module.hide()
                    elif current_view == "date": date_module.hide()
                    elif current_view == "alarm": alarm_module.hide()
                    elif current_view == "weather": weather_module.hide()
                    elif current_view == "currency": currency_module.hide()
                    elif current_view == "sensors": sensors_module.hide()
                    elif current_view == "quake": quake_module.hide()
                    
                    hand_trigger_active = True
                    current_view = magic_target_view
                    last_interaction_time = time.ticks_ms()
                    if current_view == "screensaver":
                        screensaver.draw()
            elif not is_detected:
                hand_trigger_active = False

        # === SCREEN TIMEOUT CHECK ===
        timeout_val = settings_module.settings.get("timeout", 300)
        if timeout_val > 0 and current_view != "screensaver" and current_view != "alarm_ringing" and current_view != "quake_alert":
            if time.ticks_diff(time.ticks_ms(), last_interaction_time) > (timeout_val * 1000):
                print(f"TIMEOUT: Switching to screensaver after {timeout_val}s inactivity")
                current_view = "screensaver"
                screensaver.draw()
                last_interaction_time = time.ticks_ms()
                    
        time.sleep(0.002)  # 2ms loop


except Exception as e:
    import sys
    sys.print_exception(e)
    # Hata mesajini ekrana yaz
    lcd.fill(0xF800)
    lcd.text("ERROR OCCURRED!", 10, 10, 0xFFFF)
    err_str = str(e)
    lcd.text(err_str[:40], 10, 30, 0xFFFF)
    lcd.text(err_str[40:80], 10, 45, 0xFFFF)
    lcd.show()
    while True:
        time.sleep(1)




