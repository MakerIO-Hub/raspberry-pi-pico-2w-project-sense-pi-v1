# DHT11 Sensör Entegrasyon Planı

## 1. Donanım Bağlantısı
- **Sensör**: DHT11 (Sıcaklık ve Nem)
- **Pinler**: 
    - **DATA**: GP22 (Pin 29)
    - **VCC**: 3.3V (Pin 36)
    - **GND**: GND (Pin 38)

## 2. Yazılım Stratejisi (Driver)
- **Kütüphane**: MicroPython'un dahili `dht` modülü kullanılacak.
- **Okuma Sıklığı**: Her 2 saniyede bir (DHT11 sensörü bu süreye ihtiyaç duyar).
- **Hata Yönetimi**: Sensör okunamadığında ekranda hata yerine "--.-" gösterilecek.

## 3. Arayüz Tasarımı (Grid Layout 1)
- **Konum**: Sol Üst Köşe (1. Kutu).
- **Tema Rengi**: `0x039F` (Koyu Mavi - İsteğe uygun).
- **Dil**: İngilizce.

### Görsel Yerleşim (106x107 piksel)
- **İkon Boyutu**: **50x50 piksel**.
    - Tam ortalanmış şekilde, termometre ve su damlası simgesi.
- **İçerik Yapısı**:
    - **Üst (İkon)**: Termometre/Damla ikonu.
    - **Orta (Yazı 1)**: `Temp: 24.5C`
    - **Alt (Yazı 2)**: `Hum: 55%`

### Etkileşim Mantığı
- **Seçili Değilken (Pasif)**:
    - **Arka Plan**: Siyah (`0x0000`).
    - **Görünüm**: Sadece çok silik veya gizli ikon/yazı (Minimalist).
- **Seçiliyken (Aktif)**:
    - **Arka Plan**: Mavi (`0x039F`) veya Mavi Çerçeveli Siyah.
    - **Çerçeve**: Mavi (`0x039F`).
    - **Görünüm**: Parlak beyaz yazı, detaylı ikon. Her 2 saniyede bir canlı veri güncellenir.

## 4. Uygulama Adımları
1.  **Başlangıç**: `SensorsModule` içinde `dht.DHT11(Pin(22))` tanımlanacak.
2.  **Zamanlayıcı**: Sensörü sürekli meşgul etmemek için `self.last_dht_read` zamanlayıcısı eklenecek.
3.  **Okuma Mantığı**: `update()` fonksiyonu içinde, sadece bu kutu seçiliyken çalışan `read_dht()` fonksiyonu olacak.
4.  **Çizim**: `draw_cell(0)` fonksiyonu sıcaklık (`self.temp`) ve nem (`self.hum`) değerlerini ekrana basacak şekilde güncellenecek.
