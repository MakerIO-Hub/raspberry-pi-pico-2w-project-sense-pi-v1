from machine import Pin, SPI
import time

class Touch:
    def __init__(self, spi, cs, irq=None):
        self.spi = spi
        self.cs = cs
        # IRQ pini opsiyonel, kullanmiyoruz ama kod hata vermesin diye tutuyoruz
        self.irq = irq
        
        self.cs.init(Pin.OUT, value=1)
        
        # Ekran cozunurlugu
        self.width = 320
        self.height = 240
        
        # Kalibrasyon (Test sonuçlarına göre)
        self.min_x = 4436
        self.max_x = 7783
        self.min_y = 4467
        self.max_y = 7935
        
        # Basınç Eşiği (2000 = Aşırı hassas / Tüy gibi)
        # 3500'den 2000'e düştü, simdi 400 yaparak cok daha hassas yapiyoruz
        self.threshold_z = 400 

    def cmd(self, code):
        """SPI komutu gönderip 2 byte okur (12-bit ADC verir)."""
        self.spi.write(bytearray([code]))
        raw = self.spi.read(2)
        return (raw[0] << 8 | raw[1]) >> 3

    def get_touch(self):
        """
        Dokunma koordinatlarını okur.
        Returns: (x, y) tuple or None
        """
        self.cs(0)
        
        # Basınç kontrolü (Z-Axis)
        z1 = self.cmd(0xB0)
        
        # Dokunma var mı?
        if z1 < self.threshold_z:
            self.cs(1)
            return None
        
        # X ve Y oku (RAW değerler)
        x_raw = self.cmd(0xD0)  # Touch X (fiziksel dikey)
        y_raw = self.cmd(0x90)  # Touch Y (fiziksel yatay)
        
        self.cs(1)
        
        # Normalize (0..1)
        norm_x = (x_raw - self.min_x) / (self.max_x - self.min_x)
        norm_y = (y_raw - self.min_y) / (self.max_y - self.min_y)
        
        # Sınırla
        norm_x = max(0, min(1, norm_x))
        norm_y = max(0, min(1, norm_y))
        
        # AXIS SWAP: Touch X → Screen Y, Touch Y → Screen X
        # Touch X (dikey hareket) → Screen Y (0-240)
        # Touch Y (yatay hareket) → Screen X (0-320)
        screen_y = int((1 - norm_x) * 240)  # Ters çevir (yukarı=0, aşağı=240)
        screen_x = int(norm_y * 320)         # Normal (sol=0, sağ=320)
        
        # Noise Filtresi: Köşe değerleri (320, 240) genellikle noise'dur
        if screen_x > 315 and screen_y > 235:
            return None
        
        return (screen_x, screen_y)
