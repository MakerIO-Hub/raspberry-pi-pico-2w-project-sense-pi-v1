# Deprem (Quake) Modülü Detaylı Uygulama Planı (Adım Adım)

Bu plan, SensePi cihazına gelişmiş bir deprem izleme ve erken uyarı sistemi eklemek için gereken tüm adımları içerir.

## ADIM 1: Veri Sürücüsü (Quake API Driver)
- **Çoklu Kaynak Desteği**: Türkiye için Kandilli/AFAD, diğer ülkeler için USGS (Global) verilerini çekecek `quake_api.py` sürücüsü yazılacak.
- **Hızlı Veri**: Erken uyarı için "automatic/preliminary" (çözümlenmemiş) verileri önceliklendiren bir yapı kurulacak.

## ADIM 2: Ülke Seçimi ve Mantıksal Filtreleme
- **Ülke Seçimi**: Modül içinde bir ayar menüsü veya seçim ekranı ile izlenecek ülke belirlenecek (Default: Türkiye).
- **Hassas Filtreleme**: Gelen tüm veriler işlenecek ancak **3.0 ve üzeri** olanlar "kritik" olarak işaretlenecek.

## GÖRSEL TASARIM (LCD 320x240)

Cihazın ekranı 320x240 piksel olduğu için tasarımı en verimli şekilde kullanacağız:

### A. Ana Liste Ekranı (Son 10 Deprem)
- **Üst Bar (Yükseklik: 30px)**: 
  - Sol tarafta beyaz renkli **"< back"** butonu (tıklanabilir/seçilebilir).
  - Ortada "DEPREM - TÜRKİYE" başlığı.
  - Sağda ülke seçimi için ikon.
- **Ayırıcı Çizgi**: Üst barın hemen altında, ekranı yatay olarak boydan boya bölen kontrast bir çizgi (örn: 0x8410 Gri).
- **Deprem Listesi**: Her biri 40-42 piksel yüksekliğinde 10 satır.
  - **Büyüklük Kutusu (Sol)**: 34x34 piksellik renkli bir kare. İçinde beyaz ve kalın puntoyla büyüklük (örn: **5.4**) yazar.
  - **Bilgi Alanı (Orta)**: Üstte "BÖLGE ADI" (Büyük harf), altta "Derinlik: X.X km" (Küçük harf).
  - **Zaman (Sağ)**: "12:45" gibi saat bilgisi, sağa yaslı.
- **Renk Semantiği**:
  - `0x07E0 (Yeşil)`: < 3.0 (Zararsız)
  - `0xFFE0 (Sarı)`: 3.0 - 4.5 (Hissedilir)
  - `0xFD20 (Turuncu)`: 4.5 - 6.0 (Kritik)
  - `0xF800 (Kırmızı)`: > 6.0 (Yıkıcı)

### B. Erken Uyarı (Early Warning) Ekranı
- Önemli bir sarsıntı dalgası beklendiğinde ekran anında **parlak kırmızıya** döner.
- Ortada devasa harflerle "ERKEN UYARI!" ve altında kaç saniye sonra sarsıntının beklendiği (örn: "22 SN SONRA") yazar.

### C. Ülke Seçim Menüsü
- Alfabetik olarak sıralanmış ülkelerin bulunduğu sade bir liste ekranı. Seçili olan ülke modülün rengiyle (Elektrik Moru) vurgulanır.

## ADIM 4: Erken Uyarı (Early Warning) Sistemi
- **Ultra Hızlı Sorgulama**: Sistem arka planda her 2-3 saniyede bir yeni veri kontrolü yapacak.
- **Zaman Kazanma Mantığı**: Deprem dalgalarının yayılma hızı hesaplanarak, merkeze uzaklığa göre kullanıcıya 15-30 saniye öncesinden haber verilecek.

## ADIM 5: Aktif Buzzer Entegrasyonu
- **3.0+ Sinyali**: Büyüklüğü 3.0'dan büyük olan her yeni deprem tespit edildiğinde buzzer tek seferlik bir sinyal verecek.
- **Erken Uyarı Alarmı**: Eğer 15-30 saniye içinde yıkıcı bir sarsıntı bekleniyorsa, buzzer **kesintisiz ve yüksek sesli** bir alarm moduna geçecek.

## ADIM 6: Sistem Entegrasyonu (main.py)
- Modülün Dashboard'a eklenmesi.
- Arka plan sorgulama işleminin (NTP veya Weather gibi) ana döngüye, cihazı yormayacak şekilde entegre edilmesi.

---

## Doğrulama ve Testler
- **Simülasyon**: API'den gelen veriler yapay olarak (Mock data) 3.0+ veya 6.0+ gibi değiştirilerek buzzer ve erken uyarı sisteminin doğruluğu test edilecek.
- **Liste Kontrolü**: Son 10 depremin listede doğru sıralandığı ve kaydırma işleminin akıcılığı doğrulanacak.
