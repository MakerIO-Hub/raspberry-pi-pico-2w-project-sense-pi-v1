from machine import Pin
import time

class SDCard:
    """
    Copy of drivers/sdcard.py for testing purposes in root directory.
    """
    def __init__(self, spi, cs):
        self.spi = spi
        self.cs = cs

        self.cmdbuf = bytearray(6)
        self.dummybuf = bytearray(512)
        self.tokenbuf = bytearray(1)
        for i in range(512):
            self.dummybuf[i] = 0xFF
        self.dummybuf_v = memoryview(self.dummybuf)

        self.init_card()

    def init_card(self):
        self.cs.init(Pin.OUT, value=1)
        # Kartı düşük hızda başlat (Kritik: < 400kHz)
        self.spi.init(baudrate=100000)
        
        # clock card at least 100 cycles with cs high
        for i in range(16):
            self.spi.write(b"\xff")

        # CMD0: go idle state
        if self.cmd(0, 0, 0x95) != 1:
            # Tekrar sına
            time.sleep_ms(100)
            if self.cmd(0, 0, 0x95) != 1:
                raise OSError("no SD card")

        # CMD8: confirm voltage range
        r = self.cmd(8, 0x01AA, 0x87, 0)
        # CMD8 response format: R7 (5 bytes: 1 status + 4 return)
        # But our simple cmd function might only return R1 (1 byte)
        # Let's fix this logic based on standard implementation
        
        # NOTE: Standard sdcard.py logic is complex. 
        # Using a simplified but robust init here.
        
        # Standard MicroPython sdcard.py approach:
        # CMD8 with arg 0x1aa, crc 0x87
        self.cs(0)
        self.spi.write(b'\x40\x00\x00\x00\x00\x95') # CMD0
        self.spi.read(1)
        self.cs(1)
        
        # Re-using the provided class structure with fixes
        pass
        
    def cmd(self, cmd, arg, crc, final=0, release=True, skip1=False):
        self.cs(0)

        # create and send the command
        buf = self.cmdbuf
        buf[0] = 0x40 | cmd
        buf[1] = arg >> 24
        buf[2] = arg >> 16
        buf[3] = arg >> 8
        buf[4] = arg
        buf[5] = crc
        self.spi.write(buf)

        if skip1:
            self.spi.readinto(self.tokenbuf, 0xFF)

        # wait for the response (R1 byte)
        for i in range(128):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if not (self.tokenbuf[0] & 0x80):
                break
        else:
            self.cs(1)
            return -1 # Timeout

        # receive more bytes if needed
        res = self.tokenbuf[0]
        if final > 0:
            # This is tricky without self.spi.read returning bytes directly in some ports
            # But let's assume standard behavior
            pass
            
        if release:
            self.cs(1)
            self.spi.write(b"\xff")
        return res

# --- 
# WAIT! The content above was becoming messy because I tried to fix it manually.
# Let's just WRITE THE EXACT CONTENT OF drivers/sdcard.py to root/sdcard.py
# I have the content from view_file.
