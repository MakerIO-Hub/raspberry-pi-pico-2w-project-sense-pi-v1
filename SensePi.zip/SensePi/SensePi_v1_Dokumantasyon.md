# Sense Pi Version 1 - Kapsamlı Teknik Dokümantasyon

**Sense Pi**, Raspberry Pi Pico 2W tabanlı, doğrudan ekrana entegre (Do-It-Yourself Shield yapısında) çalışan, kompakt ve son derece yetenekli bir masaüstü akıllı asistanıdır. Gelişmiş sensörleri, kesintisiz güç kaynağı (UPS) özelliği ve internet bağlantısı ile hem bir bilgi ekranı hem de taşınabilir bir ölçüm laboratuvarı işlevi görür.

---

## 1. Donanım ve Bileşenler

Proje modüler bir yapıya sahiptir. Aşağıda kullanılan tüm parçalar kategorize edilmiştir.

### Temel Kontrol ve Ekran Ünitesi
*   **Ana Kontrolcü:** Raspberry Pi Pico 2W (Çift Çekirdekli RP2350 İşlemci, 150MHz)
*   **Ekran:** 2.8 inç SPI TFT LCD Dokunmatik Panel (320x240 Piksel çözünürlük, XPT2046 Dokunmatik sürücü) - *Doğrudan Pico üzerine monteli.*
*   **Giriş Aygıtı:** KY-040 Rotary Encoder (Menü kontrolü ve seçimler için döner buton)
*   **Ses Çıkışı:** Pasif Piezo Buzzer (Alarm ve sesli geri bildirimler için)

### Sensör Grubu
1.  **DHT-11:** Dijital Sıcaklık ve Nem Sensörü (Oda sıcaklığını takip eder).
2.  **MPU-6050:** 6 Eksenli İvmeölçer ve Jiroskop (Sismometre, Su Terazisi ve Adımsayar olarak kullanılır).
3.  **HC-SR04:** Ultrasonik Mesafe Sensörü (Mesafe ölçümü ve engel algılama için).
4.  **QRE1113 (IR):** Kızılötesi Yansıma Sensörü (Temassız el hareketi ile ekranı uyandırmak için).

### Güç ve UPS Sistemi (Kesintisiz Enerji)
Cihazın elektrik kesintilerinde çalışmaya devam etmesini ve tamamen taşınabilir olmasını sağlayan batarya sistemidir.
*   **Piller:** 3 Adet 18650 Lityum İyon Pil (Seri bağlı, Toplam 12.6V kapasite).
*   **Koruma Devresi (BMS):** 1 Adet 3S 20A BMS Kartı (Pillerin güvenli şarj/deşarj kontrolü için).
*   **Voltaj Regülatörü:** 1 Adet Çift USB Çıkışlı 5V 3A Regülatör (12V pil voltajını cihaz için güvenli 5V'a düşürür).
*   **Şarj Modülü:** 1 Adet 3S 2A Type-C Şarj Modülü (Pilleri Type-C kablosuyla hızlı şarj etmek için).

---

## 2. Raspberry Pi Pico 2W Teknik Özellikleri

Sense Pi'nin beyni olan Pico 2W, yüksek performansıyla dikkat çeker:
*   **İşlemci:** RP2350 (Arm Cortex-M33, 150 MHz). Akıcı arayüz geçişleri sağlar.
*   **Kablosuz:** Wi-Fi 4 (802.11n) desteği ile hava durumu, saat, döviz kurları ve takvim verilerini internetten otomatik çeker.
*   **Bellek:** 520 KB dahili SRAM, renkli grafiklerin ve sensör verilerinin (özellikle deprem verisi) işlenmesi için gerekli alanı sunar.
*   **Depolama:** 4 MB Flash bellek, tüm yazılım ve ikonları barındırır.

---

## 3. Bağlantı Rehberi (Pinout)

Ekran modülü Pico'nun arkasına (Shield şeklinde) takılı olduğu için pin bağlantıları sabittir. Harici modüller için aşağıdaki bağlantıları yapmanız gerekir.

| Modül Adı | Modül Pini | Bağlanacağı Pico Pini | Fiziksel Pin No | Voltaj / Notlar |
| :--- | :--- | :--- | :--- | :--- |
| **Rotary Encoder** | CLK | **GP0** | Pin 1 | Menü Dönüş A |
| *(Menü Kontrolü)* | DT | **GP1** | Pin 2 | Menü Dönüş B |
| | SW | **GP2** | Pin 4 | Buton Tıklama |
| | (+) / VCC | **3V3** | Pin 36 | 3.3V Besleme |
| | (-) / GND | **GND** | Ortak | Toprak |
| | | | | |
| **MPU-6050** | SDA | **GP4** | Pin 6 | I2C Veri Hattı |
| *(Deprem Sensörü)* | SCL | **GP5** | Pin 7 | I2C Saat Hattı |
| | VCC | **3V3** | Pin 36 | 3.3V Besleme |
| | GND | **GND** | Ortak | Toprak |
| | | | | |
| **HC-SR04** | TRIG | **GP6** | Pin 9 | Tetikleme |
| *(Mesafe Sensörü)* | ECHO | **GP7** | Pin 10 | Veri Okuma |
| | VCC | **VBUS** | Pin 40 | **5V Besleme (Dikkat!)** |
| | GND | **GND** | Ortak | Toprak |
| | | | | |
| **Buzzer** | (+) Sinyal | **GP14** | Pin 19 | Ses Çıkışı |
| *(Ses)* | (-) / GND | **GND** | Ortak | Toprak |
| | | | | |
| **DHT-11** | DATA / OUT | **GP22** | Pin 29 | Sıcaklık Verisi |
| *(Isı ve Nem)* | VCC | **3V3** | Pin 36 | 3.3V Besleme |
| | GND | **GND** | Ortak | Toprak |
| | | | | |
| **QRE1113** | OUT | **GP26** | Pin 31 | Analog Giriş (ADC0) |
| *(El Sensörü)* | VCC | **3V3** | Pin 36 | 3.3V Besleme |
| | GND | **GND** | Ortak | Toprak |

---

## 4. Güç ve UPS Sistemi Kurulumu

Güç sistemi, cihazı kablosuz kullanmanıza olanak tanır. Bağlantı sırası şöyledir:

1.  **Pil Grubu:** 3 adet 18650 pil seri bağlanır. (Voltaj Aralığı: 11.1V - 12.6V)
2.  **BMS Bağlantısı:** Pillerin uçları, **3S 20A BMS** devre kartı üzerindeki lehim noktalarına (0V, 4.2V, 8.4V, 12.6V) sırasıyla lehimlenir.
3.  **Şarj Sistemi:** **Type-C Şarj Modülü**nün çıkış uçları, BMS kartının giriş/çıkış (P+/P-) uçlarına bağlanır. Böylece cihazı telefon şarj aletiyle şarj edebilirsiniz.
4.  **Voltaj Düşürme:** BMS'in çıkış uçları (P+/P-), **5V 3A Regülatör Modülü**nün girişine bağlanır. Bu modül yüksek voltajı 5V'a düşürür.
5.  **Cihaz Beslemesi:** Regülatör modülünün USB çıkışından alınan enerji, Raspberry Pi Pico'nun **VSYS** veya USB girişine bağlanarak sisteme temiz enerji verir.

---

## 5. Yazılım Özellikleri ve Uygulamalar

Sense Pi, çok fonksiyonlu bir işletim sistemi gibi çalışır.

*   **Ana Ekran (Dashboard):** İkonlu menü yapısı ile tüm uygulamalara hızlı erişim sağlar.
*   **Saat ve Tarih:** İnternetten otomatik senkronize olan atomik saat hassasiyeti.
*   **Hava Durumu:** Konum bazlı anlık hava durumu ve sıcaklık takibi.
*   **Döviz Kurları:** TCMB verileriyle Dolar, Euro ve Sterlin kurlarının canlı takibi.
*   **Deprem Takip Sistemi:** Hem internetten son depremleri listeler, hem de cihaz üzerindeki sensörle bulunduğu masadaki sarsıntıları (deprem) algılayıp alarm verir.
*   **Akıllı Alarm:** İstenilen saatte uyanmak veya hatırlatma almak için sesli alarm sistemi.
*   **Sensör Araçları:**
    *   **Su Terazisi:** Dijital olarak yüzey eğimini ölçer.
    *   **Adımsayar:** Taşınabilir modda adımlarınızı ve yaktığınız kaloriyi sayar.
    *   **Mesafe Ölçer:** Lazer metre gibi hassas mesafe ölçümü yapar ve ölçümleri listeler.
    *   **Oda Monitörü:** Odanızın sıcaklık ve nem değerlerini sürekli gösterir.
    *   **El Feneri:** Ekranı maksimum parlaklıkta beyaz yaparak ortam aydınlatması sağlar.
*   **Ekran Koruyucu:** Hareketsizlik durumunda devreye giren şık bilgi ekranı. Elinizi ekrana yaklaştırdığınızda (dokunmadan) uyanır (Magic Wake).

***

*Doküman Oluşturulma Tarihi: 19.02.2026*
