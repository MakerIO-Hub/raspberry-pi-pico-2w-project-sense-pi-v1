from machine import Pin
import framebuf
import time

class LCD_2inch8(framebuf.FrameBuffer):
    def __init__(self, spi, cs, dc, rst, bl):
        # === HORIZONTAL MODE ===
        self.width = 320
        self.height = 240

        self.cs = cs
        self.dc = dc
        self.rst = rst
        self.bl = bl

        self.cs.init(Pin.OUT, value=1)
        self.dc.init(Pin.OUT, value=0)
        self.rst.init(Pin.OUT, value=1)
        
        # Backlight can be Pin or PWM
        if hasattr(self.bl, "duty_u16"):
            # It's already PWM
            self.bl.freq(1000)
            self.bl.duty_u16(65535)
        else:
            self.bl.init(Pin.OUT, value=1)

        self.spi = spi
        self.buffer = bytearray(self.width * self.height * 2)
        super().__init__(self.buffer, self.width, self.height, framebuf.RGB565)

        self.reset()
        self.init_display()

    def reset(self):
        self.rst(0)
        time.sleep(0.1)
        self.rst(1)
        time.sleep(0.1)

    def write_cmd(self, cmd):
        self.cs(0)
        self.dc(0)
        self.spi.write(bytearray([cmd]))
        self.cs(1)

    def write_data(self, data):
        self.cs(0)
        self.dc(1)
        self.spi.write(bytearray([data]))
        self.cs(1)

    def init_display(self):
        # USB ÜSTTE – HORIZONTAL – YAZI DÜZ
        self.write_cmd(0x36)
        self.write_data(0xA0)   # 90° + mirror FIX

        self.write_cmd(0x3A)
        self.write_data(0x55)   # RGB565

        self.write_cmd(0x20)   # Color Inversion OFF (Normal)
        self.write_cmd(0x11)
        time.sleep(0.12)
        self.write_cmd(0x29)

    def show(self):
        # === DOĞRU ADRES PENCERESİ (320x240) ===
        self.write_cmd(0x2A)  # Column
        self.write_data(0x00)
        self.write_data(0x00)
        self.write_data((self.width - 1) >> 8)
        self.write_data((self.width - 1) & 0xFF)

        self.write_cmd(0x2B)  # Row
        self.write_data(0x00)
        self.write_data(0x00)
        self.write_data((self.height - 1) >> 8)
        self.write_data((self.height - 1) & 0xFF)

        self.write_cmd(0x2C)
        self.cs(0)
        self.dc(1)
        self.spi.write(self.buffer)
        self.cs(1)

    def draw_bitmap_colored(self, x, y, w, h, data, fg_color, bg_color=None):
        """
        Draws a bitmap with color override.
        Assumes input data is RGB565 (Little Endian).
        - Uses the TOP-LEFT PIXEL as the 'Background Color' (Transparency Key).
        - If a pixel matches the key, it is skipped (or drawn as bg_color).
        - If a pixel differs from the key, it is drawn as fg_color.
        """
        # Determine Transparency Key from (0,0)
        key_pixel = (data[1] << 8) | data[0] if len(data) >= 2 else 0

        for j in range(h):
            for i in range(w):
                idx = (j * w + i) * 2
                if idx + 1 < len(data):
                    # Read Pixel (Little Endian)
                    pixel = (data[idx+1] << 8) | data[idx]
                    
                    is_background = (pixel == key_pixel)
                    
                    # Decide color
                    if is_background:
                        target_color = bg_color # Usually None (Transparent)
                    else:
                        target_color = fg_color # Symbol Color
                    
                    if target_color is not None:
                        self.pixel(x + i, y + j, target_color)
