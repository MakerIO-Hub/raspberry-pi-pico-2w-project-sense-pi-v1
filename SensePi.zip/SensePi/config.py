"""
Configuration file for SensePi
Edit this file with your WiFi credentials before uploading to Pico
"""

# WiFi Configuration
WIFI_SSID = "SUPERONLINE-WiFi_4931"        # WiFi network name
WIFI_PASSWORD = "7EFXYAVA3KWJ" # WiFi password

# RTC Configuration
USE_EXTERNAL_RTC = False  # True for DS3231, False for Pico internal
RTC_I2C_SCL_PIN = 1       # SCL pin for DS3231 (if external)
RTC_I2C_SDA_PIN = 0       # SDA pin for DS3231 (if external)

# NTP Configuration
NTP_SERVER = "pool.ntp.org"
DEFAULT_TIMEZONE_OFFSET = 3   # UTC+3 for Turkey (will be auto-detected)

# Display Configuration
DEFAULT_BRIGHTNESS = 255       # 0-255

# OpenWeatherMap API Configuration
OPENWEATHERMAP_API_KEY = "cff69c0dd777fa73518805a72bd697ce"  # Your API key

# Google Calendar Configuration
# Deploy the Google Apps Script and paste the Web App URL here
GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzD5iXCn8hGimV6BurmyvP7Ec7HI9LrIbCc8b3GjD7AdztcvACnxND6sEzgFQhG_hKQIg/exec" 
