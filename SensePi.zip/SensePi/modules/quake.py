import time

class QuakeModule:
    def __init__(self, lcd, quake_api, buzzer=None, early_warning_threshold=3.0):
        self.lcd = lcd
        self.api = quake_api
        self.buzzer = buzzer
        self.threshold = early_warning_threshold
        
        self.current_country = "GL" # Default: Global
        self.events = []
        self.last_update = 0
        self.update_interval = 600000 # 10 minutes (Normal mode)
        
        # UI State
        self.selected_index = 0
        self.scroll_offset = 0
        self.view_mode = "LIST" # LIST, WARNING, SETTINGS
        self.warning_active = False
        
        # Colors
        self.COLOR_GREEN = 0x07E0
        self.COLOR_YELLOW = 0xFFE0
        self.COLOR_ORANGE = 0xFD20
        self.COLOR_RED = 0xF800
        self.COLOR_TEXT = 0x0000 # Black Text (on Orange)
        self.COLOR_BG = 0xdd22   # Standard Orange BG
        self.COLOR_HEADER_TXT = 0x0000 # Black Header (requested)
        self.COLOR_SEPARATOR = 0x0000 # Black Separator

    def show(self):
        """Draw screen initially"""
        self.lcd.fill(self.COLOR_BG) # Make whole screen orange
        self.view_mode = "LIST"
        self.draw_header()
        self.draw_list()
        
        # Update if no data or data is old
        if not self.events or (time.ticks_ms() - self.last_update > self.update_interval):
            self.update()

    def update(self):
        """Fetch data from API and update list"""
        # Update list area only (Y=21+)
        self.lcd.fill_rect(0, 21, 320, 219, self.COLOR_BG)
        self.lcd.text("Updating...", 120, 120, self.COLOR_TEXT)
        self.lcd.show()
        
        try:
            # API Call
            new_events = self.api.get_quakes(self.current_country, limit=20)
            if new_events:
                # Check for updates
                if self.events and new_events[0].timestamp > self.events[0].timestamp:
                    # New quake!
                    latest = new_events[0]
                    self.check_early_warning(latest)
                    
                self.events = new_events
                self.last_update = time.ticks_ms()
            else:
                self.lcd.text("No Data!", 120, 140, self.COLOR_TEXT) # Black
                self.lcd.show()
                time.sleep(1)
                
        except Exception as e:
            print(f"Quake Update Error: {e}")
            self.lcd.text("Connection Error!", 90, 140, self.COLOR_TEXT) # Black
            self.lcd.show()
            time.sleep(1)
            
        # Refresh UI
        self.draw_list()

    def check_early_warning(self, latest_event):
        """Check if latest quake is critical"""
        # UTC+3 logic handled roughly by just checking magnitude here
        
        is_strong = latest_event.magnitude >= self.threshold
        
        if is_strong:
            print(f"EARLY WARNING TRIGGERED: {latest_event.magnitude} @ {latest_event.location}")
            # Buzzer Signal (Short beeps - 3.0+ for any quake)
            if self.buzzer:
                for _ in range(3):
                    self.buzzer.beep(0.1)
                    time.sleep(0.1)
                
            # Critical Warning (4.5+) -> Full Screen Alert
            if latest_event.magnitude >= 4.5:
                self.trigger_early_warning(latest_event)

    def trigger_early_warning(self, event):
        self.view_mode = "WARNING"
        self.warning_active = True
        
        # Red Flash Screen and Alarm
        # Play for 10 seconds or until user intervention (not implemented here yet)
        start_time = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), start_time) < 10000: # 10 sec
            self.lcd.fill(self.COLOR_RED)
            self.lcd.text("! EARLY WARNING !", 60, 80, 0xFFFF) # White on Red
            self.lcd.text(f"MAGNITUDE: {event.magnitude}", 80, 110, 0xFFFF) # White on Red
            self.lcd.text(event.location[:20], 40, 140, 0xFFFF) # White on Red
            self.lcd.show()
            
            if self.buzzer: self.buzzer.start() # Continuous beep
            time.sleep(0.5)
            
            self.lcd.fill(0x0000) # Black flash
            self.lcd.show()
            if self.buzzer: self.buzzer.stop()
            time.sleep(0.2)
            
        # Return to list mode
        self.view_mode = "LIST"
        self.warning_active = False
        self.show()

    def draw_header(self):
        # Background is orange
        
        # Back arrow (BLACK)
        self.lcd.text("<", 5, 5, self.COLOR_HEADER_TXT)
        
        # "Back" text (BLACK)
        self.lcd.text("Back", 25, 5, self.COLOR_HEADER_TXT)
        
        # TITLE REMOVED AS REQUESTED
        
        # Separator Line (BLACK)
        self.lcd.hline(0, 20, 320, self.COLOR_SEPARATOR)

    def draw_list(self):
        if self.view_mode != "LIST": return
        
        # Clear list area
        self.lcd.fill_rect(0, 21, 320, 219, self.COLOR_BG)
        
        start_y = 25 # Header ends at Y=20
        item_height = 42
        
        # Scroll slice
        visible_items = self.events[self.scroll_offset : self.scroll_offset + 5]
        
        for i, event in enumerate(visible_items):
            y = start_y + (i * item_height)
            
            # Color coding
            color = self.COLOR_GREEN
            if event.magnitude >= 6.0: color = self.COLOR_RED
            elif event.magnitude >= 4.5: color = self.COLOR_ORANGE
            elif event.magnitude >= 3.0: color = self.COLOR_YELLOW
            
            # Magnitude Box
            self.lcd.fill_rect(10, y, 34, 34, color)
            mag_str = f"{event.magnitude:.1f}"
            # Text color inside box: Yellow/Green -> Black, Orange/Red -> White
            mag_txt_color = 0x0000 if (color == self.COLOR_YELLOW or color == self.COLOR_GREEN) else 0xFFFF
            self.lcd.text(mag_str, 12, y+10, mag_txt_color)
            
            # Location and Depth (Black/Dark Grey Text)
            loc_str = event.location[:25] # Truncate
            self.lcd.text(loc_str, 55, y, self.COLOR_TEXT)
            depth_str = f"Depth: {event.depth:.1f} km"
            self.lcd.text(depth_str, 55, y+15, 0x4208) # Dark Grey
            
            # Time
            # Convert timestamp to local time (+3 hours approx for TR/Global user)
            t = time.localtime(event.timestamp + 10800) # UTC+3 assumption
            time_str = "{:02d}:{:02d}".format(t[3], t[4])
            self.lcd.text(time_str, 270, y+10, 0x0000)
            
            # Separator line (Black)
            self.lcd.hline(10, y+40, 300, 0x0000)

        self.lcd.show()

    def handle_touch(self, x, y):
        """Touch controls"""
        # Back Button (Top Left)
        if y < 30 and x < 50:
            return "dashboard"
            
        # List Scroll (Simple: Top half up, bottom half down)
        if y > 30:
            if y < 140: # Scroll Up
                if self.scroll_offset > 0:
                    self.scroll_offset -= 1
                    self.draw_list()
            else: # Scroll Down
                if self.scroll_offset < len(self.events) - 5:
                    self.scroll_offset += 1
                    self.draw_list()
                    
        return None

    def handle_encoder(self, diff):
        """Encoder scroll"""
        if diff > 0: # Down
             if self.scroll_offset < len(self.events) - 5:
                self.scroll_offset += 1
                self.draw_list()
        else: # Up
            if self.scroll_offset > 0:
                self.scroll_offset -= 1
                self.draw_list()

    def handle_button(self):
        """Encoder button -> Refresh"""
        self.update() 
        return None
