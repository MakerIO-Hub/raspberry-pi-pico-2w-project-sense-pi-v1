import time
import math
import os

class Screensaver:
    def __init__(self, lcd, sensors_module, weather_module=None):
        self.lcd = lcd
        self.sensors = sensors_module
        self.weather = weather_module
        
        # Colors (SensePi Theme)
        self.bg_color = 0xdd22  # Orange
        self.text_color = 0xFFFF # White
        self.accent_color = 0x0000 # Black
        self.clock_accent = 0xF800 # Red (Seconds)
        
        # Icons
        self.date_icon_data = self.load_icon("icons/date.bin")
        self.weather_icon_data = self.load_icon("icons/weather.bin")
        self.celsius_icon_data = self.load_icon("icons/celsius.bin")
        self.status_icons_cache = {} # Cache for dynamically loaded weather status icons
        
    def load_icon(self, path):
        try:
            with open(path, "rb") as f:
                return f.read()
        except:
            return None

    def draw(self):
        # 1. Clear Screen (Orange)
        self.lcd.fill(self.bg_color)
        
        now = time.localtime()
        
        # === 1. HEADER: DATE (Top) ===
        self.draw_header(now)
        
        # === 2. CENTER: LARGE ANALOG CLOCK ===
        time_data = {
            "hour": now[3],
            "minute": now[4],
            "second": now[5]
        }
        # Adjusted radius to 55 (1 click larger per user request)
        # Center Y=120 (Exact Center of Screen)
        self.draw_analog_clock(160, 120, 55, time_data)
        
        # === 3. FOOTER: WEATHER & LIVING ROOM (Bottom) ===
        self.draw_footer()
        
        self.lcd.show()

    def draw_header(self, now):
        # Top background bar (Optional, for contrast)
        # self.lcd.fill_rect(0, 0, 320, 30, 0x0000)
        
        # Icon removed per user request
            
        # Date Text (Centered in header area)
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        months = ["", "January", "February", "March", "April", "May", "June", 
                  "July", "August", "September", "October", "November", "December"]
        
        day_name = days[now[6]]
        date_str = "{} {}".format(now[2], months[now[1]])
        full_date = f"{day_name}, {date_str}"
        
        # Draw Full Date string scaled (Header)
        # Calculate X to center text relative to full width (320)
        # Scale reduced to 1.5 (Simulated by drawing twice or just 1 if 1.5 is hard) 
        # Actually user asked "2 kademe kucult" from Scale 2 -> Scale 1 is good.
        # Center vertically in header (Height 50)
        # Date at top (Y=12), Location below (Y=32)
        scale = 1
        
        # 1. Date
        text_w = len(full_date) * 8 * scale
        text_x = (320 - text_w) // 2
        self.draw_scaled_text(full_date, text_x, 12, scale, 0xFFFF)
        
        # 2. Location (Static per user request: "Izmir, Turkiye")
        # Color: Black (0x0000) as requested ("siyah olacak")
        loc_str = "Izmir, Turkiye"
        loc_w = len(loc_str) * 8 * scale
        loc_x = (320 - loc_w) // 2
        self.draw_scaled_text(loc_str, loc_x, 32, scale, 0x0000) 
        
        # Separator line at Y=50 (Symmetric Top)
        self.lcd.hline(0, 50, 320, 0xFFFF)

    def draw_footer(self):
        # Bottom separator at Y=190
        self.lcd.hline(0, 190, 320, 0xFFFF)
        
        # Vertical Separator at X=160 (Split Footer)
        self.lcd.vline(160, 190, 50, 0xFFFF)
        
        # === LEFT: WEATHER (0-160) ===
        # Center of Left Box: X=80
        # Icon (50x50): X = 80 - 25 - 20 (Offset left to make room for text) = 35
        icon_x = 25
        if self.weather_icon_data:
            self.lcd.draw_bitmap_colored(icon_x, 190, 50, 50, self.weather_icon_data, 0xFFFF, None)
            
        # Weather Data
        if self.weather and self.weather.current_weather:
            temp = self.weather.current_weather.get('temperature', 0)
            temp_str = f"{int(round(temp))}"
            
            text_x = icon_x + 50 + 5 # Next to icon
            self.draw_scaled_text(temp_str, text_x, 207, 2, 0xFFFF) 
            
            text_w = len(temp_str) * 16
            celsius_x = text_x + text_w + 5
            if self.celsius_icon_data:
                self.lcd.draw_bitmap_colored(celsius_x, 203, 24, 24, self.celsius_icon_data, 0xFFFF, None)
        else:
            self.draw_scaled_text("--", icon_x + 60, 207, 2, 0xFFFF)

        # === RIGHT: LIVING ROOM (160-320) ===
        # Center of Right Box: X=240
        # Footer Height: 50 (190-240). Center Y=215.
        # Content: Title (8px) + Gap (4px) + Data (8px) = 20px height.
        # Start Y = 215 - 10 = 205.
        
        # Title: LIVING ROOM
        title = "LIVING ROOM"
        t_w = len(title) * 8
        t_x = 160 + (160 - t_w) // 2
        self.lcd.text(title, t_x, 205, 0xFFFF) # Y=205
        
        # Sensor Data: 21.0c 54% hum.
        if self.sensors and self.sensors.temp is not None:
            # Format requested: "21.0c 54% hum."
            val_str = f"{self.sensors.temp:.1f}c   {int(self.sensors.hum)}% hum."
        else:
            val_str = "Syncing..."
            
        v_w = len(val_str) * 8
        v_x = 160 + (160 - v_w) // 2
        
        # Y position: Below title (Y=205) + 8 + 4 = 217
        self.lcd.text(val_str, v_x, 217, 0xFFFF)
                 
    def get_weather_status_icon(self, code):
        # Map WMO codes to filenames
        # Simple mapping based on typical codes
        filename = "weather_clear.bin" # Default
        
        if code in [1, 2, 3]: filename = "weather_partly_cloudy.bin" # Cloud
        elif code in [45, 48]: filename = "weather_fog.bin" # Fog
        elif code in [51, 53, 55, 61, 63, 65, 80, 81, 82]: filename = "weather_rain.bin" # Rain
        elif code in [71, 73, 75, 85, 86]: filename = "weather_snow.bin" # Snow
        elif code in [95, 96, 99]: filename = "weather_thunder.bin" # Thunder
        
        # Check cache
        if filename in self.status_icons_cache:
            return self.status_icons_cache[filename]
            
        # Load and cache
        icon_data = self.load_icon(f"icons/{filename}")
        if icon_data:
            self.status_icons_cache[filename] = icon_data
            return icon_data
        return None

    def draw_analog_clock(self, center_x, center_y, radius, time_data):
        # Outer dial (WHITE - Double line for thickness)
        for t in range(3):
            self.draw_circle(center_x, center_y, radius - t, 0xFFFF)
            
        # Hour markers (Bold markers for large clock)
        for i in range(12):
            angle = math.radians(i * 30 - 90)
            inner_r = radius - 8 if i % 3 == 0 else radius - 5 # Longer markers for 12, 3, 6, 9
            x1 = int(center_x + (radius - 2) * math.cos(angle))
            y1 = int(center_y + (radius - 2) * math.sin(angle))
            x2 = int(center_x + inner_r * math.cos(angle))
            y2 = int(center_y + inner_r * math.sin(angle))
            self.draw_thick_line(x1, y1, x2, y2, 0xFFFF, 2)
            
        # Calculate angles
        hr = time_data["hour"] % 12
        mn = time_data["minute"]
        sc = time_data["second"]
        
        hr_angle = math.radians((hr * 30 + mn * 0.5) - 90)
        mn_angle = math.radians((mn * 6) - 90)
        sc_angle = math.radians((sc * 6) - 90)
        
        # Hour hand (Short, very thick)
        hr_len = radius * 0.5
        hx = int(center_x + hr_len * math.cos(hr_angle))
        hy = int(center_y + hr_len * math.sin(hr_angle))
        self.draw_thick_line(center_x, center_y, hx, hy, 0xFFFF, 4)
        
        # Minute hand (Longer, thick)
        mn_len = radius * 0.75
        mx = int(center_x + mn_len * math.cos(mn_angle))
        my = int(center_y + mn_len * math.sin(mn_angle))
        self.draw_thick_line(center_x, center_y, mx, my, 0xFFFF, 3)
        
        # Second hand (Red, thin and stylish)
        sc_len = radius * 0.85
        sx = int(center_x + sc_len * math.cos(sc_angle))
        sy = int(center_y + sc_len * math.sin(sc_angle))
        # Tail for second hand
        tx = int(center_x - 15 * math.cos(sc_angle))
        ty = int(center_y - 15 * math.sin(sc_angle))
        self.lcd.line(tx, ty, sx, sy, self.clock_accent)
        
        # Center dot (Black center with white ring)
        self.draw_filled_circle(center_x, center_y, 5, 0xFFFF)
        self.draw_filled_circle(center_x, center_y, 2, 0x0000)

    def draw_scaled_text(self, text, x, y, size, color):
        if size == 1:
            self.lcd.text(text, x, y, color)
            return
            
        import framebuf
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        for row in range(h):
            for col in range(w):
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                if c != 0:
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)

    def draw_circle(self, x0, y0, r, color):
        x = r
        y = 0
        err = 0
        while x >= y:
            self.lcd.pixel(x0 + x, y0 + y, color)
            self.lcd.pixel(x0 + y, y0 + x, color)
            self.lcd.pixel(x0 - y, y0 + x, color)
            self.lcd.pixel(x0 - x, y0 + y, color)
            self.lcd.pixel(x0 - x, y0 - y, color)
            self.lcd.pixel(x0 - y, y0 - x, color)
            self.lcd.pixel(x0 + y, y0 - x, color)
            self.lcd.pixel(x0 + x, y0 - y, color)
            if err <= 0:
                y += 1
                err += 2 * y + 1
            if err > 0:
                x -= 1
                err -= 2 * x + 1

    def draw_filled_circle(self, x0, y0, r, color):
        for y in range(-r, r + 1):
            for x in range(-r, r + 1):
                if x*x + y*y <= r*r:
                    self.lcd.pixel(x0 + x, y0 + y, color)

    def draw_thick_line(self, x0, y0, x1, y1, color, thickness=2):
        half = thickness // 2
        for off in range(-half, half + 1):
            self.lcd.line(x0 + off, y0, x1 + off, y1, color)
            self.lcd.line(x0, y0 + off, x1, y1 + off, color)

    def update(self):
        self.draw()
