import time
from drivers.hcsr04 import HCSR04

class DistanceModule:
    def __init__(self, lcd, encoder_button_func=None):
        self.lcd = lcd
        # GP6=Trig, GP7=Echo (Fixed pins as per plan)
        self.sensor = HCSR04(trigger_pin=6, echo_pin=7)
        self.last_update = 0
        self.last_dist = 0
        self.running = False
        
    def show(self):
        """
        Initial screen draw
        """
        self.lcd.fill(0x0000)
        self.lcd.text("DISTANCE METER", 100, 10, 0xFFFF)
        self.lcd.hline(0, 25, 320, 0xFFFF)
        self.lcd.text("Measuring...", 110, 100, 0x07E0)
        self.lcd.text("Press Button to Exit", 80, 215, 0xFFFF)
        self.lcd.show()
        self.running = True
        self.update(force=True)

    def update(self, force=False):
        """
        Periodic update
        """
        # Measure every 200ms
        if not force and time.ticks_diff(time.ticks_ms(), self.last_update) < 100:
            return

        dist = self.sensor.measure_cm()
        self.last_update = time.ticks_ms()
        
        if dist == -1:
            dist_str = "TIMEOUT"
            color = 0xF800 # Red
        else:
            dist_str = "{:.1f} cm".format(dist)
            color = 0x07E0 # Green
            if dist < 10: color = 0xF800 # Red if too close
            elif dist < 30: color = 0xFFE0 # Yellow
            
        # Clear previous value area
        self.lcd.fill_rect(0, 80, 320, 80, 0x0000)
        
        # Draw value (Centered approx)
        # Using simple text for now
        
        # Center text calculation (approx 8px width per char)
        text_x = (320 - (len(dist_str) * 8)) // 2 
        
        # Visualize with a bar
        max_dist = 200 # 2 meters max for bar
        bar_width = min(300, int((dist / max_dist) * 300)) if dist > 0 else 0
        self.lcd.rect(10, 150, 300, 20, 0xFFFF) # Frame
        self.lcd.fill_rect(10, 150, bar_width, 20, color) # Bar
        
        # Text
        self.lcd.text(dist_str, text_x, 100, color)
        
        self.lcd.show()

    def handle_encoder(self, diff):
        pass

    def handle_encoder_button(self):
        self.running = False
        return "dashboard"

    def handle_touch(self, x, y):
        # Return to dashboard on any touch
        self.running = False
        return "dashboard"
