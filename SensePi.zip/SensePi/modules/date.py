"""
Date Module for SensePi
Display: Analog calendar + Digital date + Year progress bar
"""

import time

class DateModule:
    def __init__(self, lcd, rtc_driver, timezone_detector, holiday_manager=None):
        self.lcd = lcd
        self.rtc = rtc_driver
        self.tz_detector = timezone_detector
        self.holiday_mgr = holiday_manager
        
        # Display settings
        self.calendar_system = "gregorian"  # or "hijri", "julian"
        
        # Timezone info
        self.timezone = "Europe/Istanbul"
        self.timezone_offset = 3 * 3600  # UTC+3
        self.city = "Istanbul"
        self.country = "Turkey"
        self.country_code = "TR"
        
        # Colors (same as Clock module)
        self.bg_color = 0xdd22  # Orange
        self.text_color = 0xFFFF  # White
        self.accent_color = 0xF81F  # Magenta (for highlights)
        self.progress_empty = 0x4208  # Dark gray
        
        # State
        self.active = False
        self.current_date = None
        self.selected_idx = 0 # 0: Back
        
        # Month names (English)
        self.months = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ]
        
        # Month abbreviations
        self.months_short = [
            "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
            "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"
        ]
        
        # Day names (English)
        self.days = [
            "Monday", "Tuesday", "Wednesday", "Thursday",
            "Friday", "Saturday", "Sunday"
        ]
        
    def show(self):
        """Show Date module (full screen)"""
        self.active = True
        print("Date: Opening...")
        
        # Auto-detect timezone on first show (if not already done)
        if self.timezone == "Europe/Istanbul" and self.tz_detector:
            self._detect_timezone()
            
        # Initialize holidays if manager exists
        if self.holiday_mgr:
            current_date = self._get_current_date()
            if not self.holiday_mgr.last_sync:
                # Sync in background (non-blocking if possible, but here blocking for simplicity)
                # For better UX, maybe just run it, it prints to console
                try:
                    self.holiday_mgr.sync_holidays(current_date["year"])
                except Exception as e:
                    print(f"Date: Holiday sync failed: {e}")
            
        self.draw_full()
        
    def hide(self):
        """Hide Date module (return to dashboard)"""
        self.active = False
        print("Date: Closing...")
        
    def update(self):
        """Update date display (call periodically)"""
        if not self.active:
            return
            
        # Get current date
        self.current_date = self._get_current_date()
        
        # Redraw
        self.draw_full()
        
    # draw_bold_text REMOVED per user request

    def draw_full(self):
        """Draw complete date interface"""
        # Clear screen (orange)
        self.lcd.fill(self.bg_color)
        
        # Draw header
        self._draw_header()
        
        # Get current date
        if not self.current_date:
            self.current_date = self._get_current_date()
            
        # 1. Analog calendar leaf (center-top)
        self._draw_calendar_leaf(160, 80, 60, self.current_date)
        
        # 2. Day name - Moved UP (125 -> 105) and simplified
        self._draw_date_text(self.current_date, y_pos=105)
        
        # 3. Progress section - Moved UP (160 -> 135)
        self._draw_progress_section(self.current_date, y_pos=135)
        
        # 4. Location info - REMOVED per user request
        # self._draw_location_info(y_pos=215)
        
        self.lcd.show()
        
    def _draw_header(self):
        """Draw header with back button and calendar system indicator"""
        # Back arrow + text (Highlight if selected_idx == 0)
        back_color = 0x07E0 if self.selected_idx == 0 else 0xFFFF
        self.lcd.text("< Back", 5, 5, back_color)
        
        # Calendar system indicator REMOVED per user request
        # Clean header with just Back button
        
        # Separator line (WHITE)
        self.lcd.hline(0, 20, 320, 0xFFFF)
        
    def _draw_calendar_leaf(self, center_x, center_y, size, date_data):
        """
        Draw analog calendar leaf (REPLACED with large text per user request)
        
        Args:
            center_x, center_y: Center coordinates
            size: Box size (not used anymore for drawing, but for relative positioning)
            date_data: dict with year, month, day info
        """
        # Get date components
        month_idx = date_data["month"] - 1
        month_str = self.months_short[month_idx].upper()
        day_str = str(date_data["day"])
        year_str = str(date_data["year"])
        
        # Format: "9 FEB 2026"
        display_str = f"{day_str} {month_str} {year_str}"
        
        # Use scale 3 for large font (same as weather module temperature)
        scale = 3
        # Center text: x = (320 - len*8*scale) // 2
        text_w = len(display_str) * (8 * scale)
        text_x = (320 - text_w) // 2
        text_y = center_y - (8 * scale) // 2
        
        # Draw scaled text
        self.draw_text_scaled(display_str, text_x, text_y, scale, self.text_color)

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        import framebuf
        # 1. Render text to a small temporary buffer
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source (RGB565 is 2 bytes)
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    # Draw 'size x size' block
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)
        
    def _draw_date_text(self, date_data, y_pos=125):
        """Draw enlarged day name"""
        # Day name (e.g., "Monday") - Enlarged with scale 2
        day_idx = date_data["weekday"]
        day_name = self.days[day_idx]
        
        scale = 2
        text_w = len(day_name) * (8 * scale)
        text_x = (320 - text_w) // 2
        
        self.draw_text_scaled(day_name, text_x, y_pos, scale, self.text_color)
        
        # Second full date removed per user request
        
    def _draw_progress_section(self, date_data, y_pos=160):
        """Draw year progress bar and day counter (No separator line)"""
        # Separator line REMOVED
        
        # Label: "2025 Progress"
        label = f"{date_data['year']} Progress"
        label_x = (320 - len(label) * 8) // 2
        self.lcd.text(label, label_x, y_pos + 5, self.text_color)
        
        # Calculate progress
        day_of_year = self._calculate_day_of_year(date_data)
        days_in_year = 366 if self._is_leap_year(date_data["year"]) else 365
        progress_pct = int((day_of_year / days_in_year) * 100)
        
        # Progress bar
        bar_x = 60
        bar_y = y_pos + 17
        bar_width = 200
        bar_height = 8
        
        # Empty bar (dark gray)
        self.lcd.fill_rect(bar_x, bar_y, bar_width, bar_height, self.progress_empty)
        
        # Filled bar (white)
        filled_width = int((bar_width * progress_pct) // 100)
        if filled_width > 0:
            self.lcd.fill_rect(bar_x, bar_y, filled_width, bar_height, self.text_color)
        
        # Percentage
        pct_str = f"{progress_pct}%"
        pct_x = bar_x + bar_width + 5
        self.lcd.text(pct_str, pct_x, bar_y, self.text_color)
        
        # Day counter
        counter_str = f"Day {day_of_year} / {days_in_year}"
        counter_x = (320 - len(counter_str) * 8) // 2
        self.lcd.text(counter_str, counter_x, y_pos + 30, self.text_color)
        
        # --- NEXT HOLIDAY DISPLAY (Below day counter) ---
        if self.holiday_mgr:
            next_holiday = self.holiday_mgr.get_next_holiday(
                date_data["year"], date_data["month"], date_data["day"]
            )
            
            if next_holiday:
                # Format: "Next: Holiday Name (Date)"
                # Date format in holiday object is "YYYY-MM-DD" -> extract MM-DD
                h_date = next_holiday['date'][5:] # "MM-DD"
                h_name = next_holiday['name']
                
                # Check if today
                today_str = f"{date_data['year']}-{date_data['month']:02d}-{date_data['day']:02d}"
                
                if next_holiday['date'] == today_str:
                    text = f"! {h_name} !"
                    color = self.accent_color # Magenta highlight
                else:
                    text = f"Next: {h_name} ({h_date})"
                    color = self.text_color
                    
                # Center text
                # Truncate if too long (max ~35 chars for small font, screen width 320)
                if len(text) > 38:
                    text = text[:35] + "..."
                    
                text_x = (320 - len(text) * 8) // 2
                self.lcd.text(text, text_x, y_pos + 50, color)
        
    def _draw_location_info(self, y_pos=215):
        """Draw location and timezone info (same as Clock module)"""
        # City, Country
        location = f"{self.city}, {self.country}"
        loc_x = (320 - len(location) * 8) // 2
        self.lcd.text(location, loc_x, y_pos, self.text_color)
        
        # Timezone
        tz_x = (320 - len(self.timezone) * 8) // 2
        self.lcd.text(self.timezone, tz_x, y_pos + 12, self.text_color)
        
    def _get_current_date(self):
        """Get current date from RTC"""
        time_data = self.rtc.get_time()
        return {
            "year": time_data["year"],
            "month": time_data["month"],
            "day": time_data["day"],
            "weekday": time_data["weekday"]
        }
        
    def _calculate_day_of_year(self, date_data):
        """Calculate day of year (1-366)"""
        year = date_data["year"]
        month = date_data["month"]
        day = date_data["day"]
        
        # Days in each month
        days_in_months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        
        # Adjust for leap year
        if self._is_leap_year(year):
            days_in_months[1] = 29
        
        # Sum days in previous months
        day_of_year = sum(days_in_months[:month-1]) + day
        return day_of_year
        
    def _is_leap_year(self, year):
        """Check if year is a leap year"""
        return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
        
    def _detect_timezone(self):
        """Auto-detect timezone from IP (same as Clock module)"""
        print("Date: Detecting timezone...")
        tz_data = self.tz_detector.detect()
        
        if tz_data:
            self.timezone = tz_data["timezone"]
            self.timezone_offset = tz_data["offset"]
            self.city = tz_data["city"]
            self.country = tz_data["country"]
            self.country_code = tz_data["country_code"]
            print(f"Date: Timezone -> {self.timezone} ({self.city}, {self.country})")
        else:
            print("Date: Timezone detection failed, using default")
            
    def toggle_calendar_system(self):
        """Toggle between calendar systems"""
        systems = ["gregorian", "hijri", "julian"]
        current_idx = systems.index(self.calendar_system)
        self.calendar_system = systems[(current_idx + 1) % len(systems)]
        print(f"Date: Calendar system -> {self.calendar_system}")
        
    def handle_encoder(self, direction):
        """Handle encoder rotation (Reserved for future)"""
        # For now only 1 item (Back), so index doesn't change
        # self.selected_idx = 0
        pass
        
    def handle_encoder_button(self):
        """Handle encoder button press (Activate selected item)"""
        if self.selected_idx == 0:
            # Back
            self.hide()
            return "dashboard"
        return None
        
    def handle_touch(self, x, y):
        """Handle touch events"""
        # Back button area (top-left)
        if x < 50 and y < 20:
            self.hide()
            return "dashboard"
            
        # Calendar system toggle REMOVED
        # Only Back button active
            
        return None
