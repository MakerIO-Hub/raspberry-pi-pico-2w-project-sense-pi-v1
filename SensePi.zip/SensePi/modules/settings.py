import os
import json
import time
import machine
import gc

class SettingsModule:
    def __init__(self, lcd, wifi_mgr, buzzer, rtc=None):
        self.lcd = lcd
        self.wifi_mgr = wifi_mgr
        self.buzzer = buzzer
        self.rtc = rtc
        self.settings_file = "data/settings.json"
        self.start_time = time.ticks_ms()
        
        # Default settings
        self.settings = {
            "brightness": 255,
            "timeout": 300, # 5 minutes in seconds
            "buzzer_volume": 100, # 0-100 percentage
        }
        
        self.load_settings()
        self.apply_settings()
        
        self.menu_items = [
            {"label": "Back", "type": "exit"},
            {"label": "Brightness", "key": "brightness", "type": "range", "min": 0, "max": 255, "step": 15},
            {"label": "Timeout", "key": "timeout", "type": "option", "options": [30, 60, 300, 600, 0], "labels": ["30s", "1m", "5m", "10m", "Never"]},
            {"label": "Buzzer Vol.", "key": "buzzer_volume", "type": "range", "min": 0, "max": 100, "step": 10},
            {"label": "WiFi Info", "type": "info"},
            {"label": "Sys Info", "type": "info"},
            {"label": "About", "type": "info"},
            {"label": "Restart", "type": "action", "func": self.restart_device},
            {"label": "Reset All", "type": "action", "func": self.reset_to_defaults}
        ]
        
        self.selected_idx = 0
        self.edit_mode = False
        self.sub_view = "menu" # "menu", "wifi_info", "sys_info"
        
    def load_settings(self):
        try:
            if "data" not in os.listdir():
                os.mkdir("data")
            
            with open(self.settings_file, "r") as f:
                loaded = json.load(f)
                self.settings.update(loaded)
        except:
            self.save_settings()

    def save_settings(self):
        try:
            with open(self.settings_file, "w") as f:
                json.dump(self.settings, f)
        except:
            print("Error saving settings")

    def apply_settings(self):
        # Apply Backlight
        if hasattr(self.lcd, 'bl'):
            try:
                # If PWM (machine.PWM)
                self.lcd.bl.duty_u16(int(self.settings["brightness"] * 65535 / 255))
            except:
                # If digital pin
                self.lcd.bl.value(1 if self.settings["brightness"] > 0 else 0)
        
        # Apply Buzzer Volume
        if self.buzzer:
            self.buzzer.set_volume(self.settings["buzzer_volume"])

    def show(self):
        self.sub_view = "menu"
        self.draw()

    def draw(self):
        if self.sub_view == "menu":
            self._draw_menu()
        elif self.sub_view == "wifi_info":
            self._draw_wifi_info()
        elif self.sub_view == "sys_info":
            self._draw_sys_info()
        elif self.sub_view == "about_info":
            self._draw_about_info()
        self.lcd.show()

    def _draw_menu(self):
        # Background: Orange (0xDD22)
        self.lcd.fill(0xDD22)
        
        # Header (Back button) - Highlight if selected (0)
        back_color = 0x07E0 if self.selected_idx == 0 else 0xFFFF # Green if on Back
        
        self.lcd.text("< Back", 5, 5, back_color)
        
        # Title (Centered)
        self.lcd.text("SETTINGS", 128, 5, 0xFFFF)
        
        # Separator Line
        self.lcd.hline(0, 20, 320, 0xFFFF)
        
        y_offset = 35
        for i, item in enumerate(self.menu_items[1:]): # Skip Back (index 0)
            idx = i + 1
            is_selected = (idx == self.selected_idx)
            color = 0xFFFF if is_selected else 0x0000
            
            if is_selected:
                # Highlight bar (20px height for better padding)
                # y_offset is text position (8px height)
                # Padding: (20 - 8) / 2 = 6px top/bottom
                self.lcd.fill_rect(5, y_offset - 6, 310, 20, 0x0000)
                color = 0xDD22 
            
            # Label (Indented slightly)
            self.lcd.text(item["label"], 15, y_offset, color)
            
            # Value (if applicable)
            value_str = ""
            if item["type"] == "range":
                value_str = str(self.settings[item["key"]])
            elif item["type"] == "option":
                try:
                    v = self.settings[item["key"]]
                    idx_opt = item["options"].index(v)
                    value_str = item["labels"][idx_opt]
                except: value_str = "Error"
            
            if self.edit_mode and is_selected:
                # Edit mode text also centered at y_offset
                self.lcd.text(f"< {value_str} >", 210, y_offset, 0x07E0) # Green for edit mode
            else:
                self.lcd.text(value_str, 240, y_offset, color)
                
            y_offset += 28 # Increased spacing for 20px bar height

    def _draw_wifi_info(self):
        self.lcd.fill(0x0000)
        self.lcd.text("WIFI INFO", 110, 10, 0xFFFF)
        self.lcd.hline(0, 25, 320, 0xFFFF)
        
        ssid = str(self.wifi_mgr.ssid) if self.wifi_mgr else "Unknown"
        status = "Connected" if self.wifi_mgr and self.wifi_mgr.is_connected() else "Disconnected"
        
        rssi = "N/A"
        try:
            import network
            sta_if = network.WLAN(network.STA_IF)
            rssi = f"{sta_if.status('rssi')} dBm"
        except: pass

        self.lcd.text(f"SSID: {ssid}", 20, 60, 0xFFFF)
        self.lcd.text(f"Status: {status}", 20, 80, 0xFFFF)
        self.lcd.text(f"Signal: {rssi}", 20, 100, 0xFFFF)
        
        self.lcd.text("< Back", 5, 215, 0x07E0)
        self.lcd.text("Press Button to Exit", 80, 215, 0xFFFF)

    def _draw_sys_info(self):
        gc.collect()
        free_ram = gc.mem_free() // 1024
        total_ram = (gc.mem_alloc() + gc.mem_free()) // 1024
        
        # Free Storage Calculation
        storage_str = "N/A"
        try:
            stat = os.statvfs('/')
            # free space = free blocks * block size
            free_bytes = stat[3] * stat[0]
            if free_bytes > 1024 * 1024:
                storage_str = "{:.2f} MB".format(free_bytes / (1024 * 1024))
            else:
                storage_str = "{} KB".format(free_bytes // 1024)
        except: pass

        temp = "N/A"
        try:
            sensor_temp = machine.ADC(machine.ADC.CORE_TEMP)
            reading = sensor_temp.read_u16() * (3.3 / 65535)
            temp_c = 27 - (reading - 0.706) / 0.001721
            temp = "{:.1f} C".format(temp_c)
        except: pass
        
        uptime_s = (time.ticks_ms() - self.start_time) // 1000
        uptime_h = uptime_s // 3600
        uptime_m = (uptime_s % 3600) // 60
        uptime_str = f"{uptime_h}h {uptime_m}m"

        self.lcd.fill(0x0000)
        self.lcd.text("SYSTEM INFO", 100, 10, 0xFFFF)
        self.lcd.hline(0, 25, 320, 0xFFFF)
        
        self.lcd.text(f"RAM: {free_ram}K / {total_ram}K", 20, 60, 0xFFFF)
        self.lcd.text(f"Free Storage: {storage_str}", 20, 80, 0xFFFF)
        self.lcd.text(f"CPU Temp: {temp}", 20, 100, 0xFFFF)
        self.lcd.text(f"Uptime: {uptime_str}", 20, 120, 0xFFFF)
        
        self.lcd.text("< Back", 5, 215, 0x07E0)
        self.lcd.text("Press Button to Exit", 80, 215, 0xFFFF)

    def _draw_about_info(self):
        self.lcd.fill(0x0000)
        self.lcd.text("ABOUT SENSEPI", 110, 10, 0xFFFF)
        self.lcd.hline(0, 25, 320, 0xFFFF)
        
        # User requested text
        self.lcd.text("SensePi v1.0", 20, 50, 0xFFFF)
        self.lcd.text("Developed by Huseyin Tekin", 20, 75, 0xFFFF) # Green for credits
        self.lcd.text("Smart Sensor & IoT Platform", 20, 100, 0xFFFF)
        self.lcd.text("v1.0.0 - Stable", 20, 125, 0xFFFF)
        
        self.lcd.text("Website: htekin.com", 20, 160, 0x039F) # Blue-ish link color
        self.lcd.text("Email: info@htekin.com", 20, 185, 0x039F)
        
        self.lcd.text("< Back", 5, 215, 0x07E0)
        self.lcd.text("Press Button to Exit", 80, 215, 0xFFFF)

    def handle_encoder(self, diff):
        if self.sub_view != "menu":
            return # Ignore encoder in info views for now, or use to exit
            
        if self.edit_mode:
            item = self.menu_items[self.selected_idx]
            if item["type"] == "range":
                val = self.settings[item["key"]]
                val += diff * item["step"]
                val = max(item["min"], min(val, item["max"]))
                self.settings[item["key"]] = val
                self.apply_settings()
            elif item["type"] == "option":
                idx = item["options"].index(self.settings[item["key"]])
                idx = (idx + diff) % len(item["options"])
                self.settings[item["key"]] = item["options"][idx]
        else:
            self.selected_idx = (self.selected_idx + diff) % len(self.menu_items)
        
        self.draw()

    def handle_button(self):
        if self.sub_view != "menu":
            self.sub_view = "menu"
            self.draw()
            return None
            
        item = self.menu_items[self.selected_idx]
        
        if item["type"] in ["range", "option"]:
            self.edit_mode = not self.edit_mode
            if not self.edit_mode:
                self.save_settings()
        elif item["type"] == "action":
            item["func"]()
        elif item["type"] == "info":
            if item["label"] == "WiFi Info":
                self.sub_view = "wifi_info"
            elif item["label"] == "Sys Info":
                self.sub_view = "sys_info"
            else:
                self.sub_view = "about_info"
        elif item["type"] == "exit":
            return "dashboard"
            
        self.draw()
        return None

    def handle_touch(self, x, y):
        if self.sub_view != "menu":
            # Any touch in sub-view area (or bottom back) returns to menu
            if y > 200:
                self.sub_view = "menu"
                self.draw()
            return None
            
        # Header is back button (y < 35, x < 60)
        if y < 35 and x < 60:
            self.selected_idx = 0
            return self.handle_button()
            
        # Check which item was clicked
        clicked_idx = ((y - 35) // 24) + 1
        if 1 <= clicked_idx < len(self.menu_items):
            if clicked_idx == self.selected_idx:
                return self.handle_button()
            else:
                self.selected_idx = clicked_idx
                self.draw()
        return None

    def restart_device(self):
        self.lcd.fill(0x0000)
        self.lcd.text("RESTARTING...", 100, 110, 0xF800)
        self.lcd.show()
        time.sleep(1)
        machine.reset()

    def reset_to_defaults(self):
        try: os.remove(self.settings_file)
        except: pass
        self.settings = {
            "brightness": 255,
            "timeout": 300,
            "buzzer_volume": 100,
        }
        self.apply_settings()
        self.save_settings()
        self.lcd.fill(0x07E0)
        self.lcd.text("RESET COMPLETE", 100, 110, 0x0000)
        self.lcd.show()
        time.sleep(1)
