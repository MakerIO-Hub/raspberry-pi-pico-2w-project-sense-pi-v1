import time
import os

class WeatherModule:
    def __init__(self, lcd, client, timezone_detector):
        self.lcd = lcd
        self.client = client
        self.tz_detector = timezone_detector
        self.visible = False
        
        # Colors
        self.bg_color = 0xdd22  # Orange
        self.text_color = 0xFFFF # White
        
        # State
        self.current_weather = None
        self.daily_forecast = None
        self.last_fetch = 0
        self.fetching = False
        self.status_message = "Init" # Debug status
        
        # Default Location
        self.location_name = "IZMIR"
        self.lat = 38.4237
        self.lon = 27.1428
        
    def show(self):
        self.visible = True
        self.draw()
        
        if time.time() - self.last_fetch > 1800:
            self.update()
            
    def hide(self):
        self.visible = False
        
    def update(self):
        self.fetching = True
        self.status_message = "Fetching..."
        self.draw() 
        try:
            # 1. Get Current
            current = self.client.get_current_weather(self.lat, self.lon)
            if current: 
                self.current_weather = current
            else:
                self.status_message = "Current W. Fail"

            # 2. Get 7-Day Forecast
            daily = self.client.get_daily_forecast(self.lat, self.lon, days=7)
            if daily: 
                self.daily_forecast = daily
            else:
                self.status_message = "Forecast Fail"
            
            if current and daily:
                 self.last_fetch = time.time()
                 self.status_message = "OK"
                 
        except Exception as e:
            self.status_message = f"Err: {str(e)[:15]}"
            print(f"Weather Update Error: {e}")
            
        self.fetching = False
        self.draw()
            
    def draw(self):
        if not self.visible: return
        
        self.lcd.fill(self.bg_color)
        
        # === HEADER SECTION (0-20px) ===
        # ONLY Back Button and Line
        self.lcd.text("< Back", 5, 5, self.text_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        if self.current_weather and self.daily_forecast:
            # ... (Existing drawing code omitted for brevity in search, but implied to be preserved)
            # This tool block only replaces the methods up to the start of the 'if' block usually
            # But here we are replacing the logic.
            # I must be careful with replace_file_content to match existing content exactly.
            pass 
            
        # ... logic continues ...
        
    # Redoing the replacement content to be valid for the tool:
    # I will replace the __init__ and update methods first, and then the else block of draw.
    
    # Actually, I'll allow multiple chunks or do a larger replace if contiguous.
    # The methods are contiguous.

        
        if self.current_weather and self.daily_forecast:
            # === LEFT PANEL: CURRENT WEATHER DETAILS (0-170px WIDTH) ===
            # Centered Alignment Logic: x = (170 - len*8) // 2
            
            # 1. IZMIR
            title = self.location_name
            t_x = (170 - len(title)*8) // 2
            self.lcd.text(title, t_x, 30, self.text_color)
            
            # 2. Monday, 9 Feb
            t = time.localtime()
            days_full = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            months = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            try:
                date_str = f"{days_full[t[6]]}, {t[2]} {months[t[1]]}"
                d_x = (170 - len(date_str)*8) // 2
                self.lcd.text(date_str, d_x, 45, self.text_color)
            except: pass
            
            # 3. ICON - Dynamic Centering
            wmo_code = self.current_weather.get("weather_code", 0)
            icon_name = self.client.get_weather_icon(wmo_code)
            icon_path = f"icons/{icon_name}"
            
            # Calculate icon width dynamically to center it
            try:
                stat = os.stat(icon_path)
                icon_size = int((stat[6] / 2) ** 0.5) # Square icon assumption
            except:
                icon_size = 50 # Fallback
            
            # Center: (170 - size) // 2
            icon_x = (170 - icon_size) // 2
            self.draw_bitmap(icon_path, icon_x, 65) 
            
            # 4. Temperature + Icon (24x24) - SCALED TEXT (3x)
            temp = round(self.current_weather.get('temperature', 0))
            temp_str = f"{temp}"
            
            # Dimensions
            # Scaled text: 8px * 3 = 24px width per char
            scale = 3
            digit_w = len(temp_str) * (8 * scale)
            gap = 8
            icon_w = 24 
            total_w = digit_w + gap + icon_w
            
            # Start X to center the group
            start_x = (170 - total_w) // 2
            
            # Draw Number SCALED
            # Font size 8x3=24px height. 
            self.draw_text_scaled(temp_str, start_x, 115, scale, self.text_color)
            
            # Draw Icon
            c_icon = "celsius.bin"
            if not self.file_exists(c_icon): c_icon = "icons/celsius.bin"
                 
            # Align with scaled text
            self.draw_bitmap(c_icon, start_x + digit_w + gap, 115)
            
            # 5. Overcast
            desc = self.client.get_weather_description(wmo_code)
            if len(desc) > 20: desc = desc[:18] + ".."
            dsc_x = (170 - len(desc)*8) // 2
            self.lcd.text(desc, dsc_x, 145, self.text_color)
            
            # 6. Wind: 2.1
            wind = self.current_weather.get("wind_speed", 0)
            wind_str = f"Wind: {wind}"
            wnd_x = (170 - len(wind_str)*8) // 2
            self.lcd.text(wind_str, wnd_x, 165, self.text_color)
            
            # 7. Hum: 77%
            hum = self.current_weather.get("humidity", 0)
            hum_str = f"Hum: {hum}%"
            hm_x = (170 - len(hum_str)*8) // 2
            self.lcd.text(hum_str, hm_x, 180, self.text_color)
            
            # 8. Rain: 45% (Precipitation Probability)
            # Get today's precip prob from daily forecast
            rain_prob = 0
            if self.daily_forecast and len(self.daily_forecast) > 0:
                rain_prob = self.daily_forecast[0].get("precip_prob", 0)
                
            rain_str = f"Rain: {rain_prob}%"
            rn_x = (170 - len(rain_str)*8) // 2
            self.lcd.text(rain_str, rn_x, 195, self.text_color)
            
            # 9. Last Update Time (Spacer needed)
            # Calculate elapsed time in minutes
            elapsed = int((time.time() - self.last_fetch) / 60)
            if elapsed < 0: elapsed = 0
            update_str = f"Updated {elapsed} min ago"
            
            # Center text
            upd_x = (170 - len(update_str)*8) // 2
            
            # Position: Rain is at 195. Text height 8.
            # Add gap of 20px -> Y = 223 (Might be too low, screen is 240)
            # Rain Y=195. Let's put this at Y=225 (Bottom edge)
            self.lcd.text(update_str, upd_x, 225, 0xF81F) # User color

            # === VERTICAL SEPARATOR (Shifted to 175) ===
            self.lcd.vline(175, 20, 220, self.text_color)

            # === RIGHT PANEL: 7-DAY FORECAST LIST (180-320px) ===
            # Header - Aligned with IZMIR (Y=30), No Line
            self.lcd.text("7-day Forecast", 185, 30, self.text_color)
            
            y_start = 60 # Increased gap (was 50)
            row_h = 25
            
            days_short = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            today_idx = t[6]
            
            for i, day_data in enumerate(self.daily_forecast):
                if i >= 7: break
                
                y = y_start + (i * row_h)
                
                d_idx = (today_idx + i) % 7
                day_name = days_short[d_idx]
                if i == 0: day_name = "Today"
                
                # Draw Day Name (Color Black 0x0000) "Mon:"
                self.lcd.text(f"{day_name}:", 185, y, 0x0000)
                
                t_max = round(day_data["temp_max"])
                t_min = round(day_data["temp_min"])
                
                # Draw Temps (White) "25/15" - Align at x=250?
                # Panel starts at 175. End 320. Width 145.
                # "Mon:" is ~32px wide.
                # "13/10" is ~40px wide.
                # Let's put temps at 185 + 60 = 245
                
                val_str = f"{t_max}/{t_min}"
                self.lcd.text(val_str, 245, y, self.text_color)
            
        else:
            # Show Status / Error
            if self.fetching:
                 self.lcd.text("Updating...", 100, 100, self.text_color)
                 self.lcd.text(self.status_message, 100, 120, 0xdd22)
            else:
                 self.lcd.text("No Data", 130, 80, self.text_color)
                 # Show specific error from update()
                 self.lcd.text(self.status_message, 80, 100, 0xF81F) 
                 
                 self.lcd.text("Check WiFi", 110, 130, 0x9999)
            
        self.lcd.show()

    def draw_bitmap(self, filename, x, y):
        try:
            stat = os.stat(filename)
        except OSError: return False
        
        side = int((stat[6] / 2) ** 0.5)
        w = 320
        bl = len(self.lcd.buffer)
        
        try:
            with open(filename, "rb") as f:
                for row in range(side):
                    sy = y + row
                    if sy >= 240: break
                    idx = ((sy * w) + x) * 2
                    d = f.read(side * 2)
                    if not d: break
                    if idx + len(d) <= bl:
                        self.lcd.buffer[idx:idx+len(d)] = d
            return True
        except:
            return False

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        # 1. Render text to a small temporary buffer
        import framebuf
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        # Simple nearest-neighbor scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source
                # RGB565 is 2 bytes
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    # Draw 'size x size' block
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)

    def file_exists(self, filename):
        try:
            os.stat(filename)
            return True
        except OSError:
            return False

    def handle_encoder_button(self):
        self.hide()
        return "dashboard"
        
    def handle_touch(self, x, y):
        if x < 60 and y < 40:
            self.hide()
            return "dashboard"
        if x < 160 and y > 150:
             self.update()
        return None
