import time

class CurrencyModule:
    # Constants for layout and colors
    BG_COLOR = 0xdd22        # Orange background
    TEXT_COLOR = 0xFFFF      # White
    CODE_COLOR = 0xF81F      # Magenta (USD, EUR, GBP)
    HEADER_COLOR = 0x0000    # Black
    ERROR_COLOR = 0xF800     # Red
    
    # Touch Zones
    BACK_BUTTON_W = 120      # Width of back button zone
    BACK_BUTTON_H = 80       # Height of back button zone
    UPDATE_ZONE_Y = 100      # Y coordinate where update zone starts

    # Encoder Navigation indices
    IDX_BACK = 0
    IDX_SOURCE = 1
    IDX_TARGET = 2

    def __init__(self, lcd, tcmb_driver):
        self.lcd = lcd
        self.driver = tcmb_driver
        self.visible = False
        
        # State
        self.last_fetch = 0
        self.rates = None
        self.fetching = False
        self.error_msg = None
        
        # Navigation State
        self.selected_index = 0 # 0:Back, 1:Source, 2:Target
        self.edit_mode = False  # True: Changing value of selected item
        
        # Converter State
        # Order: EUR, USD, GBP, TRY, then others
        self.available_currencies = ["EUR", "USD", "GBP", "TRY", "CHF", "JPY", "CAD", "AUD", "RUB"]
        self.conv_source = "EUR"
        self.conv_target = "TRY"

    def show(self):
        self.visible = True
        self.selected_index = 0 # Reset to Back button
        self.edit_mode = False
        self.draw()
        
        # Update if no data or stale (>1h)
        if not self.rates or (time.time() - self.last_fetch > 3600):
            self.update()
            
    def hide(self):
        self.visible = False
        
    def update(self):
        self.fetching = True
        self.draw() # Show "Updating..."
        
        try:
            data = self.driver.get_rates()
            if data:
                self.rates = data
                self.last_fetch = time.time()
                self.error_msg = None
            else:
                self.error_msg = "Connection Error"
        except Exception as e:
            self.error_msg = str(e)
            
        self.fetching = False
        self.draw()
            
    def draw(self):
        if not self.visible: return
        
        self.lcd.fill(self.BG_COLOR)
        
        # === HEADER ===
        # Back Button Style matches Clock Module (Green if selected, else White)
        back_color = 0x07E0 if self.selected_index == self.IDX_BACK else self.TEXT_COLOR
        self.lcd.text("< Back", 5, 5, back_color)
        
        self.lcd.hline(0, 20, 320, self.TEXT_COLOR)
        
        # === CONTENT ===
        if self.fetching:
            self.lcd.text("Updating...", 100, 110, self.TEXT_COLOR)
            self.lcd.show()
            return
            
        if self.error_msg:
            self.lcd.text("ERROR:", 10, 110, self.ERROR_COLOR)
            self.lcd.text(self.error_msg[:30], 10, 130, self.TEXT_COLOR)
            self.lcd.show()
            return
            
        if self.rates:
            self.draw_converter()
            
            # Footer: Refresh Hint
            # self.lcd.text("Touch Bottom to Refresh", 60, 220, self.HEADER_COLOR)
            
        else:
            self.lcd.text("No Data", 130, 110, self.TEXT_COLOR)
            self.lcd.text("Touch BELOW to Refresh", 70, 130, self.HEADER_COLOR)
            

        
        self.lcd.show()

    def draw_converter(self):
        # Title
        self.lcd.text("CONVERTER", 120, 40, self.HEADER_COLOR)
        
        # Determine Colors based on State
        source_color = self.TEXT_COLOR
        if self.selected_index == self.IDX_SOURCE:
            source_color = 0xF800 if self.edit_mode else 0x07E0
            
        target_color = self.TEXT_COLOR
        if self.selected_index == self.IDX_TARGET:
            target_color = 0xF800 if self.edit_mode else 0x07E0
        
        # Boxes (y=70 to give more space from result)
        box_y = 70
        
        # Source Box
        self.lcd.rect(20, box_y, 100, 40, source_color)
        if self.selected_index == self.IDX_SOURCE and self.edit_mode:
             self.lcd.rect(21, box_y+1, 98, 38, source_color) # Thicker
             
        self.lcd.text(self.conv_source, 50, box_y + 15, self.TEXT_COLOR)
        self.lcd.text("Source", 45, box_y + 45, self.HEADER_COLOR)
        self.lcd.text("v", 110, box_y + 15, self.TEXT_COLOR)
        
        # Target Box
        self.lcd.rect(200, box_y, 100, 40, target_color)
        if self.selected_index == self.IDX_TARGET and self.edit_mode:
             self.lcd.rect(201, box_y+1, 98, 38, target_color) # Thicker

        self.lcd.text(self.conv_target, 230, box_y + 15, self.TEXT_COLOR)
        self.lcd.text("Target", 225, box_y + 45, self.HEADER_COLOR)
        self.lcd.text("v", 290, box_y + 15, self.TEXT_COLOR)
        
        # Swap Icon (Center)
        self.lcd.text("<-->", 145, box_y + 15, self.CODE_COLOR)
        
        # Calculation
        try:
            # 1. Get Source Rate (in TRY)
            if self.conv_source == "TRY":
                s_rate = 1.0
            else:
                if self.conv_source in self.rates:
                    s_rate = self.rates[self.conv_source]["satis"]
                else:
                    s_rate = 0
                
            # 2. Get Target Rate (in TRY)
            if self.conv_target == "TRY":
                t_rate = 1.0
            else:
                if self.conv_target in self.rates:
                    t_rate = self.rates[self.conv_target]["satis"]
                else:
                    t_rate = 0
                
            # 3. Calculate Cross
            if t_rate > 0 and s_rate > 0:
                result = s_rate / t_rate
                
                # Format: "1 EUR = 34.5020 TRY"
                res_str = f"1 {self.conv_source} = {result:.4f} {self.conv_target}"
                
                # Centered Result
                res_x = (320 - (len(res_str) * 8)) // 2 
                
                # Display Result
                self.lcd.text(res_str, res_x, 160, self.TEXT_COLOR)
                
                # Date Display (Below result with spacing)
                # If API date is available, use it. Otherwise use System Date.
                date_str = ""
                if "tarih" in self.rates and self.rates["tarih"] not in ["Unknown", None, ""]:
                    date_str = self.rates["tarih"]
                else:
                    # Fallback to System Date
                    now = time.localtime()
                    # Format: DD.MM.YYYY
                    date_str = "{:02d}.{:02d}.{}".format(now[2], now[1], now[0])
                
                # Y=200 (Result 160 + Spacing 40)
                date_x = (320 - (len(date_str) * 8)) // 2
                self.lcd.text(date_str, date_x, 200, self.HEADER_COLOR)
                
            else:
                 self.lcd.text("Rate Error", 120, 160, self.ERROR_COLOR)
                 
        except Exception as e:
            self.lcd.text("Error", 140, 160, self.ERROR_COLOR)



    def handle_encoder_button(self):
        if self.selected_index == self.IDX_BACK:
            self.hide()
            return "dashboard"
            
        # For Source/Target items, Toggle Edit Mode
        if self.selected_index in [self.IDX_SOURCE, self.IDX_TARGET]:
            self.edit_mode = not self.edit_mode
            self.draw()
            return None
            
        return None
        
    def handle_encoder(self, direction):
        if self.edit_mode:
            # Context Sensitive Interaction (Change Value)
            try:
                if self.selected_index == self.IDX_SOURCE:
                    curr_idx = self.available_currencies.index(self.conv_source)
                    next_idx = (curr_idx + direction) % len(self.available_currencies)
                    self.conv_source = self.available_currencies[next_idx]
                    
                elif self.selected_index == self.IDX_TARGET:
                    curr_idx = self.available_currencies.index(self.conv_target)
                    next_idx = (curr_idx + direction) % len(self.available_currencies)
                    self.conv_target = self.available_currencies[next_idx]
                
                self.draw()
            except: pass
            
        else:
            # Navigation (Change Focus)
            # Cycle 0->1->2->0
            self.selected_index = (self.selected_index + direction) % 3
            self.draw()

    def handle_touch(self, x, y):
        # 1. Back Butonu (Genişletilmiş Alan)
        if x < self.BACK_BUTTON_W and y < self.BACK_BUTTON_H:
            self.hide()
            return "dashboard"
            
        # 2. Update / Refresh (Bottom Area)
        if y > 200:
            self.update()
            return None
            
        # 3. Converter Interaction
        # Adjusted coordinates for new box positions (y=70 to y=110)
        
        # Source Box (20, 70, 100, 40)
        if x > 10 and x < 130 and y > 60 and y < 120:
             self.selected_index = self.IDX_SOURCE
             # Cycle directly on touch
             try:
                 curr_idx = self.available_currencies.index(self.conv_source)
                 next_idx = (curr_idx + 1) % len(self.available_currencies)
                 self.conv_source = self.available_currencies[next_idx]
                 self.draw()
             except: pass
            
        # Target Box (200, 70, 100, 40)
        elif x > 190 and x < 310 and y > 60 and y < 120:
             self.selected_index = self.IDX_TARGET
             # Cycle directly on touch
             try:
                 curr_idx = self.available_currencies.index(self.conv_target)
                 next_idx = (curr_idx + 1) % len(self.available_currencies)
                 self.conv_target = self.available_currencies[next_idx]
                 self.draw()
             except: pass
            
        # Swap (Center)
        elif x > 130 and x < 190 and y > 60 and y < 120:
            # Swap
            self.conv_source, self.conv_target = self.conv_target, self.conv_source
            self.draw()
            
        return None
