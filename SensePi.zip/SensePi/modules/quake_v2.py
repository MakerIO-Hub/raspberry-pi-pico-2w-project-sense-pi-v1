import time

class QuakeModule:
    def __init__(self, lcd, quake_api, buzzer=None, early_warning_threshold=3.0):
        self.lcd = lcd
        self.api = quake_api
        self.buzzer = buzzer
        self.threshold = early_warning_threshold
        
        self.current_country = "GL" # Default: Global
        self.events = []
        self.last_update = 0
        self.update_interval = 60000 # 1 minute (Fast mode)
        self.visible = False
        
        # UI State
        self.selected_index = 0
        self.scroll_offset = 0
        self.view_mode = "LIST" # LIST, WARNING, SETTINGS
        self.warning_active = False
        self.latest_alert_event = None # For global alert screen
        
        # Colors
        self.COLOR_GREEN = 0x07E0
        self.COLOR_YELLOW = 0xFFE0
        self.COLOR_ORANGE = 0xFD20
        self.COLOR_RED = 0xF800
        self.COLOR_TEXT = 0xFFFF # Visual Black (Code White due to inversion)
        self.COLOR_BG = 0xdd22   # Standard Orange BG
        self.COLOR_HEADER_TXT = 0xFFFF # Visual Black
        self.COLOR_SEPARATOR = 0xFFFF # Visual Black

    def show(self):
        """Draw screen initially"""
        self.visible = True
        self.lcd.fill(self.COLOR_BG) # Make whole screen orange
        self.view_mode = "LIST"
        self.scroll_offset = 0 # Reset scroll on open
        self.draw_header()
        self.draw_list()
        self.lcd.show() # Force update immediately (buffer flush)
        
        if not self.events or (time.ticks_ms() - self.last_update > self.update_interval):
            self.update()

    def hide(self):
        self.visible = False
        self.warning_active = False # Reset warning if hiding

    def update(self):
        """Fetch data from API and update list"""
        # Update list area only (Y=21+)
        self.lcd.fill_rect(0, 21, 320, 219, self.COLOR_BG)
        self.lcd.text("Checking...", 120, 120, self.COLOR_TEXT)
        self.lcd.show()
        
        try:
            # API Call
            new_events = self.api.get_quakes(self.current_country, limit=20)
            if new_events:
                # Check for updates
                if self.events and new_events[0].timestamp > self.events[0].timestamp:
                    # New quake!
                    latest = new_events[0]
                    # Check if it triggers warning (M >= 2.5)
                    if latest.magnitude >= 2.5:
                        self.trigger_early_warning(latest)
                        return True # Signal main.py to switch to alert view
                    
                self.events = new_events
                self.scroll_offset = 0 # Reset scroll on new data
                self.last_update = time.ticks_ms()
            else:
                self.lcd.text("No Data!", 120, 140, self.COLOR_TEXT) 
                self.lcd.show()
                time.sleep(1)
                
        except Exception as e:
            print(f"Quake Update Error: {e}")
            self.lcd.text("Connection Error!", 90, 140, self.COLOR_TEXT) 
            self.lcd.show()
            time.sleep(1)
            
        # Refresh UI
        self.draw_list()
        self.lcd.show() 
        return False

    # ... check_background ...

    def trigger_early_warning(self, event):
        """Register alert event to be picked up by main.py"""
        print(f"EARLY WARNING: {event.location} M{event.magnitude}")
        self.latest_alert_event = event
        # We do NOT block here anymore. main.py handles the 'quake_alert' view.
    def check_background(self):
        """Check for updates silently (without UI changes)"""
        # Only check if interval passed
        if time.ticks_ms() - self.last_update < self.update_interval:
            return False
            
        print("Quake: Background checking...")
        try:
            # API Call (Silent)
            new_events = self.api.get_quakes(self.current_country, limit=20)
            if new_events:
                # Check for updates
                if self.events and new_events[0].timestamp > self.events[0].timestamp:
                    # New quake!
                    latest = new_events[0]
                    self.events = new_events
                    self.scroll_offset = 0
                    self.last_update = time.ticks_ms()
                    
                    # Check if it triggers warning (M >= 2.5 as requested)
                    if latest.magnitude >= 2.5:
                         self.latest_alert_event = latest
                         return True # Switch to alert mode!
            
            self.last_update = time.ticks_ms() 
            
        except Exception as e:
            print(f"Quake Background Error: {e}")
            
        return False

    def parse_location(self, location_str):
        """Parse Location: 'City, Country'"""
        if "," in location_str:
            parts = location_str.rsplit(",", 1)
            raw_city = parts[0].strip()
            country = parts[1].strip()[:20] 
            
            # Cleanup City: Remove "10 km E of " etc.
            if " of " in raw_city:
                city = raw_city.split(" of ")[-1].strip()
            else:
                city = raw_city
            
            city = city[:20] 
        else:
            city = location_str[:20]
            country = "Region"
        return country, city

    def trigger_early_warning(self, event):
        self.view_mode = "WARNING"
        self.warning_active = True
        
        # Red Flash Screen and Alarm
        # Play for 10 seconds or until user intervention (not implemented here yet)
        start_time = time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(), start_time) < 10000: # 10 sec
            self.lcd.fill(self.COLOR_RED)
            self.lcd.text("! EARLY WARNING !", 60, 80, 0xFFFF) # White on Red
            self.lcd.text(f"MAGNITUDE: {event.magnitude}", 80, 110, 0xFFFF) # White on Red
            self.lcd.text(event.location[:20], 40, 140, 0xFFFF) # White on Red
            self.lcd.show()
            
            if self.buzzer: self.buzzer.start() # Continuous beep
            time.sleep(0.5)
            
            self.lcd.fill(0x0000) # Black flash
            self.lcd.show()
            if self.buzzer: self.buzzer.stop()
            time.sleep(0.2)
            
        # Return to list mode
        self.view_mode = "LIST"
        self.warning_active = False
        self.show()

    def draw_header(self):
        # Background is orange
        
        # Back arrow (BLACK)
        self.lcd.text("<", 5, 5, self.COLOR_HEADER_TXT)
        
        # "Back" text (BLACK)
        self.lcd.text("Back", 25, 5, self.COLOR_HEADER_TXT)
        
        # TITLE REMOVED AS REQUESTED
        
        # Separator Line (BLACK)
        self.lcd.hline(0, 20, 320, self.COLOR_SEPARATOR)

    def draw_list(self):
        if self.view_mode != "LIST": return
        
        # Clear list area
        self.lcd.fill_rect(0, 21, 320, 219, self.COLOR_BG)
        
        start_y = 25 # Header ends at Y=20
        item_height = 50 # Increased for 3 lines
        
        # Scroll slice
        visible_items = self.events[self.scroll_offset : self.scroll_offset + 5]
        print(f"DEBUG: Draw List with {len(self.events)} events. Visible: {len(visible_items)}")
        
        for i, event in enumerate(visible_items):
            y = start_y + (i * item_height)
            
            # Color coding
            color = self.COLOR_GREEN
            if event.magnitude >= 6.0: color = self.COLOR_RED
            elif event.magnitude >= 4.5: color = self.COLOR_ORANGE
            elif event.magnitude >= 3.0: color = self.COLOR_YELLOW
            
            # Magnitude Box (Centered Vertically in 50px row)
            # Box height 34. (50-34)/2 = 8. So Y + 8.
            box_y = y + 8
            self.lcd.fill_rect(10, box_y, 34, 34, color)
            
            mag_str = f"{event.magnitude:.1f}"
            
            # Center text in 34x34 box (Font 8x8)
            text_w = len(mag_str) * 8
            text_x = 10 + (34 - text_w) // 2
            text_y = box_y + (34 - 8) // 2
            
            # Text color inside box: Yellow/Green -> Visual Black (0xFFFF), Orange/Red -> Visual White (0x0000)
            mag_txt_color = 0xFFFF if (color == self.COLOR_YELLOW or color == self.COLOR_GREEN) else 0x0000
            self.lcd.text(mag_str, text_x, text_y, mag_txt_color)
            
            # --- Layout 3-Line (Updated) ---
            # Line 1: Country (at Y+9)
            # Line 2: City (at Y+20)
            # Line 3: Depth - Time (at Y+31)
            
            # Parse Location: "City, Country"
            if "," in event.location:
                parts = event.location.rsplit(",", 1)
                raw_city = parts[0].strip()
                country = parts[1].strip()[:20] 
                
                # Cleanup City: Remove "10 km E of " etc.
                if " of " in raw_city:
                    city = raw_city.split(" of ")[-1].strip()
                else:
                    city = raw_city
                
                city = city[:20] 
            else:
                city = event.location[:20]
                country = "Region" # Default if no comma
            
            # Line 1: Country
            self.lcd.text(f"Country: {country}", 55, y + 9, 0xFFFF)
            
            # Line 2: City
            self.lcd.text(f"City: {city}", 55, y + 20, 0xFFFF)
            
            # Line 3: Depth - Time
            t = time.localtime(event.timestamp + 10800) # UTC+3 assumption
            details_str = "Depth: {:.1f}km - Time: {:02d}:{:02d}".format(event.depth, t[3], t[4])
            self.lcd.text(details_str, 55, y + 31, 0xFFFF) 
            
            # Separator line
            self.lcd.hline(10, y + item_height - 1, 300, 0xFFFF)
            
        self.lcd.show() # Force update after drawing list

    def handle_touch(self, x, y):
        """Touch controls"""
        # Back Button (Top Left)
        if y < 30 and x < 50:
            return "dashboard"
            
        # List Scroll (Simple: Top half up, bottom half down)
        if y > 30:
            if y < 140: # Scroll Up
                if self.scroll_offset > 0:
                    self.scroll_offset -= 1
                    self.draw_list()
            else: # Scroll Down
                if self.scroll_offset < len(self.events) - 5:
                    self.scroll_offset += 1
                    self.draw_list()
                    
        return None

    def handle_encoder(self, diff):
        """Encoder scroll"""
        if diff > 0: # Down
             if self.scroll_offset < len(self.events) - 5:
                self.scroll_offset += 1
                self.draw_list()
        else: # Up
            if self.scroll_offset > 0:
                self.scroll_offset -= 1
                self.draw_list()

    def handle_button(self):
        """Encoder button -> Refresh"""
        self.update() 
        return None
