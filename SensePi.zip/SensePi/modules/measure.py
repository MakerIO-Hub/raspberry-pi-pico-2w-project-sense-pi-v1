import time
import framebuf
from drivers.hcsr04 import HCSR04

class MeasureModule:
    """
    Measure Module for SensePi.
    Features: Precise Distance Measurement, Save Log, Reset Button.
    """
    def __init__(self, lcd, buzzer=None, encoder_button_func=None):
        self.lcd = lcd
        self.buzzer = buzzer
        # Fixed Pins: TRIG=6, ECHO=7
        self.sensor = HCSR04(trigger_pin=6, echo_pin=7)
        
        # UI Settings
        self.bg_color = 0xdd22       # Orange background (Same as Sensors)
        self.text_color = 0xFFFF      # White
        self.header_height = 25
        
        # Measurement Variables
        self.last_update = 0
        self.current_dist = 0.0
        self.history = []     # For smoothing (precision)
        self.history_len = 5  # Moving average window
        
        # Saved Measurements Log
        self.saved_measurements = []
        self.max_saved = 5    # Keep list short for display
        
        # Reset Button Zone
        self.reset_btn_rect = (230, 190, 80, 40) # x, y, w, h
        
        # Initial Draw Flag
        self.needs_redraw = True
        
        # Encoder Selection: 0=Back, 1=Save (Default), 2=Reset
        self.selected_option = 1

    def show(self):
        """Initial screen draw"""
        print("DEBUG: Entering MeasureModule.show()")
        self.selected_option = 1 # Always start at Center (Save)
        self.needs_redraw = True
        self.update(force=True)

    def draw_interface(self):
        # 1. Clear Screen (Orange Background)
        self.lcd.fill(self.bg_color)
        
        # 2. Header (Back Button)
        self.lcd.text("< Back", 5, 5, self.text_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        # 3. Main Measurement Display (Large & Centered)
        # We simulate large text by drawing a box for now, or just text
        # Since we don't have large fonts yet, we'll center it nicely
        pass # Drawn in update loop to avoid flicker

    def update(self, force=False):
        # Update frequency: 500ms (2Hz) for smooth but stable reading
        if not force and time.ticks_diff(time.ticks_ms(), self.last_update) < 500:
            return

        # 1. Get Precise Reading (Averaging)
        raw_dist = self.sensor.measure_cm()
        if raw_dist > 0:
            # Calibration: 
            # 20cm (act) was showing 16cm (raw)
            # 10cm (act) was showing 11cm (with 1.25x) -> raw was 8.8cm
            # Solution: dist = (raw * 1.39) - 2.2
            calibrated_dist = (raw_dist * 1.39) - 2.2
            
            # Clamp to 0
            if calibrated_dist < 0: calibrated_dist = 0
            
            self.history.append(calibrated_dist)
            if len(self.history) > self.history_len:
                self.history.pop(0)
            
            # Simple average for stability
            self.current_dist = sum(self.history) / len(self.history)
        else:
            # Keep last valid reading or show error if consistent failure
            pass

        self.last_update = time.ticks_ms()
        
        # --- DRAWING ---
        if self.needs_redraw:
            # Redraw static elements only once
            self.draw_static_elements()
            self.needs_redraw = False
            
        # 2. Clear Measurement Area (Top Half)
        self.lcd.fill_rect(0, 30, 320, 110, self.bg_color)
        
        # 3. Draw Main Distance Value (GIGANTIC & CENTERED)
        dist_str = f"{self.current_dist:.1f} cm"
        
        # Scaling settings (Scale 5 is massive, like a pro tool)
        scale = 5 
        text_w = len(dist_str) * (8 * scale)
        text_x = (320 - text_w) // 2
        text_y = 50 # Centered perfectly in the top half
        
        self.draw_text_scaled(dist_str, text_x, text_y, scale, self.text_color)
        
        # 4. Draw Saved List (Bottom Area)
        # Clear list area first
        self.lcd.fill_rect(20, 150, 200, 60, self.bg_color)
        
        y_pos = 150
        self.lcd.text("SAVED LOG:", 20, y_pos, 0x0000) # Black label for contrast
        y_pos += 12
        
        for idx, val in enumerate(self.saved_measurements[:4]): # Show last 4 for space
            self.lcd.text(f"{idx+1}. {val:.1f} cm", 20, y_pos, 0xFFFF)
            y_pos += 11
            
        self.lcd.show()

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        import framebuf
        # 1. Render text to a small temporary buffer
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source (RGB565 is 2 bytes)
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)
        
        del buf # Clear buffer immediately
    def draw_static_elements(self):
        self.lcd.fill(self.bg_color)
        
        # HEADER (BACK) - Option 0
        # Style: Yellow Text if selected, White if not. No Box background.
        back_color = 0xFFE0 if self.selected_option == 0 else self.text_color
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        # RESET BUTTON - Option 2
        rx, ry, rw, rh = self.reset_btn_rect
        if self.selected_option == 2:
            # Highlighted (White BG, Red Text)
            self.lcd.fill_rect(rx, ry, rw, rh, 0xFFFF)
            self.lcd.rect(rx, ry, rw, rh, 0xF800)
            self.lcd.text("RESET", rx + 20, ry + 16, 0xF800)
        else:
            # Normal (Red BG, White Text)
            self.lcd.fill_rect(rx, ry, rw, rh, 0xF800)
            self.lcd.rect(rx, ry, rw, rh, 0xFFFF)
            self.lcd.text("RESET", rx + 20, ry + 16, 0xFFFF)

    def handle_encoder(self, diff):
        # Cycle: 0(Back) <-> 1(Save/Center) <-> 2(Reset)
        self.selected_option += diff
            
        # Clamp between 0 and 2
        if self.selected_option > 2: self.selected_option = 2
        if self.selected_option < 0: self.selected_option = 0
            
        self.needs_redraw = True

    def handle_encoder_button(self):
        if self.selected_option == 0:
            return "dashboard" # Exit
        elif self.selected_option == 2:
            self.saved_measurements = [] # Clear List
            self.needs_redraw = True
        elif self.selected_option == 1:
            # SAVE LOG
            if self.current_dist > 0:
                self.saved_measurements.insert(0, self.current_dist)
                if len(self.saved_measurements) > self.max_saved:
                    self.saved_measurements.pop()
                self.needs_redraw = True
        return None

    def handle_touch(self, x, y):
        # 1. Check Back Button (< 80, < 40)
        if x < 80 and y < 40:
            return "dashboard"
            
        # 2. Check Reset Button
        rx, ry, rw, rh = self.reset_btn_rect
        if rx <= x <= rx + rw and ry <= y <= ry + rh:
            self.saved_measurements = [] # Clear List
            self.needs_redraw = True # Trigger full redraw to clear list
            return None
            
        return None
