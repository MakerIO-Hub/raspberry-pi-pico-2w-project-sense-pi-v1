import time

class AlarmModule:
    def __init__(self, lcd, mgr):
        self.lcd = lcd
        self.mgr = mgr  # AlarmManager instance
        self.visible = False
        
        # Colors
        self.bg_color = 0xdd22  # Orange
        self.text_color = 0xFFFF  # White
        self.active_color = 0xFE60 # Yellow-green (ON)
        self.inactive_color = 0xF81F # Magenta (OFF)
        self.button_color = 0x4208  # Dark gray for buttons
        
        # State
        self.mode = "main"  # "main", "add", "edit"
        self.editing_id = None  # ID of alarm being edited
        self.temp_hour = 7
        self.temp_minute = 0
        
        # Dropdown state
        self.dropdown_active = None  # "hour" or "minute" or None
        self.dropdown_scroll = 0  # Scroll offset for dropdown list
        
        # Encoder selection state
        # MAIN MODE: 0: Back, 1: Plus, 2+: Alarms
        # ADD/EDIT MODE: 0: Hour, 1: Minute, 2: Cancel, 3: Save
        self.selected_index = 0
        self.editing_time = None # None, "hour", "minute" (for encoder adjustment)
        
        # Limit warning
        self.show_limit_warning = False
        self.warning_start_time = 0
        
    def show(self):
        self.visible = True
        self.mode = "main"
        self.selected_index = 0
        self.editing_time = None
        self.draw()
        
    # ... (skipping unchanged parts) ...

    def handle_button(self):
        """Handle rotary encoder button press"""
        if self.mode == "main":
            if self.selected_index == 0:  # Back
                self.hide()
                return "dashboard"
                
            elif self.selected_index == 1:  # + Button
                # Check limit
                if self.mgr.get_alarm_count() >= 3:
                    self.show_limit_warning = True
                    self.warning_start_time = time.time()
                    self.draw_main()
                else:
                    self.mode = "add"
                    self.dropdown_active = None
                    self.selected_index = 0 # Start at Hour
                    self.editing_time = None
                    self.temp_hour = 7
                    self.temp_minute = 0
                    self.draw_add()
                    
            else:  # Alarm Actions (index 2+)
                # Determine which alarm and which action
                # Indices: 2,3 -> Alarm 0
                #          4,5 -> Alarm 1
                #          6,7 -> Alarm 2
                adjusted_idx = self.selected_index - 2
                alarm_idx = adjusted_idx // 2
                action = adjusted_idx % 2 # 0=Toggle, 1=Delete
                
                alarms = self.mgr.get_alarms()
                if 0 <= alarm_idx < len(alarms):
                    alarm_id = alarms[alarm_idx]["id"]
                    
                    if action == 0: # Toggle
                        self.mgr.toggle_alarm(alarm_id)
                        self.draw_main()
                        
                    elif action == 1: # Delete
                        self.mgr.delete_alarm(alarm_id)
                        # Fix index shift after deletion
                        # If we deleted something, max index decreases by 2
                        # Go back to Plus button for safety or clamp
                        self.selected_index = 1 
                        self.draw_main()
                        
        elif self.mode == "add" or self.mode == "edit":
            print(f"DEBUG: handle_button in ADD/EDIT mode. Index={self.selected_index}, Editing={self.editing_time}")
            # 0:Hour, 1:Minute, 2:Cancel, 3:Save
            if self.selected_index == 0: # Hour
                if self.editing_time == "hour":
                    print("DEBUG: Confirming Hour")
                    self.editing_time = None # Confirm
                else:
                    print("DEBUG: Editing Hour")
                    self.editing_time = "hour" # Start editing
                self.draw_add()
                
            elif self.selected_index == 1: # Minute
                if self.editing_time == "minute":
                    print("DEBUG: Confirming Minute")
                    self.editing_time = None # Confirm
                else:
                    print("DEBUG: Editing Minute")
                    self.editing_time = "minute" # Start editing
                self.draw_add()
                
            elif self.selected_index == 2: # Cancel
                print("DEBUG: Cancel pressed")
                self.mode = "main"
                self.selected_index = 0
                self.draw_main()
                
            elif self.selected_index == 3: # Save
                print("DEBUG: Save pressed")
                if self.mode == "add":
                    self.mgr.add_alarm(self.temp_hour, self.temp_minute)
                elif self.mode == "edit":
                    self.mgr.update_alarm(self.editing_id, self.temp_hour, self.temp_minute)
                self.mode = "main"
                self.selected_index = 0
                self.draw_main()
        
    def hide(self):
        self.visible = False
        
    def draw(self):
        """Main draw dispatcher"""
        if self.mode == "main":
            self.draw_main()
        elif self.mode == "add":
            self.draw_add()
        elif self.mode == "edit":
            self.draw_edit()
            
    def draw_main(self):
        """Draw main alarm list screen"""
        self.lcd.fill(self.bg_color)
        
        # Header (Back button) - Highlight if selected (0)
        back_color = self.active_color if self.selected_index == 0 else self.text_color
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        # Large + Button (80x80 square, centered)
        plus_x = 120
        plus_y = 30
        plus_size = 80
        
        # Highlight + button if selected (1)
        if self.selected_index == 1:
            # Draw thick border (3 pixels wide) instead of fill
            self.lcd.rect(plus_x - 3, plus_y - 3, plus_size + 6, plus_size + 6, self.active_color)
            self.lcd.rect(plus_x - 2, plus_y - 2, plus_size + 4, plus_size + 4, self.active_color)
            self.lcd.rect(plus_x - 1, plus_y - 1, plus_size + 2, plus_size + 2, self.active_color)
        
        self.lcd.rect(plus_x, plus_y, plus_size, plus_size, self.text_color)
        # Draw large + symbol (centered in square) - yellow-green color
        # Horizontal line of +
        self.lcd.hline(plus_x + 25, plus_y + 40, 30, 0xFE60)
        self.lcd.hline(plus_x + 25, plus_y + 39, 30, 0xFE60)
        self.lcd.hline(plus_x + 25, plus_y + 41, 30, 0xFE60)
        # Vertical line of +
        self.lcd.vline(plus_x + 40, plus_y + 25, 30, 0xFE60)
        self.lcd.vline(plus_x + 39, plus_y + 25, 30, 0xFE60)
        self.lcd.vline(plus_x + 41, plus_y + 25, 30, 0xFE60)
        
        # Alarm count text below + button (centered)
        alarm_count = self.mgr.get_alarm_count()
        count_text = f"{alarm_count}/3 Alarms"
        # Center text: 320/2 - (len * 4) = 160 - len*4
        count_x = 160 - (len(count_text) * 4)
        self.lcd.text(count_text, count_x, 115, self.text_color)
        
        # Alarm List
        alarms = self.mgr.get_alarms()
        if len(alarms) == 0:
            # No alarms message (centered, under count)
            self.lcd.text("Press + to add", 95, 135, self.text_color)
            self.lcd.text("a new alarm", 105, 150, self.text_color)
        else:
            # Draw each alarm (adjusted to fit 3 alarms on screen)
            y_start = 140
            row_height = 33
            
            for i, alarm in enumerate(alarms):
                y = y_start + (i * row_height)
                # Calculate selection for this row
                # Row index base = 2 + (i * 2)
                # Toggle index = base
                # Del index = base + 1
                base_idx = 2 + (i * 2)
                sel_type = None # None, "toggle", "del"
                
                if self.selected_index == base_idx:
                    sel_type = "toggle"
                elif self.selected_index == base_idx + 1:
                    sel_type = "del"
                    
                self._draw_alarm_item(alarm, y, sel_type)
        
        # Limit warning (if active)
        if self.show_limit_warning:
            # Check if 2 seconds passed
            if time.time() - self.warning_start_time > 2:
                self.show_limit_warning = False
                self.draw_main()  # Redraw without warning
            else:
                # Draw warning message at bottom
                self.lcd.fill_rect(10, 210, 300, 25, 0xF800)  # Red background
                self.lcd.text("Max 3 alarms", 95, 218, 0xFFFF)
                
        self.lcd.show()
        
    def _draw_alarm_item(self, alarm, y, sel_type=None):
        """Draw a single alarm list item with ON/OFF toggle"""
        # Time display (normal weight, no overlay)
        time_str = f"{alarm['hour']:02d}:{alarm['minute']:02d}"
        self.lcd.text(time_str, 20, y + 5, self.text_color)
        
        # ON/OFF Toggle
        toggle_x = 100
        toggle_w = 35
        toggle_h = 20
        toggle_color = self.active_color if alarm['enabled'] else self.inactive_color
        toggle_text = "ON" if alarm['enabled'] else "OFF"
        
        # Highlight Toggle if selected
        if sel_type == "toggle":
            self.lcd.fill_rect(toggle_x - 2, y - 2, toggle_w + 4, toggle_h + 4, 0xFFFF) # White border
            
        self.lcd.fill_rect(toggle_x, y, toggle_w, toggle_h, toggle_color)
        self.lcd.rect(toggle_x, y, toggle_w, toggle_h, self.text_color)
        
        # Center text horizontally
        # Assuming font width is roughly 8px per char
        text_w = len(toggle_text) * 8
        text_x = toggle_x + (toggle_w - text_w) // 2
        
        self.lcd.text(toggle_text, text_x, y + 6, 0x0000)
        
        # DELETE Button (right side) - magenta color
        del_x = 220
        del_w = 60
        del_h = 25
        
        # Highlight Delete if selected
        if sel_type == "del":
             self.lcd.fill_rect(del_x - 2, y - 2, del_w + 4, del_h + 4, 0xFFFF) # White border
        
        self.lcd.fill_rect(del_x, y, del_w, del_h, 0xF81F)  # Magenta RGB565
        self.lcd.rect(del_x, y, del_w, del_h, self.text_color)
        self.lcd.text("DEL", del_x + 18, y + 8, 0xFFFF)
        
    def draw_add(self):
        """Draw add/edit alarm screen with dropdown selectors"""
        self.lcd.fill(self.bg_color)
        
        # Header - Center the title
        title = "NEW ALARM" if self.editing_id is None else "EDIT ALARM"
        # Calculate center position (8px per char)
        title_w = len(title) * 8
        title_x = (320 - title_w) // 2
        
        self.lcd.text(title, title_x, 5, self.text_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        # Dropdown boxes for Hour and Minute - Center them together
        dropdown_w = 60
        dropdown_h = 30
        dropdown_y = 50
        gap = 60  # Space between hour and minute
        total_width = dropdown_w + gap + dropdown_w  # 180px
        start_x = (320 - total_width) // 2  # 70px
        
        hour_x = start_x
        minute_x = start_x + dropdown_w + gap
        
        # Draw Hour dropdown
        # Highlight logic
        hour_fill = self.bg_color # Default fill
        
        # Draw base box
        self.lcd.fill_rect(hour_x, dropdown_y, dropdown_w, dropdown_h, hour_fill)
        self.lcd.rect(hour_x, dropdown_y, dropdown_w, dropdown_h, self.text_color)
        
        # Highlight if selected
        if self.selected_index == 0:
            # Draw Thick Border for Selection
            # Using active_color (Yellow-Green) so it stands out
            self.lcd.rect(hour_x - 3, dropdown_y - 3, dropdown_w + 6, dropdown_h + 6, self.active_color)
            self.lcd.rect(hour_x - 2, dropdown_y - 2, dropdown_w + 4, dropdown_h + 4, self.active_color)
            
            # Check Edit State
            if self.editing_time == "hour":
                 # Red Fill if editing
                 self.lcd.fill_rect(hour_x, dropdown_y, dropdown_w, dropdown_h, 0xF800)
                 # Visual Cue: Show "CHANGE" below
                 self.lcd.text("CHANGE", hour_x, dropdown_y + 35, 0xF800)
                 self.lcd.text("^ v", hour_x + 15, dropdown_y + 45, 0xF800)
        
        hour_text = f"{self.temp_hour:02d}"
        # Center "Hour" label and value
        self.lcd.text("Hour", hour_x + (dropdown_w - 32) // 2, dropdown_y - 15, self.text_color)  # "Hour" = 4 chars = 32px
        self.lcd.text(hour_text, hour_x + (dropdown_w - 16) // 2, dropdown_y + 10, self.text_color if self.editing_time != "hour" else 0xFFFF)  # 2 chars = 16px
        
        # Draw Minute dropdown
        # Highlight logic
        minute_fill = self.bg_color
        
        # Draw base box
        self.lcd.fill_rect(minute_x, dropdown_y, dropdown_w, dropdown_h, minute_fill)
        self.lcd.rect(minute_x, dropdown_y, dropdown_w, dropdown_h, self.text_color)
        
        # Highlight if selected
        if self.selected_index == 1:
            # Draw Thick Border for Selection
            self.lcd.rect(minute_x - 3, dropdown_y - 3, dropdown_w + 6, dropdown_h + 6, self.active_color)
            self.lcd.rect(minute_x - 2, dropdown_y - 2, dropdown_w + 4, dropdown_h + 4, self.active_color)
            
            # Check Edit State
            if self.editing_time == "minute":
                 # Red Fill if editing
                 self.lcd.fill_rect(minute_x, dropdown_y, dropdown_w, dropdown_h, 0xF800)
                 # Visual Cue: Show "CHANGE" below
                 self.lcd.text("CHANGE", minute_x, dropdown_y + 35, 0xF800)
                 self.lcd.text("^ v", minute_x + 15, dropdown_y + 45, 0xF800)
        
        minute_text = f"{self.temp_minute:02d}"
        # Center "Minute" label and value
        self.lcd.text("Minute", minute_x + (dropdown_w - 48) // 2, dropdown_y - 15, self.text_color)  # "Minute" = 6 chars = 48px
        self.lcd.text(minute_text, minute_x + (dropdown_w - 16) // 2, dropdown_y + 10, self.text_color if self.editing_time != "minute" else 0xFFFF)  # 2 chars = 16px
        
        # If dropdown is active (via touch), show selection list
        if self.dropdown_active == "hour":
            self._draw_hour_dropdown(hour_x, dropdown_y + dropdown_h)
        elif self.dropdown_active == "minute":
            self._draw_minute_dropdown(minute_x, dropdown_y + dropdown_h)
        
        # Bottom buttons
        # CANCEL (Left - Magenta)
        cancel_x = 20
        cancel_w = 100
        cancel_h = 30
        cancel_y = 200
        
        self.lcd.fill_rect(cancel_x, cancel_y, cancel_w, cancel_h, self.inactive_color)
        if self.selected_index == 2:
            self.lcd.rect(cancel_x - 2, cancel_y - 2, cancel_w + 4, cancel_h + 4, 0xFFFF) # Highlight border (Outer)
            self.lcd.rect(cancel_x - 1, cancel_y - 1, cancel_w + 2, cancel_h + 2, 0xFFFF) # Highlight border (Inner)
        
        # Center "CANCEL" text (6 chars = 48px)
        cancel_text_x = cancel_x + (cancel_w - 48) // 2
        self.lcd.text("CANCEL", cancel_text_x, cancel_y + 10, 0xFFFF)
        
        # SAVE (Right - Yellow-green)
        save_x = 200
        save_w = 100
        save_h = 30
        save_y = 200
        
        self.lcd.fill_rect(save_x, save_y, save_w, save_h, self.active_color)
        if self.selected_index == 3:
             self.lcd.rect(save_x - 2, save_y - 2, save_w + 4, save_h + 4, 0xFFFF) # Highlight border (Outer)
             self.lcd.rect(save_x - 1, save_y - 1, save_w + 2, save_h + 2, 0xFFFF) # Highlight border (Inner)
        
        # Center "SAVE" text (4 chars = 32px)
        save_text_x = save_x + (save_w - 32) // 2
        self.lcd.text("SAVE", save_text_x, save_y + 10, 0x0000)
        
        self.lcd.show()
        
    def _draw_hour_dropdown(self, x, y):
        """Draw hour selection dropdown (0-23)"""
        # Show 6 hours at a time
        list_h = 120
        self.lcd.fill_rect(x, y, 60, list_h, self.bg_color)
        self.lcd.rect(x, y, 60, list_h, self.text_color)
        
        # Draw visible hours (scroll offset)
        for i in range(6):
            hour_val = (self.dropdown_scroll + i) % 24
            item_y = y + (i * 20)
            
            # Highlight selected
            if hour_val == self.temp_hour:
                self.lcd.fill_rect(x + 2, item_y + 2, 56, 16, 0x4208)
            
            self.lcd.text(f"{hour_val:02d}", x + 20, item_y + 5, self.text_color)
        
        # Scroll arrows
        self.lcd.text("^", x + 25, y - 15, self.text_color)
        self.lcd.text("v", x + 25, y + list_h + 5, self.text_color)
        
    def _draw_minute_dropdown(self, x, y):
        """Draw minute selection dropdown (0-59)"""
        # Show 6 minutes at a time
        list_h = 120
        self.lcd.fill_rect(x, y, 60, list_h, self.bg_color)
        self.lcd.rect(x, y, 60, list_h, self.text_color)
        
        # Draw visible minutes (scroll offset, step by 5 for easier selection)
        for i in range(6):
            minute_val = (self.dropdown_scroll + (i * 5)) % 60
            item_y = y + (i * 20)
            
            # Highlight selected
            if minute_val == self.temp_minute:
                self.lcd.fill_rect(x + 2, item_y + 2, 56, 16, 0x4208)
            
            self.lcd.text(f"{minute_val:02d}", x + 20, item_y + 5, self.text_color)
        
        # Scroll arrows
        self.lcd.text("^", x + 25, y - 15, self.text_color)
        self.lcd.text("v", x + 25, y + list_h + 5, self.text_color)
        
    def draw_edit(self):
        """Same as draw_add but for editing"""
        self.draw_add()  # Reuse the same screen
        
    def handle_touch(self, x, y):
        """Handle touch input based on current mode"""
        if self.mode == "main":
            return self._handle_main_touch(x, y)
        elif self.mode == "add" or self.mode == "edit":
            return self._handle_add_edit_touch(x, y)
            
    def _handle_main_touch(self, x, y):
        """Handle touches on main screen"""
        # Back button
        if x < 60 and y < 20:
            self.hide()
            return "dashboard"
            
        # + Button (120-200, 30-110)
        if 120 <= x <= 200 and 30 <= y <= 110:
            # Check alarm limit
            if self.mgr.get_alarm_count() >= 3:
                self.show_limit_warning = True
                self.warning_start_time = time.time()
                self.draw_main()
            else:
                self.mode = "add"
                self.dropdown_active = None
                self.selected_index = 0 # Start at Hour
                self.editing_time = None
                self.temp_hour = 7
                self.temp_minute = 0
                self.draw_add()
            return None
            
        # Check alarm items (y: 140, 173, 206)
        alarms = self.mgr.get_alarms()
        y_start = 140
        row_height = 33
        
        for i, alarm in enumerate(alarms):
            row_y = y_start + (i * row_height)
            
            # Check if touch is in this row's Y range
            if row_y <= y < row_y + 30:
                alarm_id = alarm["id"]
                
                # ON/OFF Toggle button (100-135, row_y to row_y+20)
                if 100 <= x <= 135 and row_y <= y < row_y + 20:
                    self.mgr.toggle_alarm(alarm_id)
                    self.draw_main()
                    return None
                
                # DELETE button (220-280, row_y to row_y+25)
                elif 220 <= x <= 280 and row_y <= y < row_y + 25:
                    self.mgr.delete_alarm(alarm_id)
                    self.draw_main()
                    return None
                    
        return None
        
    def _handle_add_edit_touch(self, x, y):
        """Handle touches on add/edit screen with dropdown menus"""
        hour_x = 80
        minute_x = 200
        dropdown_y = 50
        dropdown_w = 60
        dropdown_h = 30
        
        # DEBUG
        print(f"ADD/EDIT Touch: x={x}, y={y}")
        print(f"Hour box: x={hour_x}-{hour_x+dropdown_w}, y={dropdown_y}-{dropdown_y+dropdown_h}")
        print(f"Minute box: x={minute_x}-{minute_x+dropdown_w}, y={dropdown_y}-{dropdown_y+dropdown_h}")
        
        # Touch on Hour dropdown box (open/close) - Expanded Y area to include label
        if hour_x <= x <= hour_x + dropdown_w and (dropdown_y - 20) <= y <= (dropdown_y + dropdown_h):
            print(">>> HOUR DROPDOWN TOGGLED!")
            if self.dropdown_active == "hour":
                self.dropdown_active = None
            else:
                self.dropdown_active = "hour"
                self.dropdown_scroll = max(0, self.temp_hour - 3)  # Center current hour
            self.draw_add()
            return
            
        # Touch on Minute dropdown box (open/close) - Expanded Y area to include label
        if minute_x <= x <= minute_x + dropdown_w and (dropdown_y - 20) <= y <= (dropdown_y + dropdown_h):
            print(">>> MINUTE DROPDOWN TOGGLED!")
            if self.dropdown_active == "minute":
                self.dropdown_active = None
            else:
                self.dropdown_active = "minute"
                self.dropdown_scroll = max(0, (self.temp_minute // 5) - 3) * 5  # Center current minute
            self.draw_add()
            return
        
        # Handle dropdown list interactions
        if self.dropdown_active == "hour":
            list_y = dropdown_y + dropdown_h
            list_h = 120
            
            # Scroll up arrow
            if hour_x + 20 <= x <= hour_x + 35 and list_y - 20 <= y <= list_y - 10:
                self.dropdown_scroll = (self.dropdown_scroll - 1) % 24
                self.draw_add()
                return
                
            # Scroll down arrow
            if hour_x + 20 <= x <= hour_x + 35 and list_y + list_h + 5 <= y <= list_y + list_h + 15:
                self.dropdown_scroll = (self.dropdown_scroll + 1) % 24
                self.draw_add()
                return
                
            # Click on hour value
            if hour_x <= x <= hour_x + 60 and list_y <= y < list_y + list_h:
                item_index = (y - list_y) // 20
                if 0 <= item_index < 6:
                    self.temp_hour = (self.dropdown_scroll + item_index) % 24
                    self.dropdown_active = None
                    self.draw_add()
                return
                
        elif self.dropdown_active == "minute":
            list_y = dropdown_y + dropdown_h
            list_h = 120
            
            # Scroll up arrow
            if minute_x + 20 <= x <= minute_x + 35 and list_y - 20 <= y <= list_y - 10:
                self.dropdown_scroll = (self.dropdown_scroll - 5) % 60
                self.draw_add()
                return
                
            # Scroll down arrow
            if minute_x + 20 <= x <= minute_x + 35 and list_y + list_h + 5 <= y <= list_y + list_h + 15:
                self.dropdown_scroll = (self.dropdown_scroll + 5) % 60
                self.draw_add()
                return
                
            # Click on minute value
            if minute_x <= x <= minute_x + 60 and list_y <= y < list_y + list_h:
                item_index = (y - list_y) // 20
                if 0 <= item_index < 6:
                    self.temp_minute = (self.dropdown_scroll + (item_index * 5)) % 60
                    self.dropdown_active = None
                    self.draw_add()
                return
        
        # CANCEL button (20-120, 200-230)
        if 20 <= x <= 120 and 200 <= y <= 230:
            self.mode = "main"
            self.editing_id = None
            self.dropdown_active = None
            self.draw_main()
            return
            
        # SAVE button (200-300, 200-230)
        elif 200 <= x <= 300 and 200 <= y <= 230:
            if self.mode == "add":
                # Add new alarm
                self.mgr.add_alarm(self.temp_hour, self.temp_minute)
            elif self.mode == "edit":
                # Update existing alarm
                self.mgr.update_alarm(self.editing_id, self.temp_hour, self.temp_minute)
                
            self.mode = "main"
            self.editing_id = None
            self.dropdown_active = None
            self.draw_main()
            return
            
    def handle_encoder(self, diff):
        """Handle rotary encoder rotation"""
        if self.mode == "main":
            # Navigation: 0=Back, 1=Plus
            # Then 2 items per alarm (Toggle, Del)
            alarm_count = self.mgr.get_alarm_count()
            max_index = 1 + (alarm_count * 2) 
            
            # Cyclic navigation
            self.selected_index = (self.selected_index + diff) % (max_index + 1)
            self.draw_main()
            
        elif self.mode == "add" or self.mode == "edit":
            # If editing time, change value
            if self.editing_time == "hour":
                self.temp_hour = (self.temp_hour + diff) % 24
                self.draw_add()
            elif self.editing_time == "minute":
                self.temp_minute = (self.temp_minute + diff) % 60
                self.draw_add()
            else:
                # Navigation: 0=Hour, 1=Minute, 2=Cancel, 3=Save
                self.selected_index = (self.selected_index + diff) % 4
                self.draw_add()
            
    def handle_button(self):
        """Handle rotary encoder button press"""
        if self.mode == "main":
            if self.selected_index == 0:  # Back
                self.hide()
                return "dashboard"
                
            elif self.selected_index == 1:  # + Button
                # Check limit
                if self.mgr.get_alarm_count() >= 3:
                    self.show_limit_warning = True
                    self.warning_start_time = time.time()
                    self.draw_main()
                else:
                    self.mode = "add"
                    self.dropdown_active = None
                    self.temp_hour = 7
                    self.temp_minute = 0
                    self.draw_add()
                    
            else:  # Alarm Actions (index 2+)
                # Determine which alarm and which action
                # Indices: 2,3 -> Alarm 0
                #          4,5 -> Alarm 1
                #          6,7 -> Alarm 2
                adjusted_idx = self.selected_index - 2
                alarm_idx = adjusted_idx // 2
                action = adjusted_idx % 2 # 0=Toggle, 1=Delete
                
                alarms = self.mgr.get_alarms()
                if 0 <= alarm_idx < len(alarms):
                    alarm_id = alarms[alarm_idx]["id"]
                    
                    if action == 0: # Toggle
                        self.mgr.toggle_alarm(alarm_id)
                        self.draw_main()
                        
                    elif action == 1: # Delete
                        self.mgr.delete_alarm(alarm_id)
                        # Fix index shift after deletion
                        # If we deleted something, max index decreases by 2
                        # Go back to Plus button for safety or clamp
                        self.selected_index = 1 
                        self.draw_main()

                    
        elif self.mode == "add" or self.mode == "edit":
            print(f"DEBUG: handle_button in ADD/EDIT mode. Index={self.selected_index}, Editing={self.editing_time}")
            # 0:Hour, 1:Minute, 2:Cancel, 3:Save
            if self.selected_index == 0: # Hour
                if self.editing_time == "hour":
                    print("DEBUG: Confirming Hour")
                    self.editing_time = None # Confirm
                else:
                    print("DEBUG: Editing Hour")
                    self.editing_time = "hour" # Start editing
                self.draw_add()
                
            elif self.selected_index == 1: # Minute
                if self.editing_time == "minute":
                    print("DEBUG: Confirming Minute")
                    self.editing_time = None # Confirm
                else:
                    print("DEBUG: Editing Minute")
                    self.editing_time = "minute" # Start editing
                self.draw_add()
                
            elif self.selected_index == 2: # Cancel
                print("DEBUG: Cancel pressed")
                self.mode = "main"
                self.selected_index = 0
                self.draw_main()
                
            elif self.selected_index == 3: # Save
                print("DEBUG: Save pressed")
                if self.mode == "add":
                    self.mgr.add_alarm(self.temp_hour, self.temp_minute)
                elif self.mode == "edit":
                    self.mgr.update_alarm(self.editing_id, self.temp_hour, self.temp_minute)
                self.mode = "main"
                self.selected_index = 0
                self.draw_main()

    def update(self):
        """Update function called from main loop"""
        # Redraw if warning is active and needs to be cleared
        if self.show_limit_warning and self.visible:
            if time.time() - self.warning_start_time > 2:
                self.show_limit_warning = False
                self.draw_main()
