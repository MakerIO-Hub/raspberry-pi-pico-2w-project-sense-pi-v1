"""
Standalone Torch Module for SensePi
This module handles the Torch (LED) functionality independently.
It includes its own pin configuration and test logic.
"""

from machine import Pin, PWM
import time

# --- CONFIGURATION (INTERNAL) ---
TORCH_PIN = 21

class TorchModule:
    def __init__(self, lcd, buzzer=None):
        self.lcd = lcd
        self.buzzer = buzzer
        self.torch_on = False
        self.brightness = 100 # Default 100%
        
        # Navigation State
        # 0: Back, 1: ON/OFF, 2: -, 3: +
        self.selected_index = 0
        
        # Initialize PWM for LED Control
        try:
            self.led_pin = Pin(TORCH_PIN, Pin.OUT)
            self.pwm = PWM(self.led_pin)
            self.pwm.freq(1000)
            self.pwm.duty_u16(0) # Start OFF
            print(f"TorchModule: Initialized on GP{TORCH_PIN}")
        except Exception as e:
            print(f"TorchModule: Init Error - {e}")
            self.pwm = None

        # UI Colors
        self.bg_color = 0xdd22       # Orange (SensePi Theme)
        self.header_text_color = 0xFFFF # White
        self.btn_off_color = 0x3186  # Dark Grey/Blue
        self.btn_on_color = 0xFFFF   # White (Bright)
        self.text_black = 0x0000
        self.select_color = 0xF81F   # Magenta highlight
    
    def draw(self):
        """Draw the full Torch UI"""
        # 1. Clear Screen
        self.lcd.fill(self.bg_color)
        
        # 2. Header
        back_color = self.select_color if self.selected_index == 0 else self.header_text_color
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, self.header_text_color)
        
        # 3. Main Toggle Button (Centered)
        # Moved up as requested: Cy=120 -> 100
        cx, cy = 160, 100 
        radius = 50
        
        # Determine colors based on state
        if self.torch_on:
            circle_color = self.btn_on_color
            text_color = self.text_black
            label = "ON"
        else:
            circle_color = self.btn_off_color
            text_color = self.header_text_color
            label = "OFF"
            
        # Highlight if selected
        if self.selected_index == 1:
            self.draw_circle(cx, cy, radius + 3, self.select_color)
            self.draw_circle(cx, cy, radius + 2, self.select_color)

        # Draw Concentric Circles for button effect
        self.draw_circle(cx, cy, radius, circle_color)
        self.draw_circle(cx, cy, radius-1, circle_color)
        self.draw_circle(cx, cy, radius-2, circle_color)
        
        # Fill Circle
        for r in range(radius-4, 0, -2):
             self.draw_circle(cx, cy, r, circle_color)
             
        # Button Label
        label_len = len(label)
        text_w = label_len * 32 
        text_x = cx - (text_w // 2)
        text_y = cy - 16
        self.draw_text_scaled(label, text_x, text_y, 4, text_color)
        
        # 4. Brightness Controls (Bottom Area)
        # Moved up: Y=200 -> 175
        ctrl_y = 175
        ctrl_radius = 25
        
        # "-" Button (Left - Center 80, 175)
        if self.selected_index == 2:
            self.draw_circle(80, ctrl_y, ctrl_radius + 3, self.select_color)
            self.draw_circle(80, ctrl_y, ctrl_radius + 2, self.select_color)

        self.draw_circle(80, ctrl_y, ctrl_radius, 0xFFFF)
        self.draw_text_scaled("-", 80 - 12, ctrl_y - 12, 3, 0x0000)
        
        # "+" Button (Right - Center 240, 175)
        if self.selected_index == 3:
            self.draw_circle(240, ctrl_y, ctrl_radius + 3, self.select_color)
            self.draw_circle(240, ctrl_y, ctrl_radius + 2, self.select_color)

        self.draw_circle(240, ctrl_y, ctrl_radius, 0xFFFF)
        self.draw_text_scaled("+", 240 - 12, ctrl_y - 12, 3, 0x0000)
        
        # Brightness Level (Center Bottom - below controls)
        level_str = f"{self.brightness}%"
        level_w = len(level_str) * 16
        self.draw_text_scaled(level_str, 160 - (level_w // 2), ctrl_y - 8, 2, 0xFFFF)
        
        self.lcd.show()
        
    def handle_touch(self, x, y):
        """Handle touch input. Returns 'sensors' if back button pressed."""
        
        # 1. Back Button
        if x < 80 and y < 40:
            return "sensors"
            
        # 2. Main Toggle Button (Center 160,100, Radius 50)
        dx = x - 160
        dy = y - 100
        if (dx*dx + dy*dy) < (75*75): # Increased from 50 to 75 for much better tolerance
            self.toggle_torch()
            self.selected_index = 1
            self.draw()
            return None
            
        # 3. Brightness Controls
        # "-" Button (Center 80, 175, Radius 25)
        dx_minus = x - 80
        dy_minus = y - 175
        if (dx_minus*dx_minus + dy_minus*dy_minus) < (45*45): # Increased from 35 to 45
            self.change_brightness(-10)
            self.selected_index = 2
            self.draw()
            return None
            
        # "+" Button (Center 240, 175, Radius 25)
        dx_plus = x - 240
        dy_plus = y - 175
        if (dx_plus*dx_plus + dy_plus*dy_plus) < (45*45): # Increased from 35 to 45
            self.change_brightness(+10)
            self.selected_index = 3
            self.draw()
            return None
            
        return None

    def handle_encoder(self, direction):
        """Standard navigation through items 0:Back, 1:ON/OFF, 2:-, 3:+"""
        self.selected_index = (self.selected_index + direction) % 4
        self.draw()

    def handle_encoder_button(self):
        """Execute action for selected item. Returns 'sensors' on Back."""
        if self.selected_index == 0: # Back
            return "sensors"
        elif self.selected_index == 1: # ON/OFF
            self.toggle_torch()
            self.draw() # Update UI
        elif self.selected_index == 2: # -
            self.change_brightness(-10)
            self.draw() # Update UI
        elif self.selected_index == 3: # +
            self.change_brightness(+10)
            self.draw() # Update UI
        return None
        
    def change_brightness(self, amount):
        """Adjust brightness within 0-100 range"""
        self.brightness = max(0, min(100, self.brightness + amount))
        
        # Update PWM if currently ON
        if self.torch_on:
            duty = int((self.brightness / 100) * 65535)
            self.pwm.duty_u16(duty)

    def toggle_torch(self):
        """Switch LED state"""
        if not self.pwm: return
        
        self.torch_on = not self.torch_on
        if self.torch_on:
            duty = int((self.brightness / 100) * 65535)
            self.pwm.duty_u16(duty) # Use current brightness
        else:
            self.pwm.duty_u16(0) # OFF

    # --- Helper Graphics Functions (Copied from other modules to be standalone) ---
    def draw_circle(self, cx, cy, r, color):
        x = r
        y = 0
        err = 0
        
        while x >= y:
            self.lcd.pixel(cx + x, cy + y, color)
            self.lcd.pixel(cx + y, cy + x, color)
            self.lcd.pixel(cx - y, cy + x, color)
            self.lcd.pixel(cx - x, cy + y, color)
            self.lcd.pixel(cx - x, cy - y, color)
            self.lcd.pixel(cx - y, cy - x, color)
            self.lcd.pixel(cx + y, cy - x, color)
            self.lcd.pixel(cx + x, cy - y, color)
            
            if err <= 0:
                y += 1
                err += 2 * y + 1
            if err > 0:
                x -= 1
                err -= 2 * x + 1

    def draw_text_scaled(self, text, x, y, size, color):
        import framebuf
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        
        # DEBUG: Treat Black as White, White as Black for background differentiation
        # If text is Black (0x0000), make background White (0xFFFF)
        bg_color = 0xFFFF if color == 0x0000 else 0x0000
            
        fb.fill(bg_color)
        fb.text(text, 0, 0, color)
        
        pixels_drawn = 0
        pixel_debug_limit = 5
        
        for row in range(h):
            for col in range(w):
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                # Draw only if NOT background
                if c != bg_color:
                    draw_c = c if c != 0x0000 else 0x0001
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, draw_c)
                    pixels_drawn += 1

    def draw_touch_marker(self, x, y):
        """Draw small marker at touch point for debugging"""
        # Red X or Circle
        color = 0xF800 # Red
        self.draw_circle(x, y, 3, color)
        # self.lcd.pixel(x, y, color)

# --- STANDALONE TEST BLOCK ---
if __name__ == "__main__":
    from machine import SPI, Pin
    import sys
    
    # Ensure root directory is in path for imports
    try:
        import lcd_2inch8
        import touch_xpt2046
    except ImportError:
        sys.path.append('..')
        import lcd_2inch8
        import touch_xpt2046

    import time
    
    print("--- STARTING TORCH MODULE TEST ---")
    
    # 1. Setup SPI (Shared by LCD and Touch)
    spi = SPI(1, baudrate=10000000, sck=Pin(10), mosi=Pin(11), miso=Pin(12))
    
    # 2. Setup LCD
    lcd = lcd_2inch8.LCD_2inch8(spi, cs=Pin(9), dc=Pin(8), rst=Pin(15), bl=machine.PWM(Pin(13)))
    
    # 3. Setup Touch
    touch = touch_xpt2046.Touch(spi, cs=Pin(16), irq=Pin(17))
    
    # NEW: Setup Encoder for Standalone Test
    try:
        import ky040
        encoder = ky040.KY040(clk_pin=0, dt_pin=1, sw_pin=2)
        old_val = encoder.get_value()
        print("Encoder initialized on GP0, GP1, GP2")
    except Exception as e:
        print(f"Encoder Init Error: {e}")
        encoder = None
    torch_mod = TorchModule(lcd)
    
    # Flash LED on startup to prove hardware works
    print("Flashing LED for hardware test...")
    if torch_mod.pwm:
        torch_mod.pwm.duty_u16(65535)
        time.sleep(0.2)
        torch_mod.pwm.duty_u16(0)
        time.sleep(0.2)
        torch_mod.pwm.duty_u16(65535)
        time.sleep(0.2)
        torch_mod.pwm.duty_u16(0)
    
    torch_mod.draw()
    
    print("UI Drawn. Waiting for input...")
    print("Touch OR Encoder to interact. Back button returns 'sensors'.")
    
    try:
        while True:
            # --- ENCODER TEST ---
            if encoder:
                new_val = encoder.get_value()
                if new_val != old_val:
                    diff = 1 if new_val > old_val else -1
                    torch_mod.handle_encoder(diff)
                    old_val = new_val
                
                if encoder.is_pressed():
                    result = torch_mod.handle_encoder_button()
                    if result == "sensors":
                        print("BACK PRESSED (Encoder) - Exiting Test")
                        break
                    time.sleep(0.3) # Debounce
            
            # --- TOUCH TEST ---
            p = touch.get_touch()
            if p:
                # Simple debouncing
                time.sleep(0.05) 
                
                # Double check if still touching
                p2 = touch.get_touch()
                if p2:
                    if isinstance(p2, tuple) and len(p2) == 2:
                        x, y = p2
                        print(f"Touch Detected: {x}, {y}")
                        
                        # Draw marker (Debug)
                        torch_mod.draw_touch_marker(x, y)
                        
                        action = torch_mod.handle_touch(x, y)
                        if action == "sensors":
                            print("BACK BUTTON PRESSED (Touch) - Exiting Test")
                            break
                        
                        # Calculate distance to button center for debug
                        dx = x - 160
                        dy = y - 130
                        dist = (dx*dx + dy*dy)**0.5
                        print(f"Distance to center: {dist:.1f} (Threshold: 60)")
                        
            time.sleep(0.02)
            
    except KeyboardInterrupt:
        print("Test Interrupted")
    finally:
        if torch_mod.pwm:
            torch_mod.pwm.deinit()
        print("Test Finished")
