import time

class CalendarModule:
    def __init__(self, lcd, driver, tz_detector):
        self.lcd = lcd
        self.driver = driver
        self.tz_detector = tz_detector
        self.visible = False
        
        # Colors (Matching Alarm Module)
        self.bg_color = 0xdd22  # Orange Background
        self.text_color = 0xFFFF # White Text (Content - Matches Alarm)
        self.header_text_color = 0xFFFF # White Text (Header)
        self.line_color = 0xFFFF # White Lines
        
        # State
        self.events = []
        self.last_update = 0
        self.fetching = False
        self.status_message = "Ready"
        
    def show(self):
        self.visible = True
        self.draw()
        
        # Auto update if stale (> 15 mins)
        if time.time() - self.last_update > 900:
            self.update()
            
    def hide(self):
        self.visible = False
        
    def update(self):
        self.fetching = True
        self.status_message = "Updating..."
        self.draw()
        self.lcd.show()
        
        try:
            result = self.driver.get_daily_agenda()
            if result is not None:
                self.events = result
                self.last_update = time.time()
                self.status_message = "Updated"
            else:
                self.status_message = "Error/Empty"
        except Exception as e:
            self.status_message = "Error"
            print(f"Calendar Update Error: {e}")
            
        self.fetching = False
        self.draw()
        
    def draw(self):
        if not self.visible: return
        
        self.lcd.fill(self.bg_color)
        
        # === HEADER (Alarm Style) ===
        # Back Button - White text
        self.lcd.text("< Back", 5, 5, self.header_text_color)
        
        # Separator Line
        self.lcd.hline(0, 20, 320, self.line_color)
        
        # NO TITLE as requested
        
        # === CONTENT ===
        if self.fetching:
            self.lcd.text("Updating...", 10, 40, self.text_color)
            self.lcd.show()
            return

        if not self.events:
            # Empty State
            if self.status_message.startswith("Error"):
                self.lcd.text("Connection Error", 10, 40, self.text_color)
            else:
                self.lcd.text("No Events Today", 10, 40, self.text_color)
            self.lcd.show()
            return

        # List Events (Left Aligned)
        y = 35
        row_h = 25
        
        for event in self.events:
            # Format: HH:MM Title
            time_str = event.get("time", "??:??")
            title = event.get("title", "No Title")
            
            # Truncate title to fit screen (approx 30 chars max with time)
            max_len = 25
            if len(title) > max_len:
                title = title[:max_len-1] + "."
                
            display_str = f"{time_str} {title}"
            
            self.lcd.text(display_str, 10, y, self.text_color)
            
            y += row_h
            if y > 220: break
            
        self.lcd.show()
        
    def _get_time_str(self, timestamp):
        if timestamp == 0: return "--:--"
        t = time.localtime(timestamp)
        return "{:02d}:{:02d}".format(t[3], t[4])

    def handle_encoder_button(self):
        self.hide()
        return "dashboard"
        
    def handle_touch(self, x, y):
        # Header / Back button area
        if y < 35:
            self.hide()
            return "dashboard"
            
        return None
