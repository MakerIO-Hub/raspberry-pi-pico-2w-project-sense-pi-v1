"""
Clock Module for SensePi
Dual display: Analog + Digital clock with automatic timezone detection
"""

import time
import math

class ClockModule:
    def __init__(self, lcd, rtc_driver, ntp_manager, timezone_detector):
        self.lcd = lcd
        self.rtc = rtc_driver
        self.ntp = ntp_manager
        self.tz_detector = timezone_detector
        
        # Display settings
        self.show_analog = True
        self.show_digital = True
        self.format_24h = True
        
        # Timezone info
        self.timezone = "Europe/Istanbul"
        self.timezone_offset = 3 * 3600  # UTC+3
        self.city = "Istanbul"
        self.country = "Turkey"
        self.country_code = "TR"
        
        # Time source
        self.time_source = "rtc"  # "rtc" or "ntp"
        self.last_ntp_sync = 0
        self.auto_sync_interval = 3600  # 1 hour
        
        # Colors (Updated: Orange background, WHITE text for visibility)
        self.bg_color = 0xdd22  # Orange (dashboard color)
        self.primary_color = 0xFFFF  # White (for visibility)
        self.text_color = 0xFFFF  # White (for visibility)
        self.accent_color = 0xF800  # Red (second hand)
        
        # State
        self.active = False
        self.current_time = None
        self.selected_idx = 0 # 0: Back, 1: Source
        
    def show(self):
        """Show Clock module (full screen)"""
        self.active = True
        print("Clock: Açılıyor...")
        
        # Auto-detect timezone on first show
        if self.timezone == "Europe/Istanbul" and self.tz_detector:
            self._detect_timezone()
            
        self.draw_full()
        
    def hide(self):
        """Hide Clock module (return to dashboard)"""
        self.active = False
        print("Clock: Kapatılıyor...")
        
    def update(self):
        """Update clock (call every second)"""
        if not self.active:
            return
            
        # Auto-sync NTP periodically
        if self.time_source == "ntp":
            if time.time() - self.last_ntp_sync > self.auto_sync_interval:
                self._sync_ntp()
                
        # Get current time
        self.current_time = self._get_current_time()
        
        # Redraw clock
        self.draw_full()
        
    def draw_full(self):
        """Draw complete clock interface - Centered vertical layout"""
        # Clear screen (orange)
        self.lcd.fill(self.bg_color)
        
        # Draw header
        self._draw_header()
        
        # Get current time
        if not self.current_time:
            self.current_time = self._get_current_time()
            
        # Centered vertical layout
        # 1. Analog clock (top-center)
        if self.show_analog:
            self._draw_analog_clock(160, 80, 50, self.current_time)  # Center X=160, Y=80
            
        # 2. Digital clock (below analog) - Simple text
        if self.show_digital:
            self._draw_digital_clock_centered(self.current_time, y_pos=145)
            
        # 3. Location info (below digital)
        self._draw_location_info_centered(y_pos=165)
        
        self.lcd.show()
        
    def _draw_header(self):
        """Draw header with back button and source indicator - GREEN if selected"""
        # Back arrow + text (Highlight if selected_idx == 0)
        back_color = 0x07E0 if self.selected_idx == 0 else 0xFFFF
        self.lcd.text("< Back", 5, 5, back_color)
        
        # Source indicator (Highlight if selected_idx == 1)
        source_color = 0x07E0 if self.selected_idx == 1 else 0xFFFF
        source_text = "[RTC]" if self.time_source == "rtc" else "[NTP]"
        source_x = 320 - len(source_text) * 8 - 5
        self.lcd.text(source_text, source_x, 5, source_color)
        
        # Separator line (WHITE)
        self.lcd.hline(0, 20, 320, 0xFFFF)
        
    def _draw_analog_clock(self, center_x, center_y, radius, time_data):
        """
        Draw analog clock with hour, minute, and second hands
        
        Args:
            center_x, center_y: Center coordinates
            radius: Clock radius
            time_data: dict with hour, minute, second
        """
        # Outer circle (WHITE - THICK)
        # Draw multiple circles for thickness
        for thickness in range(3):
            self._draw_circle(center_x, center_y, radius - thickness, 0xFFFF)
        
        # Hour markers (12 positions) - WHITE THICK
        for i in range(12):
            angle = math.radians(i * 30 - 90)  # -90 to start from top
            
            # Outer point
            x1 = int(center_x + (radius - 6) * math.cos(angle))
            y1 = int(center_y + (radius - 6) * math.sin(angle))
            
            # Inner point
            x2 = int(center_x + (radius - 12) * math.cos(angle))
            y2 = int(center_y + (radius - 12) * math.sin(angle))
            
            # Draw THICK marker line (3px thick)
            for offset in range(-1, 2):
                self.lcd.line(x1 + offset, y1, x2 + offset, y2, 0xFFFF)
                self.lcd.line(x1, y1 + offset, x2, y2 + offset, 0xFFFF)
            
        # Calculate hand angles
        hour = time_data["hour"] % 12
        minute = time_data["minute"]
        second = time_data["second"]
        
        hour_angle = math.radians((hour * 30 + minute * 0.5) - 90)
        minute_angle = math.radians((minute * 6) - 90)
        second_angle = math.radians((second * 6) - 90)
        
        # Hour hand (short, thick) - WHITE - EXTRA THICK
        hour_len = radius * 0.5
        hour_x = int(center_x + hour_len * math.cos(hour_angle))
        hour_y = int(center_y + hour_len * math.sin(hour_angle))
        self._draw_thick_line(center_x, center_y, hour_x, hour_y, 0xFFFF, thickness=3)
        
        # Minute hand (longer, medium thick) - WHITE
        minute_len = radius * 0.7
        minute_x = int(center_x + minute_len * math.cos(minute_angle))
        minute_y = int(center_y + minute_len * math.sin(minute_angle))
        self._draw_thick_line(center_x, center_y, minute_x, minute_y, 0xFFFF, thickness=2)
        
        # Second hand (longest, MAGENTA TEST) - Trying magenta instead
        second_len = radius * 0.8
        second_x = int(center_x + second_len * math.cos(second_angle))
        second_y = int(center_y + second_len * math.sin(second_angle))
        self.lcd.line(center_x, center_y, second_x, second_y, 0xF81F)  # MAGENTA (pink-red)
        
        # Center dot - WHITE BIGGER
        self._draw_filled_circle(center_x, center_y, 4, 0xFFFF)
        
    def _draw_digital_clock_centered(self, time_data, y_pos=135):
        """Draw digital time display (enlarged text format)"""
        hour = time_data["hour"]
        minute = time_data["minute"]
        second = time_data["second"]
        
        # Format time
        if self.format_24h:
            time_str = f"{hour:02d}:{minute:02d}:{second:02d}"
        else:
            am_pm = "AM" if hour < 12 else "PM"
            hour_12 = hour % 12
            if hour_12 == 0:
                hour_12 = 12
            time_str = f"{hour_12:02d}:{minute:02d}:{second:02d} {am_pm}"
            
        # Enlarged text (matches Date module's weekday size)
        scale = 2
        text_w = len(time_str) * (8 * scale)
        text_x = (320 - text_w) // 2
        
        self.draw_text_scaled(time_str, text_x, y_pos, scale, 0xFFFF)

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        import framebuf
        # 1. Render text to a small temporary buffer
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source (RGB565 is 2 bytes)
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    # Draw 'size x size' block
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)
    
    def _draw_location_info_centered(self, y_pos=175):
        """Draw location and timezone info (centered, 3 lines) - ALL WHITE"""
        # Line 1: City, Country (WHITE)
        location = f"{self.city}, {self.country}"
        loc_x = (320 - len(location) * 8) // 2
        self.lcd.text(location, loc_x, y_pos, 0xFFFF)
        
        # Line 2: Timezone name (WHITE)
        tz_x = (320 - len(self.timezone) * 8) // 2
        self.lcd.text(self.timezone, tz_x, y_pos + 12, 0xFFFF)
        
        # Line 3: UTC offset (WHITE)
        tz_offset_hours = self.timezone_offset // 3600
        offset_str = f"UTC{tz_offset_hours:+d}"
        offset_x = (320 - len(offset_str) * 8) // 2
        self.lcd.text(offset_str, offset_x, y_pos + 24, 0xFFFF)
        
    def _get_current_time(self):
        """Get current time from RTC"""
        return self.rtc.get_time()
        
    def _sync_ntp(self):
        """Synchronize time from NTP"""
        print("Clock: NTP senkronizasyonu başlatılıyor...")
        if self.ntp.sync_rtc(self.rtc, self.timezone_offset):
            self.last_ntp_sync = time.time()
            print("Clock: NTP senkronizasyonu başarılı")
        else:
            print("Clock: NTP senkronizasyonu başarısız, RTC kullanılıyor")
            
    def _detect_timezone(self):
        """Auto-detect timezone from IP"""
        print("Clock: Timezone algılanıyor...")
        tz_data = self.tz_detector.detect()
        
        if tz_data:
            self.timezone = tz_data["timezone"]
            self.timezone_offset = tz_data["offset"]
            self.city = tz_data["city"]
            self.country = tz_data["country"]
            self.country_code = tz_data["country_code"]
            print(f"Clock: Timezone -> {self.timezone} ({self.city}, {self.country})")
            
            # Sync NTP with new timezone
            if self.time_source == "ntp":
                self._sync_ntp()
        else:
            print("Clock: Timezone algılanamadı, varsayılan kullanılıyor")
            
    def toggle_time_source(self):
        """Toggle between RTC and NTP"""
        if self.time_source == "rtc":
            self.time_source = "ntp"
            self._sync_ntp()
        else:
            self.time_source = "rtc"
        print(f"Clock: Time source -> {self.time_source.upper()}")
        
    def handle_encoder(self, direction):
        """Handle encoder rotation (Switch selection)"""
        # 0: Back, 1: Source
        self.selected_idx = (self.selected_idx + direction) % 2
        self.draw_full()
        
    def handle_encoder_button(self):
        """Handle encoder button press (Activate selected item)"""
        if self.selected_idx == 0:
            # Back
            self.hide()
            return "dashboard"
        elif self.selected_idx == 1:
            # Toggle Source
            self.toggle_time_source()
            self.draw_full()
        return None
        
    def handle_touch(self, x, y):
        """Handle touch events"""
        # Back button area (top-left)
        if x < 50 and y < 20:
            self.hide()
            return "dashboard"
            
        # Source toggle (top-right)
        if x > 270 and y < 20:
            self.toggle_time_source()
            self.draw_full()
            
        return None
        
    # === Helper Drawing Functions ===
    
    def _draw_circle(self, x0, y0, r, color):
        """Draw circle outline using Bresenham's algorithm"""
        x = r
        y = 0
        err = 0
        
        while x >= y:
            self.lcd.pixel(x0 + x, y0 + y, color)
            self.lcd.pixel(x0 + y, y0 + x, color)
            self.lcd.pixel(x0 - y, y0 + x, color)
            self.lcd.pixel(x0 - x, y0 + y, color)
            self.lcd.pixel(x0 - x, y0 - y, color)
            self.lcd.pixel(x0 - y, y0 - x, color)
            self.lcd.pixel(x0 + y, y0 - x, color)
            self.lcd.pixel(x0 + x, y0 - y, color)
            
            if err <= 0:
                y += 1
                err += 2 * y + 1
            if err > 0:
                x -= 1
                err -= 2 * x + 1
                
    def _draw_filled_circle(self, x0, y0, r, color):
        """Draw filled circle"""
        for y in range(-r, r + 1):
            for x in range(-r, r + 1):
                if x*x + y*y <= r*r:
                    self.lcd.pixel(x0 + x, y0 + y, color)
                    
    def _draw_thick_line(self, x0, y0, x1, y1, color, thickness=2):
        """Draw thick line"""
        for offset in range(-thickness//2, thickness//2 + 1):
            self.lcd.line(x0 + offset, y0, x1 + offset, y1, color)
            self.lcd.line(x0, y0 + offset, x1, y1 + offset, color)
