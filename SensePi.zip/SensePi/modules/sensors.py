import time
import dht
from machine import Pin, I2C
import framebuf
import math


class SensorsModule:
    def __init__(self, lcd, buzzer=None):
        self.lcd = lcd
        self.visible = False
        self.mode = "GRID" # GRID, DETAIL_DHT11, DETAIL_EARTHQUAKE
        
        # Navigation State
        # 0: Back Button
        # 1-6: Grid Items
        self.selected_index = 1 # Start at Item 1 by default
        
        # DHT11 Sensor (Item 1)
        try:
            self.dht_sensor = dht.DHT11(Pin(22))
        except Exception as e:
            print(f"DHT11 Init Error: {e}")
            self.dht_sensor = None
            
        self.last_dht_read = 0
        self.temp = None
        self.hum = None
        self.dht_interval = 2000 # 2 seconds
        
        # Load DHT11 Icon
        self.dht_icon_data = None
        try:
            with open("icons/temperature_humidity.bin", "rb") as f:
                self.dht_icon_data = f.read()
        except Exception as e:
            print(f"DHT11 Icon Load Error: {e}")
            
        # Load Earthquake Sensor Icon
        self.earthquake_icon_data = None
        try:
            with open("icons/earthquake-sensor.bin", "rb") as f:
                self.earthquake_icon_data = f.read()
        except Exception as e:
            print(f"Earthquake Icon Load Error: {e}")
        
        # Load Spirit Level Icon
        self.spirit_level_icon_data = None
        try:
            with open("icons/spirit-level.bin", "rb") as f:
                self.spirit_level_icon_data = f.read()
        except Exception as e:
            print(f"Spirit Level Icon Load Error: {e}")
            
        # Load Step Counter Icon
        self.step_counter_icon_data = None
        try:
            with open("icons/stepcounter.bin", "rb") as f:
                self.step_counter_icon_data = f.read()
        except Exception as e:
            print(f"Step Counter Icon Load Error: {e}")
            
        # Load Torch Icon
        self.torch_icon_data = None
        try:
            with open("icons/torch.bin", "rb") as f:
                self.torch_icon_data = f.read()
        except Exception as e:
            print(f"Torch Icon Load Error: {e}")

        # Load Hand Detection Icon
        self.hand_icon_data = None
        try:
            # Note: Following user's spelling "handdedection"
            with open("icons/handdedection.bin", "rb") as f:
                self.hand_icon_data = f.read()
        except Exception as e:
            print(f"Hand Detection Icon Load Error: {e}")
        
        # MPU-6050 Sensor (Item 2 - Earthquake Detection)
        
        # MPU-6050 Sensor (Item 2 - Earthquake Detection)
        try:
            from drivers.mpu6050 import MPU6050
            i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=400000)
            self.mpu = MPU6050(i2c)
            print("MPU-6050 initialized successfully")
        except Exception as e:
            print(f"MPU-6050 Init Error: {e}")
            self.mpu = None
        
        # Earthquake detection variables
        self.last_mpu_read = 0
        self.mpu_interval = 100  # Read every 100ms
        self.shake_magnitude = 0.0
        self.max_shake = 0.0
        self.shake_threshold = 0.2  # G units above normal (for status display)
        self.shake_status = "Normal"  # "Normal", "Low Shake", "STRONG"
        
        # Alarm system
        self.buzzer = buzzer
        self.alarm_threshold = 0.15  # G units - triggers alarm
        self.alarm_active = False
        self.alarm_enabled = False  # Disabled until grace period passes
        self.alarm_start_time = 0
        self.alarm_trigger_duration = 1000  # ms - shake must persist for this long (increased to avoid touch vibrations)
        self.shake_start_time = 0  # When shake first exceeded threshold
        self.startup_time = 0  # When module was opened
        self.startup_grace_period = 2000  # ms - don't trigger alarm for 2 seconds after opening
        self.alarm_last_triggered = 0
        self.alarm_cooldown = 5000 # 5 seconds cooldown after dismissal
        
        # Buzzer control for non-blocking beeps
        self.buzzer_active = False
        self.buzzer_start_time = 0
        self.buzzer_duration = 10000  # 10 seconds
        self.last_beep_time = 0
        self.beep_interval = 200  # 200ms between beeps (0.1s beep + 0.1s pause)
        self.buzzer_enabled = True  # User can toggle buzzer on/off
        
        # Earthquake event logging (max 5 events, auto-delete after 24h)
        self.earthquake_log = []  # List of {timestamp, max_magnitude, duration, logged_at}
        self.max_log_size = 5
        
        # Spirit Level Variables
        self.pitch = 0.0
        self.roll = 0.0
        self.cal_pitch = 0.0
        self.cal_roll = 0.0
        self.balanced_beep_done = False
        
        # Step Counter Variables
        # Step Counter
        self.steps = 0
        self.step_counter_active = False # Default inactive
        self.distance_km = 0.0
        self.calories_kcal = 0.0
        self.step_threshold = 1.2 # Gravity + movement (1.0 + 0.2)
        self.step_cooldown = 300 # ms between steps
        self.last_step_time = 0
        self.step_history = [] # For smoothing/peak detection
        self.step_history_max_len = 5

        # ITEM 6: Hand Detection (QRE1113)
        try:
            from drivers.qre1113 import QRE1113
            # Using GP26 (ADC0) as recommended for Analog/ADC support
            self.hand_sensor = QRE1113(pin_num=26, is_analog=True)
            print("Hand Detection (QRE1113) initialized on GP26 (Analog)")
        except Exception as e:
            print(f"Hand Detection Init Error: {e}")
            self.hand_sensor = None

        # Colors
        self.bg_color = 0xdd22       # Orange background
        self.text_color = 0xFFFF      # White
        self.unselected_text = 0x0000 # Black
        
        # Item Specific Colors
        self.item_colors = [
            0x039F, # Item 1 (DHT11 Blue)
            0xF81F, # Item 2
            0xF800, # Item 3
            0xCF9F, # Item 4
            0xFE60, # Item 5
            0xA81F  # Item 6
        ]
        
        self.last_draw_time = 0
        
        # Grid settings (2 rows x 3 columns)
        self.cols = 3
        self.rows = 2
        self.cell_width = 320 // self.cols
        self.header_height = 25
        self.cell_height = (240 - self.header_height) // self.rows
        
        # Icon Data placeholders (Initialize as None for lazy loading)
        self.dht_icon_data = None
        self.earthquake_icon_data = None
        self.spirit_level_icon_data = None
        self.step_counter_icon_data = None
        self.torch_icon_data = None
        self.measure_icon_data = None

        # Grid items (Updated to Dict for Icon support)
        # Icons will be loaded on demand or kept as paths to save RAM
        self.items = [
            {"name": "DHT11", "icon_path": "icons/temperature_humidity.bin", "target": "dht_info"}, 
            {"name": "Quake", "icon_path": "icons/earthquake-sensor.bin", "target": "quake_info"},
            {"name": "Level", "icon_path": "icons/spirit-level.bin", "target": "level_app"}, 
            {"name": "Steps", "icon_path": "icons/stepcounter.bin", "target": "steps_app"}, 
            {"name": "Torch", "icon_path": "icons/torch.bin", "target": "torch"}, 
            {"name": "Measure", "icon_path": "icons/measure.bin", "target": "measure"} 
        ]
        
    def _load_icon(self, path):
        # Load icon on demand
        try:
            with open(path, "rb") as f:
                return f.read()
        except:
            return None
        


    def show(self):
        self.visible = True
        
        # Don't reset mode if alarm is active (preserve ALARM_VIEW)
        if hasattr(self, 'alarm_active') and self.alarm_active:
             pass
        else:
             self.mode = "GRID"  
             # self.selected_index = 1 # REMOVED: Keep last selection
             
        self.startup_time = time.ticks_ms()  # Record startup time
        self.alarm_enabled = False  # Disable alarm during startup
        
        self.draw()

    def hide(self):
        self.visible = False

    def update(self):
        # ALWAYS update MPU-6050 for global earthquake monitoring (even when not visible)
        if self.mpu and time.ticks_diff(time.ticks_ms(), self.last_mpu_read) > self.mpu_interval:
            self.read_mpu()
            self.last_mpu_read = time.ticks_ms()
            
            # Clean old events periodically
            self.clean_old_events()
        
        # Update buzzer (non-blocking beeps) - also works globally
        if self.buzzer_active:
            current_time = time.ticks_ms()
            
            # Check if buzzer duration expired (10 seconds)
            if time.ticks_diff(current_time, self.buzzer_start_time) > self.buzzer_duration:
                # Auto-stop buzzer and dismiss alarm
                self.buzzer_active = False
                self.alarm_active = False
                if self.visible:
                    self.mode = "GRID"
                    self.draw() # Go back to grid
                print("Buzzer auto-stopped after 10 seconds")
            else:
                # Play beep every 200ms
                if time.ticks_diff(current_time, self.last_beep_time) > self.beep_interval:
                    if self.buzzer:
                        self.buzzer.beep(freq=3000, duration=0.1)
                    self.last_beep_time = current_time
        
        
        # ALWAYS update DHT11 for global monitoring (Screensaver needs this)
        if time.ticks_diff(time.ticks_ms(), self.last_dht_read) > self.dht_interval:
            self.read_dht()
            self.last_dht_read = time.ticks_ms()
            
            # If visible, redraw relevant parts
            if self.visible:
                if self.mode == "GRID":
                    self.draw_cell(0) 
                elif self.mode == "DETAIL_DHT11":
                    self.draw_detail_dht11()

        # Only update other display elements if visible
        if self.visible:
            
            # Redraw earthquake sensor cell if in GRID or detail view
            if self.mode == "GRID":
                self.draw_cell(1)  # Update earthquake sensor cell
            elif self.mode == "DETAIL_EARTHQUAKE":
                self.draw_detail_earthquake()
            elif self.mode == "DETAIL_SPIRIT_LEVEL":
                self.draw_detail_spirit_level()
            elif self.mode == "DETAIL_STEP_COUNTER":
                self.draw_detail_step_counter()
            elif self.mode == "ALARM_VIEW":
                # Throttle redraw to save CPU for input handling
                if time.ticks_diff(time.ticks_ms(), self.last_draw_time) > 200:
                    self.draw_alarm_view()
                    self.last_draw_time = time.ticks_ms()
            

            
            # DETAIL_HAND_DETECTION is now passive/removed
            pass

    def read_dht(self):
        if self.dht_sensor:
            try:
                self.dht_sensor.measure()
                self.temp = self.dht_sensor.temperature()
                self.hum = self.dht_sensor.humidity()
            except Exception as e:
                pass
    
    def read_mpu(self):
        """Read MPU-6050 and calculate shake magnitude"""
        if self.mpu:
            try:
                ax, ay, az = self.mpu.get_accel_data()
                
                # Calculate total magnitude (for earthquake detection)
                magnitude = math.sqrt(ax**2 + ay**2 + az**2)
                
                # Subtract gravity (1.0G) to get shake component
                self.shake_magnitude = abs(magnitude - 1.0)
                
                # Calculate Pitch & Roll (for Spirit Level)
                # Roll: Angle around Y-axis
                # Pitch: Angle around X-axis
                self.roll = math.atan2(ay, az) * 57.29578
                self.pitch = math.atan2(-ax, math.sqrt(ay*ay + az*az)) * 57.29578
                
                # Check for balance beep if in Spirit Level mode
                if self.mode == "DETAIL_SPIRIT_LEVEL":
                    p = self.pitch - self.cal_pitch
                    r = self.roll - self.cal_roll
                    if abs(p) < 1.0 and abs(r) < 1.0:
                        if not self.balanced_beep_done:
                            if self.buzzer:
                                self.buzzer.beep(freq=2000, duration=0.1)
                            self.balanced_beep_done = True
                    else:
                        self.balanced_beep_done = False
                
                # --- STEP COUNTING LOGIC ---
                # Simple peak detection
                if self.step_counter_active:
                    current_time = time.ticks_ms()
                    if magnitude > self.step_threshold:
                        if time.ticks_diff(current_time, self.last_step_time) > self.step_cooldown:
                            self.steps += 1
                            self.last_step_time = current_time
                            
                            # Calculate Distance (approx 0.762m per step)
                            self.distance_km = (self.steps * 0.762) / 1000.0
                            
                            # Calculate Calories (approx 0.04 kcal per step)
                            self.calories_kcal = self.steps * 0.04
                            
                            print(f"Step Detected! Total: {self.steps}")
                
                # Update max shake
                if self.shake_magnitude > self.max_shake:
                    self.max_shake = self.shake_magnitude
                
                # Update status based on threshold
                if self.shake_magnitude < self.shake_threshold:
                    self.shake_status = "Normal"
                elif self.shake_magnitude < self.shake_threshold * 2:
                    self.shake_status = "Low Shake"
                else:
                    self.shake_status = "STRONG"
                
                # Simple visual alarm with buzzer
                # Threshold: 1.5G (moderate shake detection)
                # Simple visual alarm with buzzer
                # Threshold: 1.5G (moderate shake detection)
                if self.shake_magnitude > 1.5:
                    current_time = time.ticks_ms()
                    # Check for cooldown
                    if not self.alarm_active and time.ticks_diff(current_time, self.alarm_last_triggered) > self.alarm_cooldown:
                        # Trigger visual alarm + buzzer
                        self.alarm_active = True
                        self.alarm_last_triggered = current_time # Set trigger time
                        self.log_earthquake()
                        print(f"VISUAL ALARM! Shake: {self.shake_magnitude:.3f}G")
                        
                        # Make module visible and switch to alarm view
                        self.visible = True
                        self.mode = "ALARM_VIEW"
                        self.draw()
                        
                        # Start buzzer (non-blocking) - ONLY if enabled
                        if self.buzzer and self.buzzer_enabled:
                            self.buzzer_active = True
                            self.buzzer_start_time = time.ticks_ms()
                            self.last_beep_time = time.ticks_ms()
                    
            except Exception as e:
                print(f"MPU Read Error: {e}")
    
    def start_buzzer(self):
        """Start buzzer alarm"""
        if self.buzzer:
            try:
                self.buzzer.start()
                print("Buzzer started - Earthquake detected!")
            except Exception as e:
                print(f"Buzzer start error: {e}")
    
    def stop_buzzer(self):
        """Stop buzzer alarm"""
        if self.buzzer:
            try:
                self.buzzer.stop()
                print("Buzzer stopped")
            except Exception as e:
                print(f"Buzzer stop error: {e}")
    
    def log_earthquake(self):
        """Log earthquake event with timestamp"""
        try:
            # Get current time from RTC
            # Format: "DD Mon HH:MM"
            current_time = time.localtime()
            timestamp = "{:02d} {:s} {:02d}:{:02d}".format(
                current_time[2],  # day
                ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][current_time[1] - 1],
                current_time[3],  # hour
                current_time[4]   # minute
            )
            
            # Create event record
            event = {
                "timestamp": timestamp,
                "max_magnitude": self.max_shake,
                "duration": 0,  # Will be updated when shake ends
                "logged_at": time.time()  # Unix timestamp for 24h check
            }
            
            # Add to log (keep only last 5)
            self.earthquake_log.insert(0, event)  # Add to beginning
            if len(self.earthquake_log) > self.max_log_size:
                self.earthquake_log = self.earthquake_log[:self.max_log_size]
            
            print(f"Earthquake logged: {timestamp} - {self.max_shake:.3f}G")
            
        except Exception as e:
            print(f"Logging error: {e}")
    
    def clean_old_events(self):
        """Remove events older than 24 hours"""
        try:
            current_time = time.time()
            # Filter events: keep only those less than 24 hours old
            self.earthquake_log = [
                event for event in self.earthquake_log
                if (current_time - event.get("logged_at", 0)) < 86400  # 24 hours in seconds
            ]
        except Exception as e:
            print(f"Clean old events error: {e}")
    
    def stop_alarm(self):
        """Stop alarm (buzzer + reset alarm state)"""
        self.stop_buzzer()
        self.alarm_active = False
        print("Alarm stopped by user")

    def draw(self):
        if not self.visible: return
        
        # Arka plan temizle (Turuncu 0xdd22)
        self.lcd.fill(self.bg_color)
        
        if self.mode == "GRID":
            self.draw_grid_view()
        elif self.mode == "DETAIL_DHT11":
            self.draw_detail_dht11()
        elif self.mode == "DETAIL_EARTHQUAKE":
            self.draw_detail_earthquake()
        elif self.mode == "DETAIL_SPIRIT_LEVEL":
            self.draw_detail_spirit_level()
        elif self.mode == "DETAIL_STEP_COUNTER":
            self.draw_detail_step_counter()
        elif self.mode == "ALARM_VIEW":
            self.draw_alarm_view()


    def draw_grid_view(self):
        # === HEADER ===
        if self.selected_index == 0:
            back_color = 0x07E0 
        else:
            back_color = self.text_color
            
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, self.text_color)
        
        # === GRID ===
        for i in range(len(self.items)):
            self.draw_cell(i)
            
        self.lcd.show()

    def draw_detail_dht11(self):
        # Clear Screen (Orange Background)
        self.lcd.fill(self.bg_color)
        
        # --- HEADER (Back Button) ---
        # Match Grid View Alignment (Single String)
        self.lcd.text("< Back", 5, 5, 0xFFFF)
        self.lcd.hline(0, 20, 320, 0xFFFF) # Separator Line at 20 (was 25, then 20)

        # --- CONTENT (CENTERED) ---
        
        # 1. Title: "LIVING ROOM" (Size 2, White)
        title = "LIVING ROOM"
        title_scale = 2
        title_w = len(title) * (8 * title_scale)
        title_x = (320 - title_w) // 2
        # Y=60 (Centered Vertically)
        self.draw_text_scaled(title, title_x, 60, title_scale, 0xFFFF)
        
        # 2. Icon: Centered (Black Symbol)
        # Y=90 (Centered Vertically)
        icon_y = 90
        if self.dht_icon_data:
            icon_x = (320 - 50) // 2
            # Always Black Icon (0x0000) - Using 0xFFFF due to inversion test result earlier
            self.lcd.draw_bitmap_colored(icon_x, icon_y, 50, 50, self.dht_icon_data, 0xFFFF, None)
            
        # 3. Temperature: "TEMPERATURE 25.0 C" (Size 2, White)
        if self.temp is not None:
            temp_str = f"TEMPERATURE {self.temp} C"
        else:
            temp_str = "TEMPERATURE --.- C"
            
        temp_scale = 2
        temp_w = len(temp_str) * (8 * temp_scale)
        temp_x = (320 - temp_w) // 2
        # Y=160 (Centered Vertically)
        self.draw_text_scaled(temp_str, temp_x, 160, temp_scale, 0xFFFF)
        
        # 4. Humidity: "HUMIDITY 48%" (Size 2, White)
        if self.hum is not None:
            hum_str = f"HUMIDITY {self.hum}%"
        else:
            hum_str = "HUMIDITY --%"
            
        hum_scale = 2
        hum_w = len(hum_str) * (8 * hum_scale)
        hum_x = (320 - hum_w) // 2
        # Y=190 (Centered Vertically)
        self.draw_text_scaled(hum_str, hum_x, 190, hum_scale, 0xFFFF)
        
        self.lcd.show()

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        # 1. Render text to a small temporary buffer
        w = len(text) * 8
        h = 8
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source (RGB565 is 2 bytes)
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    # Draw 'size x size' block
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)
    
    def draw_detail_earthquake(self):
        # Clear Screen (Orange Background)
        self.lcd.fill(self.bg_color)
        
        # --- HEADER (Back Button) ---
        # Highlight Back button if selected (index 0)
        back_color = 0x07E0 if self.selected_index == 0 else 0xFFFF  # Green if selected
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, 0xFFFF)

        # --- CONTENT ---
        
        # 1. Title: "EARTHQUAKE SENSOR" (Small, top)
        title = "EARTHQUAKE SENSOR"
        title_w = len(title) * 8
        title_x = (320 - title_w) // 2
        self.lcd.text(title, title_x, 28, 0xFFFF)
        
        # 2. Current Magnitude (Large, centered)
        if self.mpu:
            mag_str = f"{self.shake_magnitude:.3f}G"
        else:
            mag_str = "NO SENSOR"
        
        mag_scale = 2
        mag_w = len(mag_str) * (8 * mag_scale)
        mag_x = (320 - mag_w) // 2
        self.draw_text_scaled(mag_str, mag_x, 45, mag_scale, 0xFFFF)
        
        # 3. Status
        status_str = f"Status: {self.shake_status}"
        status_w = len(status_str) * 8
        status_x = (320 - status_w) // 2
        self.lcd.text(status_str, status_x, 75, 0xFFFF)
        
        # 4. Earthquake Counter (Badge style)
        event_count = len(self.earthquake_log)
        count_str = f"Total Events: {event_count}"
        count_w = len(count_str) * 8
        count_x = (320 - count_w) // 2
        self.lcd.text(count_str, count_x, 90, 0xFE60)  # Yellow
        
        # 5. Event List
        self.lcd.text("RECENT EVENTS", 10, 110, 0xFFFF)
        self.lcd.hline(10, 120, 300, 0x7BEF)  # Gray line
        
        if len(self.earthquake_log) > 0:
            y_pos = 128
            for i, event in enumerate(self.earthquake_log[:3]):  # Show max 3 events
                # Format: "DD Mon HH:MM | 0.45G"
                event_str = f"{event['timestamp']} | {event['max_magnitude']:.2f}G"
                self.lcd.text(event_str, 15, y_pos, 0xFFFF)
                y_pos += 12
        else:
            self.lcd.text("No events yet", 15, 128, 0x7BEF)  # Gray
        
        # 6. Reset Button (Modern circular style at bottom left)
        reset_x = 100  # Left side
        reset_y = 200  # Bottom area
        reset_radius = 20
        
        # Highlight color based on selection (index 1)
        if self.selected_index == 1:
            outer_color = 0x07E0  # Green if selected
            inner_color = 0xF800  # Red
        else:
            outer_color = 0xFFFF  # White
            inner_color = 0xF800  # Red
        
        # Draw circular button
        # Outer circle
        for r in range(reset_radius, reset_radius - 2, -1):
            self.draw_circle(reset_x, reset_y, r, outer_color)
        
        # Inner fill (red)
        for r in range(reset_radius - 2, 0, -1):
            self.draw_circle(reset_x, reset_y, r, inner_color)
        
        # Reset icon (simple "R" text)
        self.lcd.text("R", reset_x - 4, reset_y - 4, 0xFFFF)
        
        # Reset label below button
        reset_label = "RESET"
        reset_label_w = len(reset_label) * 8
        self.lcd.text(reset_label, reset_x - (reset_label_w // 2), reset_y + 25, 0xFFFF)
        
        # 7. Buzzer Toggle Button (Modern circular style at bottom right)
        buzzer_x = 220  # Right side
        buzzer_y = 200  # Bottom area
        buzzer_radius = 20
        
        # Highlight color based on selection (index 2)
        if self.selected_index == 2:
            buzzer_outer_color = 0x07E0  # Green if selected
        else:
            buzzer_outer_color = 0xFFFF  # White
        
        # Inner color based on buzzer state (green=ON, red=OFF)
        if self.buzzer_enabled:
            buzzer_inner_color = 0x07E0  # Green = ON
        else:
            buzzer_inner_color = 0xF800  # Red = OFF
        
        # Draw circular button
        # Outer circle
        for r in range(buzzer_radius, buzzer_radius - 2, -1):
            self.draw_circle(buzzer_x, buzzer_y, r, buzzer_outer_color)
        
        # Inner fill
        for r in range(buzzer_radius - 2, 0, -1):
            self.draw_circle(buzzer_x, buzzer_y, r, buzzer_inner_color)
        
        # Buzzer icon (simple "B" text)
        self.lcd.text("B", buzzer_x - 4, buzzer_y - 4, 0xFFFF)
        
        # Buzzer label below button
        buzzer_label = "ON" if self.buzzer_enabled else "OFF"
        buzzer_label_w = len(buzzer_label) * 8
        self.lcd.text(buzzer_label, buzzer_x - (buzzer_label_w // 2), buzzer_y + 25, 0xFFFF)
        
        self.lcd.show()
    
    def draw_circle(self, cx, cy, r, color):
        """Draw a circle using midpoint algorithm"""
        x = r
        y = 0
        err = 0
        
        while x >= y:
            self.lcd.pixel(cx + x, cy + y, color)
            self.lcd.pixel(cx + y, cy + x, color)
            self.lcd.pixel(cx - y, cy + x, color)
            self.lcd.pixel(cx - x, cy + y, color)
            self.lcd.pixel(cx - x, cy - y, color)
            self.lcd.pixel(cx - y, cy - x, color)
            self.lcd.pixel(cx + y, cy - x, color)
            self.lcd.pixel(cx + x, cy - y, color)
            
            if err <= 0:
                y += 1
                err += 2 * y + 1
            
            if err > 0:
                x -= 1
                err -= 2 * x + 1
    
    def draw_detail_spirit_level(self):
        """Draw the Digital Spirit Level detail view"""
        self.lcd.fill(self.bg_color)
        
        # --- HEADER (Back Button) ---
        back_color = 0x07E0 if self.selected_index == 0 else 0xFFFF
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, 0xFFFF)
        
        # --- UI LAYOUT ---
        cx, cy = 160, 125  # Center of the level
        radius = 70
        
        # Current adjusted angles
        p = self.pitch - self.cal_pitch
        r = self.roll - self.cal_roll
        
        # Check if balanced (within 1 degree)
        balanced = abs(p) < 1.0 and abs(r) < 1.0
        ui_color = 0x07E0 if balanced else 0xFFFF  # Green if balanced, else White
        
        # 1. Draw Level Housing (Fixed)
        self.draw_circle(cx, cy, radius, ui_color)
        self.draw_circle(cx, cy, radius-1, ui_color)
        
        # Target crosshair (Center hole)
        self.draw_circle(cx, cy, 12, ui_color)
        self.lcd.hline(cx - 20, cy, 40, ui_color)
        self.lcd.vline(cx, cy - 20, 40, ui_color)
        
        # 2. Calculate Bubble Position
        # Map degrees to pixels (radius is 70, let's say 45 degrees max shift)
        max_shift = radius - 15  # Bubble radius is ~10-12
        limit_angle = 30.0 # Degrees for max shift
        
        bx = cx + (r / limit_angle) * max_shift
        by = cy + (p / limit_angle) * max_shift
        
        # Constrain bubble within the main circle
        dist = math.sqrt((bx-cx)**2 + (by-cy)**2)
        if dist > max_shift:
            ratio = max_shift / dist
            bx = cx + (bx-cx) * ratio
            by = cy + (by-cy) * ratio
        
        # 3. Draw Bubble (Moving)
        bubble_radius = 12
        bubble_color = 0x07E0 if balanced else 0xF920 # Bright color
        for br in range(bubble_radius, 0, -1):
            self.draw_circle(int(bx), int(by), br, bubble_color)
        
        # 4. Numeric Values
        self.lcd.text(f"PITCH: {p:.1f} deg", 10, 210, 0xFFFF)
        self.lcd.text(f"ROLL:  {r:.1f} deg", 10, 222, 0xFFFF)
        
        # 5. Calibration Button (Circular at bottom right)
        cal_x, cal_y, cal_r = 260, 215, 18
        cal_highlight = 0x07E0 if self.selected_index == 1 else 0xFFFF
        
        for r_cal in range(cal_r, cal_r - 2, -1):
            self.draw_circle(cal_x, cal_y, r_cal, cal_highlight)
        
        # Draw "CAL" text
        self.lcd.text("CAL", cal_x - 12, cal_y - 4, 0xFFFF)
        
        self.lcd.show()
    
    def draw_detail_step_counter(self):
        """Draw Step Counter Detail View (Centered & New Buttons)"""
        # Clear screen
        self.lcd.fill(self.bg_color) # Orange Background
        
        # Header (Back Button)
        back_color = 0x07E0 if self.selected_index == 0 else 0xFFFF
        self.lcd.text("< Back", 5, 5, back_color)
        self.lcd.hline(0, 20, 320, 0xFFFF)
        
        # Helper for centering scaled text
        def draw_centered_scaled(text, y, scale, color):
            w = len(text) * 8 * scale
            x = (320 - w) // 2
            self.draw_text_scaled(text, x, y, scale, color)

        # 1. Main Steps Display
        draw_centered_scaled(f"{self.steps}", 50, 6, 0xFFFF)
        draw_centered_scaled("STEPS", 110, 2, 0xFFFF) # White Label
        
        # 2. Stats (Distance & Calories) - Centered
        # Distance
        dist_str = f"{self.distance_km:.2f} km"
        dist_w = len(dist_str) * 8
        
        # Calories
        cal_str = f"{int(self.calories_kcal)} kcal"
        cal_w = len(cal_str) * 8
        
        # Draw side by side or vertically? Vertically looks cleaner given the width
        y_stats = 140
        self.lcd.text(dist_str, (320 - dist_w)//2, y_stats, 0xFFFF)
        self.lcd.text(cal_str, (320 - cal_w)//2, y_stats + 20, 0xFFFF)
        
        # 3. Control Buttons (Start/Stop & Reset)
        # Button Dimensions
        btn_y = 200
        btn_w = 100
        btn_h = 30
        gap = 20
        
        # Start/Stop Button (Left) - Index 1
        btn1_x = (320 - (btn_w * 2 + gap)) // 2
        
        if self.selected_index == 1:
            btn1_fill = 0x07E0 # Green (Selected)
            btn1_text = 0x0000 # Black text
        else:
            btn1_fill = 0xFFFF # White (Not selected)
            btn1_text = 0x0000 # Black text
        
        # Label based on state
        lbl1 = "STOP" if self.step_counter_active else "START"
        self.lcd.fill_rect(btn1_x, btn_y, btn_w, btn_h, btn1_fill)
        lbl1_w = len(lbl1) * 8
        self.lcd.text(lbl1, btn1_x + (btn_w - lbl1_w)//2, btn_y + 11, btn1_text)
        
        # Reset Button (Right) - Index 2
        btn2_x = btn1_x + btn_w + gap
        
        if self.selected_index == 2:
            btn2_fill = 0x07E0 # Green (Selected)
            btn2_text = 0x0000 # Black text
        else:
            btn2_fill = 0xFFFF # White (Not selected)
            btn2_text = 0x0000 # Black text
            
        lbl2 = "RESET"
        self.lcd.fill_rect(btn2_x, btn_y, btn_w, btn_h, btn2_fill)
        lbl2_w = len(lbl2) * 8
        self.lcd.text(lbl2, btn2_x + (btn_w - lbl2_w)//2, btn_y + 11, btn2_text)
        
        self.lcd.show()


    def draw_alarm_view(self):
        """Visual earthquake alarm screen (orange background)"""
        # Full screen orange (alarm color)
        self.lcd.fill(0xFD20)  # Bright orange
        
        # Warning title
        title = "! EARTHQUAKE !"
        title_scale = 3
        title_w = len(title) * (8 * title_scale)
        title_x = (320 - title_w) // 2
        self.draw_text_scaled(title, title_x, 40, title_scale, 0xFFFF)
        
        # Magnitude
        mag_str = f"{self.shake_magnitude:.2f}G"
        mag_scale = 4
        mag_w = len(mag_str) * (8 * mag_scale)
        mag_x = (320 - mag_w) // 2
        self.draw_text_scaled(mag_str, mag_x, 100, mag_scale, 0xF800)  # Red
        
        # Max shake
        max_str = f"Max: {self.max_shake:.2f}G"
        max_w = len(max_str) * 8
        max_x = (320 - max_w) // 2
        self.lcd.text(max_str, max_x, 160, 0xFFFF)
        
        # Instructions
        inst1 = "Touch screen or press"
        inst1_w = len(inst1) * 8
        self.lcd.text(inst1, (320 - inst1_w) // 2, 190, 0xFFFF)
        
        inst2 = "button to dismiss"
        inst2_w = len(inst2) * 8
        self.lcd.text(inst2, (320 - inst2_w) // 2, 205, 0xFFFF)
        
        self.lcd.show()

    def draw_cell(self, index):
        # Only draw if we are in GRID mode
        if self.mode != "GRID": return
        if index < 0 or index >= len(self.items): return
        
        item = self.items[index]
        row = index // self.cols
        col = index % self.cols
        
        x = col * self.cell_width
        y = self.header_height + (row * self.cell_height)
        
        # selected_index 1..6 defines items 0..5. Index 0 is Back.
        is_selected = (self.selected_index == index + 1)
        item_color = self.item_colors[index] if index < len(self.item_colors) else 0x07E0
        
        center_x = x + (self.cell_width // 2)
        center_y = y + (self.cell_height // 2)
        
        if is_selected:
            # Highlight border
            self.lcd.rect(x+2, y+2, self.cell_width-4, self.cell_height-4, item_color)
            self.lcd.rect(x+3, y+3, self.cell_width-6, self.cell_height-6, item_color)
            icon_color = 0x0000 
            text_color = 0xFFFF 
        else:
            # Clear border
            self.lcd.rect(x+2, y+2, self.cell_width-4, self.cell_height-4, self.bg_color)
            self.lcd.rect(x+3, y+3, self.cell_width-6, self.cell_height-6, self.bg_color)
            icon_color = 0x0000 
            text_color = 0x0000 

        # --- CONTENT DRAWING (Lazy Loading) ---
        icon_path = item.get("icon_path")
        if icon_path:
            icon_data = self._load_icon(icon_path)
            if icon_data:
                icon_x = center_x - 25
                icon_y = center_y - 45
                # Inverted logic: 0xFFFF produces Black
                self.lcd.draw_bitmap_colored(icon_x, icon_y, 50, 50, icon_data, 0xFFFF, None)
                # Cleanup to save RAM immediately
                icon_data = None
                import gc
                gc.collect()
            else:
                self.lcd.rect(center_x-25, center_y-45, 50, 50, icon_color)
        
        # Label Drawing
        name = item.get("name", "")
        if name == "DHT11":
            self.lcd.text("Temperature", center_x - 44, center_y + 18, text_color)
            self.lcd.text("& Humidity", center_x - 40, center_y + 30, text_color)
        elif name == "Quake":
            self.lcd.text("Earthquake", center_x - 40, center_y + 18, text_color)
            self.lcd.text("Sensor", center_x - 24, center_y + 30, text_color)
        elif name == "Level":
            self.lcd.text("Digital", center_x - 28, center_y + 18, text_color)
            self.lcd.text("Spirit Level", center_x - 48, center_y + 30, text_color)
        else:
            # Generic simple center
            text_w = len(name) * 8
            self.lcd.text(name, center_x - (text_w // 2), center_y + 24, text_color)
    
    def handle_encoder(self, direction):
        if self.mode == "GRID":
            # Normal Navigation
            max_index = len(self.items)
            self.selected_index = (self.selected_index + direction) % (max_index + 1)
            self.draw() # Redraw full grid to update highlights
        elif self.mode == "DETAIL_DHT11":
            # No navigation inside detail view currently, just Back
            pass
        elif self.mode == "DETAIL_EARTHQUAKE":
            # Navigate between Back (0), Reset (1), and Buzzer (2) buttons
            self.selected_index = (self.selected_index + direction) % 3
            self.draw()  # Redraw to update highlights
        elif self.mode == "DETAIL_SPIRIT_LEVEL":
            # Navigate between Back (0) and Calibrate (1)
            self.selected_index = (self.selected_index + direction) % 2
            self.draw() # Redraw to update highlights
        elif self.mode == "DETAIL_STEP_COUNTER":
            # Navigate between Back (0), Start/Stop (1), and Reset (2)
            self.selected_index = (self.selected_index + direction) % 3
            self.draw()
            

        

    def handle_encoder_button(self):
        print(f"EXPERT DEBUG: SensorsModule.handle_encoder_button() | mode={self.mode} | selected={self.selected_index}")
        # Dismiss alarm if in alarm view
        if self.mode == "ALARM_VIEW":
            self.alarm_active = False
            self.buzzer_active = False  # Stop buzzer immediately
            self.alarm_last_triggered = time.ticks_ms() # Start cooldown
            self.mode = "DETAIL_EARTHQUAKE"  # Go to earthquake detail view
            self.draw()
            return None
        
        if self.mode == "GRID":
            if self.selected_index == 0:
                self.hide()
                return "dashboard"
            
            if self.selected_index == 1: # DHT11 Item selected
                self.mode = "DETAIL_DHT11"
                self.draw() # Switch to detail view
                return None
            
            if self.selected_index == 2: # Earthquake Sensor Item selected
                self.selected_index = 0  # Start from Back button
                self.mode = "DETAIL_EARTHQUAKE"
                self.draw() # Switch to detail view
                return None
            
            if self.selected_index == 3: # Spirit Level Item selected
                self.selected_index = 0  # Start from Back button
                self.mode = "DETAIL_SPIRIT_LEVEL"
                self.draw()
                return None
            
            if self.selected_index == 4: # Step Counter Item selected
                self.selected_index = 0 # Start from Back button
                self.mode = "DETAIL_STEP_COUNTER"
                self.draw()
                return None
            
            if self.selected_index == 5: # Slot 5 is Torch
                return "torch"
            
            if self.selected_index == 6: # Slot 6 is Measure
                return "measure"
                
        elif self.mode == "DETAIL_DHT11":
            # Pressing button goes back to grid
            self.mode = "GRID"
            self.selected_index = 1 # Back to DHT11
            self.draw()
        
        elif self.mode == "DETAIL_EARTHQUAKE":
            # Execute action based on selected button
            if self.selected_index == 0:
                # Back button selected - go back to grid
                self.mode = "GRID"
                self.selected_index = 2  # Reset to Earthquake Sensor
                self.draw()
            elif self.selected_index == 1:
                # Reset button selected - clear max shake and log
                self.max_shake = 0.0
                self.earthquake_log = []
                self.draw()
                print("Reset: Max shake and log cleared")
            elif self.selected_index == 2:
                # Buzzer toggle button selected - toggle buzzer on/off
                self.buzzer_enabled = not self.buzzer_enabled
                
                # If buzzer was active and we just disabled it, stop it immediately
                if not self.buzzer_enabled and self.buzzer_active:
                    self.buzzer_active = False
                    print("Buzzer disabled and stopped promptly")
                
                status = "ON" if self.buzzer_enabled else "OFF"
                print(f"Buzzer: {status}")
                self.draw()  # Redraw to update button color
                
        elif self.mode == "DETAIL_SPIRIT_LEVEL":
            if self.selected_index == 0:
                self.mode = "GRID"
                self.selected_index = 3 # Back to Spirit Level
                self.draw()
            elif self.selected_index == 1:
                # Calibrate: set offsets to current values
                self.cal_pitch = self.pitch
                self.cal_roll = self.roll
                print(f"Calibrated: P={self.cal_pitch:.2f}, R={self.cal_roll:.2f}")
                self.draw()
                
        elif self.mode == "DETAIL_STEP_COUNTER":
            print(f"DEBUG: Handling Step Counter Button. Index: {self.selected_index}")
            if self.selected_index == 0:
                self.mode = "GRID"
                self.selected_index = 4 # Back to Step Counter
                self.draw()
            elif self.selected_index == 1:
                # Start/Stop Button
                self.step_counter_active = not self.step_counter_active
                print(f"Step Counter Active: {self.step_counter_active}")
                self.draw()
            elif self.selected_index == 2:
                # Reset steps
                self.steps = 0
                self.distance_km = 0.0
                self.calories_kcal = 0.0
                # If currently active, maybe stop it? Or keep running from 0? Let's keep state.
                print("Step Counter Reset")
                self.draw()
            
                self.draw()
            


    def handle_touch(self, x, y):
        print(f"EXPERT DEBUG: SensorsModule.handle_touch({x}, {y}) | mode={self.mode}")
        # 0. Global Mode Dispatch
        if self.mode == "GRID":
            # --- GRID MODE ---
            # Header (Back Button) - Returns to Dashboard
            if x < 100 and y < 40:
                self.hide()
                return "dashboard"
            
            # Content (Grid Selection)
            if y >= self.header_height:
                col = x // self.cell_width
                row = (y - self.header_height) // self.cell_height
                if 0 <= col < self.cols and 0 <= row < self.rows:
                    index = (row * self.cols) + col
                    print(f"DEBUG: Sensors Grid Click: x={x}, y={y} -> row={row}, col={col}, index={index}")
                    if index < len(self.items):
                        target_index = index + 1
                        
                        # Simplified Touch Logic: ALWAYS OPEN selected item on touch
                        # Update selection for visual feedback
                        self.selected_index = target_index
                        self.draw() # Briefly update highlight
                        
                        if index == 0: # DHT11
                            self.mode = "DETAIL_DHT11"
                            self.draw()
                        elif index == 1: # Earthquake Sensor
                            self.selected_index = 0
                            self.mode = "DETAIL_EARTHQUAKE"
                            self.draw()
                        elif index == 2: # Spirit Level
                            self.selected_index = 0
                            self.mode = "DETAIL_SPIRIT_LEVEL"
                            self.draw()
                        elif index == 3: # Step Counter
                            self.selected_index = 0
                            self.mode = "DETAIL_STEP_COUNTER"
                            self.draw()
                        elif index == 4: # Torch slot
                            return "torch"
                        elif index == 5: # Measure slot
                            return "measure"
            return None

        elif self.mode == "DETAIL_DHT11":
            # --- DHT11 MODE ---
            # ONLY handle Back Button (Top Left)
            # Coordinates for "< Back" text: 5,5 to approx 60,15. 
            # We use x < 80, y < 40 for reliability but narrow enough to avoid center.
            if x < 80 and y < 40:
                print("DEBUG: DHT11 Touch Exit Triggered")
                self.mode = "GRID"
                self.selected_index = 1 # Back to DHT11
                self.draw()
            else:
                print(f"DEBUG: DHT11 Touch Ignored at {x},{y}")
            return None

        elif self.mode == "DETAIL_EARTHQUAKE":
            # --- EARTHQUAKE MODE ---
            # Back Button
            if x < 80 and y < 40:
                self.mode = "GRID"
                self.selected_index = 2
                self.draw()
                return None
            
            # Stop alarm if active
            if self.alarm_active:
                self.stop_alarm()
                return None
            
            # Reset Button
            reset_x, reset_y, reset_r = 100, 200, 20
            dx, dy = x - reset_x, y - reset_y
            if (dx*dx + dy*dy) <= (reset_r * reset_r):
                self.max_shake = 0.0
                self.earthquake_log = []
                self.draw()
                return None
            
            # Buzzer Button
            buz_x, buz_y, buz_r = 220, 200, 20
            dx, dy = x - buz_x, y - buz_y
            if (dx*dx + dy*dy) <= (buz_r * buz_r):
                self.buzzer_enabled = not self.buzzer_enabled
                if not self.buzzer_enabled and self.buzzer_active:
                    self.buzzer_active = False
                self.draw()
                return None
            return None

        elif self.mode == "DETAIL_SPIRIT_LEVEL":
            # --- SPIRIT LEVEL MODE ---
            # Back Button
            if x < 80 and y < 40:
                self.mode = "GRID"
                self.selected_index = 3
                self.draw()
                return None
            
            # Calibration button
            cal_x, cal_y, cal_r = 260, 215, 25
            dx, dy = x - cal_x, y - cal_y
            if (dx*dx + dy*dy) <= (cal_r * cal_r):
                self.cal_pitch, self.cal_roll = self.pitch, self.roll
                self.draw()
                return None
            return None

        elif self.mode == "DETAIL_STEP_COUNTER":
            # --- STEP COUNTER MODE ---
            # Back Button
            if x < 80 and y < 40:
                self.mode = "GRID"
                self.selected_index = 4
                self.draw()
                return None
            
            btn_y, btn_w, btn_h, gap = 200, 100, 30, 20
            btn1_x = (320 - (btn_w * 2 + gap)) // 2
            
            # Start/Stop
            if x >= btn1_x and x <= btn1_x + btn_w and y >= btn_y and y <= btn_y + btn_h:
                self.step_counter_active = not self.step_counter_active
                self.draw()
                return None
            
            # Reset
            btn2_x = btn1_x + btn_w + gap
            if x >= btn2_x and x <= btn2_x + btn_w and y >= btn_y and y <= btn_y + btn_h:
                self.steps, self.distance_km, self.calories_kcal = 0, 0.0, 0.0
                self.draw()
                return None
            return None



        elif self.mode == "DETAIL_HAND_DETECTION":
            # --- HAND DETECTION MODE ---
            if x < 80 and y < 40:
                self.mode = "GRID"
                self.selected_index = 6
                self.draw()
                return None
            return None

        elif self.mode == "ALARM_VIEW":
            # --- ALARM VIEW ---
            self.alarm_active = False
            self.buzzer_active = False
            self.mode = "DETAIL_EARTHQUAKE"
            self.draw()
            return None

        return None
