import time
import random
import framebuf

class SpaceShooter:
    def __init__(self, lcd):
        self.lcd = lcd
        self.width = 320
        self.height = 240
        self.game_active = False
        self.game_over = False
        self.score = 0
        self.highlight_exit = False # For encoder navigation
        
        # Player
        self.player_x = 160
        self.player_y = 210
        self.player_w = 20
        self.player_h = 20
        self.player_speed = 0 # Controlled by tilt
        
        # Game Objects
        self.bullets = []
        self.enemies = []
        self.stars = []
        
        # Settings
        self.enemy_spawn_rate = 1000 # ms
        self.last_enemy_spawn = 0
        self.colors = {
            'bg': 0x0000,
            'star': 0xFFFF,
            'player': 0x07E0, # Green
            'enemy': 0xF800,  # Red
            'bullet': 0xFFE0, # Yellow
            'text': 0xFFFF
        }
        
        # Create initial stars
        for _ in range(30):
            self.stars.append([random.randint(0, self.width), random.randint(0, self.height), random.randint(1, 3)])

    def start(self):
        self.game_active = True
        self.game_over = False
        self.score = 0
        self.player_x = 160
        self.bullets = []
        self.enemies = []
        self.last_enemy_spawn = time.ticks_ms()

    def stop(self):
        self.game_active = False

    def toggle_highlight(self):
        self.highlight_exit = not self.highlight_exit

    def handle_button(self):
        if self.highlight_exit:
            self.stop()
            return "EXIT"
        else:
            self.fire()
            return "FIRE"

    def fire(self):
        if not self.game_active:
            if self.game_over:
                self.start() # Restart if game over
            return
            
        # Add bullet (center of ship)
        # Bullet: [x, y]
        self.bullets.append([self.player_x, self.player_y - 5])

    def update(self, tilt_x):
        if not self.game_active: return

        # 1. Update Player Position
        # tilt_x is roughly -10.0 to 10.0 (m/s^2) but mapped from raw MPU
        
        # Invert logic: Tiling LEFT (positive X usually on sensors) should go LEFT (minus
        # Increased sensitivity: 8 -> 20 as per user request ("slow")
        move_speed = tilt_x * 20 
        self.player_x += int(move_speed)
        
        # Boundary Check
        width_half = self.player_w // 2
        if self.player_x < width_half: self.player_x = width_half
        if self.player_x > self.width - width_half: self.player_x = self.width - width_half

        # 2. Update Stars (Background scroll)
        for star in self.stars:
            star[1] += star[2] # Move down
            if star[1] > self.height:
                star[1] = 0
                star[0] = random.randint(0, self.width)

        # 3. Update Bullets
        active_bullets = []
        for b in self.bullets:
            b[1] -= 8 # Move up speed
            if b[1] > 0:
                active_bullets.append(b)
        self.bullets = active_bullets

        # 4. Spawn Enemies
        now = time.ticks_ms()
        if time.ticks_diff(now, self.last_enemy_spawn) > self.enemy_spawn_rate:
            # Spawn new enemy
            # Enemy: [x, y, w, h]
            ew = random.randint(15, 25)
            ex = random.randint(ew, self.width - ew)
            self.enemies.append([ex, -20, ew, ew]) 
            self.last_enemy_spawn = now
            
            # Speed up slightly over time
            if self.enemy_spawn_rate > 300:
                self.enemy_spawn_rate -= 5

        # 5. Update Enemies & Collisions
        active_enemies = []
        player_rect = (self.player_x - width_half, self.player_y, self.player_w, self.player_h)
        
        for e in self.enemies:
            e[1] += 3 # Enemy speed
            
            # Check collision with Bullets
            hit = False
            remaining_bullets = []
            for b in self.bullets:
                # Bullet rect (3x5)
                # Simple box collision
                if (b[0] >= e[0] - e[2]//2 and b[0] <= e[0] + e[2]//2 and
                    b[1] >= e[1] and b[1] <= e[1] + e[3]):
                    hit = True
                    self.score += 10
                    # Bullet removed
                else:
                    remaining_bullets.append(b)
            self.bullets = remaining_bullets
            
            if hit:
                continue # Enemy destroyed
                
            # Check collision with Player
            # A bit more lenient box collision for player
            if (self.rect_overlap(player_rect, (e[0]-e[2]//2, e[1], e[2], e[3]))):
                self.game_over = True
                self.game_active = False
                
            if e[1] < self.height:
                active_enemies.append(e)
            else:
                # Enemy passed bottom
                pass
                
        self.enemies = active_enemies

    def rect_overlap(self, r1, r2):
        # r: x, y, w, h
        return (r1[0] < r2[0] + r2[2] and
                r1[0] + r1[2] > r2[0] and
                r1[1] < r2[1] + r2[3] and
                r1[1] + r1[3] > r2[1])

    def draw(self):
        # Clear screen (Black)
        self.lcd.fill(self.colors['bg'])

        # Draw Stars
        for star in self.stars:
            self.lcd.pixel(star[0], star[1], self.colors['star'])

        if self.game_active:
            # Draw Player (Triangle)
            px, py = self.player_x, self.player_y
            pw = self.player_w
            ph = self.player_h
            
            x1, y1 = px, py 
            x2, y2 = px - pw//2, py + ph
            x3, y3 = px + pw//2, py + ph
            
            self.lcd.line(x1, y1, x2, y2, self.colors['player'])
            self.lcd.line(x2, y2, x3, y3, self.colors['player'])
            self.lcd.line(x3, y3, x1, y1, self.colors['player'])
            self.lcd.pixel(px, py+5, self.colors['player'])

            # Draw Bullets (Lines)
            for b in self.bullets:
                self.lcd.line(b[0], b[1], b[0], b[1]+5, self.colors['bullet'])

            # Draw Enemies (Rectangles)
            for e in self.enemies:
                self.lcd.rect(e[0] - e[2]//2, e[1], e[2], e[3], self.colors['enemy'])
                self.lcd.line(e[0] - e[2]//2, e[1], e[0] + e[2]//2, e[1] + e[3], self.colors['enemy'])
                self.lcd.line(e[0] + e[2]//2, e[1], e[0] - e[2]//2, e[1] + e[3], self.colors['enemy'])

            # Draw Score
            self.lcd.text(f"SCORE: {self.score}", 60, 5, self.colors['text']) # Moved right due to Exit button
            
            # Draw Exit Button
            exit_color = 0x07E0 if self.highlight_exit else self.colors['text']
            self.lcd.text("< Exit", 5, 5, exit_color)
            
        elif self.game_over:
            # Game Over Screen
            self.centered_text("GAME OVER", 100, self.colors['enemy'], 2)
            self.centered_text(f"FINAL SCORE: {self.score}", 130, self.colors['text'], 1)
            self.centered_text("PRESS BUTTON TO RESTART", 200, self.colors['text'], 1)
            
            # Draw Exit Button
            exit_color = 0x07E0 if self.highlight_exit else self.colors['text']
            self.lcd.text("< Exit", 5, 5, exit_color)
            
        else:
            # Menu Screen (Not active, Not game over)
            self.centered_text("SPACE SHOOTER", 80, self.colors['player'], 2)
            self.centered_text("TILT TO MOVE", 120, self.colors['text'], 1)
            self.centered_text("BUTTON TO FIRE/START", 140, self.colors['text'], 1)
            
        self.lcd.show()

    def centered_text(self, text, y, color, scale=1):
        if scale == 1:
            w = len(text) * 8
            x = (self.width - w) // 2
            self.lcd.text(text, x, y, color)
        else:
            w = len(text) * 8 * scale
            x = (self.width - w) // 2
            self.draw_text_scaled(text, x, y, scale, color)

    def draw_text_scaled(self, text, x, y, size, color):
        """Draw scaled text (pixel doubling/tripling)"""
        # 1. Render text to a small temporary buffer
        w = len(text) * 8
        h = 8
        # Ensure buffer size is valid
        if w == 0: return
        
        buf = bytearray(w * h * 2)
        fb = framebuf.FrameBuffer(buf, w, h, framebuf.RGB565)
        fb.fill(0)
        fb.text(text, 0, 0, color)
        
        # 2. Draw to LCD with scaling
        for row in range(h):
            for col in range(w):
                # Get pixel color from source (RGB565 is 2 bytes)
                idx = (row * w + col) * 2
                c = buf[idx] | (buf[idx+1] << 8)
                
                if c != 0: # If not background
                    # Draw 'size x size' block
                    self.lcd.fill_rect(x + col * size, y + row * size, size, size, c)
