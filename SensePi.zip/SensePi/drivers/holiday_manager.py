"""
Holiday Manager Driver for SensePi
Fetches public holidays from Nager.Date API
Supports multiple country codes (e.g., TR, US, GB)
"""

import time
import ujson

class HolidayManager:
    def __init__(self, wifi_manager):
        self.wifi = wifi_manager
        self.api_url = "https://date.nager.at/api/v3/publicholidays"
        self.holidays = []  # List of holiday objects
        self.last_sync = 0
        self.sync_interval = 24 * 3600  # Sync once a day
        self.countries = ["TR", "US", "GB"]  # Countries to fetch
        
    def sync_holidays(self, year):
        """Fetch holidays for the specified year"""
        if not self.wifi.is_connected():
            print("HolidayManager: No WiFi, cannot sync")
            return False
            
        print(f"HolidayManager: Syncing holidays for {year}...")
        all_holidays = []
        
        for country in self.countries:
            try:
                url = f"{self.api_url}/{year}/{country}"
                print(f"HolidayManager: Fetching {country}...")
                response = self.wifi.http_get(url)
                
                if response:
                    # Append country code to each holiday for display
                    for h in response:
                        h['countryCode'] = country
                        all_holidays.append(h)
                    print(f"HolidayManager: {len(response)} holidays found for {country}")
                else:
                    print(f"HolidayManager: Failed to fetch {country}")
                    
            except Exception as e:
                print(f"HolidayManager: Error fetching {country}: {e}")
                
        # Sort all holidays by date
        # Date format is "YYYY-MM-DD" which is sortable as string
        all_holidays.sort(key=lambda x: x['date'])
        
        self.holidays = all_holidays
        self.last_sync = time.time()
        print(f"HolidayManager: Total {len(self.holidays)} holidays synced")
        return True
        
    def get_next_holiday(self, year, month, day):
        """Find the next upcoming holiday from the current date"""
        if not self.holidays:
            # Try to sync if empty
            if not self.sync_holidays(year):
                return None
                
        # Format current date as YYYY-MM-DD
        current_date_str = f"{year}-{month:02d}-{day:02d}"
        
        for h in self.holidays:
            if h['date'] >= current_date_str:
                return h
                
        # If no holiday found this year (end of year), need to fetch next year
        # For simplicity, just return None or "New Year" logic could be added
        return None
        
    def get_holidays_today(self, year, month, day):
        """Check if today is a holiday"""
        if not self.holidays:
            return []
            
        current_date_str = f"{year}-{month:02d}-{day:02d}"
        today_holidays = [h for h in self.holidays if h['date'] == current_date_str]
        return today_holidays
