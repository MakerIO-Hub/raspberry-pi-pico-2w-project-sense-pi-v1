"""
RTC Driver for SensePi
Supports both Raspberry Pi Pico internal RTC and external DS3231 (I2C)
"""

from machine import RTC, I2C
import time

class RTCDriver:
    def __init__(self, use_external=False, i2c=None):
        """
        Initialize RTC driver
        
        Args:
            use_external: True for DS3231, False for Pico internal RTC
            i2c: I2C instance (required if use_external=True)
        """
        self.use_external = use_external
        self.i2c = i2c
        self.rtc = RTC()  # Pico dahili RTC
        
        if use_external:
            if not i2c:
                raise ValueError("I2C gerekli (DS3231 için)")
            self.ds3231_addr = 0x68
            print("RTC: DS3231 kullanılıyor (I2C)")
        else:
            print("RTC: Pico dahili RTC kullanılıyor")
            
    def set_time(self, year, month, day, hour, minute, second, weekday=0):
        """
        Set RTC time
        
        Args:
            year: 2026
            month: 1-12
            day: 1-31
            hour: 0-23
            minute: 0-59
            second: 0-59
            weekday: 0-6 (Monday=0)
        """
        if self.use_external:
            self._set_ds3231_time(year, month, day, hour, minute, second, weekday)
        else:
            # Pico RTC: (year, month, day, weekday, hour, minute, second, subseconds)
            self.rtc.datetime((year, month, day, weekday, hour, minute, second, 0))
            
        print(f"RTC: Saat ayarlandı -> {year}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}:{second:02d}")
        
    def get_time(self):
        """
        Get current time from RTC
        
        Returns:
            dict: {"year": int, "month": int, "day": int, "hour": int, "minute": int, "second": int, "weekday": int}
        """
        if self.use_external:
            return self._get_ds3231_time()
        else:
            dt = self.rtc.datetime()
            return {
                "year": dt[0],
                "month": dt[1],
                "day": dt[2],
                "weekday": dt[3],
                "hour": dt[4],
                "minute": dt[5],
                "second": dt[6]
            }
            
    def sync_from_ntp(self, ntp_time):
        """
        Synchronize RTC from NTP time
        
        Args:
            ntp_time: dict from NTPManager.get_time()
        """
        self.set_time(
            ntp_time["year"],
            ntp_time["month"],
            ntp_time["day"],
            ntp_time["hour"],
            ntp_time["minute"],
            ntp_time["second"],
            ntp_time.get("weekday", 0)
        )
        print("RTC: NTP ile senkronize edildi")
        
    # ===== DS3231 Specific Methods =====
    
    def _bcd_to_dec(self, bcd):
        """Convert BCD to decimal"""
        return ((bcd // 16) * 10) + (bcd % 16)
        
    def _dec_to_bcd(self, dec):
        """Convert decimal to BCD"""
        return ((dec // 10) * 16) + (dec % 10)
        
    def _set_ds3231_time(self, year, month, day, hour, minute, second, weekday):
        """Set DS3231 RTC time via I2C"""
        # DS3231 register addresses
        self.i2c.writeto_mem(self.ds3231_addr, 0x00, bytes([self._dec_to_bcd(second)]))
        self.i2c.writeto_mem(self.ds3231_addr, 0x01, bytes([self._dec_to_bcd(minute)]))
        self.i2c.writeto_mem(self.ds3231_addr, 0x02, bytes([self._dec_to_bcd(hour)]))
        self.i2c.writeto_mem(self.ds3231_addr, 0x03, bytes([self._dec_to_bcd(weekday + 1)]))  # DS3231: 1-7
        self.i2c.writeto_mem(self.ds3231_addr, 0x04, bytes([self._dec_to_bcd(day)]))
        self.i2c.writeto_mem(self.ds3231_addr, 0x05, bytes([self._dec_to_bcd(month)]))
        self.i2c.writeto_mem(self.ds3231_addr, 0x06, bytes([self._dec_to_bcd(year - 2000)]))  # Year offset
        
    def _get_ds3231_time(self):
        """Get DS3231 RTC time via I2C"""
        # Read 7 bytes starting from register 0x00
        data = self.i2c.readfrom_mem(self.ds3231_addr, 0x00, 7)
        
        return {
            "second": self._bcd_to_dec(data[0] & 0x7F),
            "minute": self._bcd_to_dec(data[1] & 0x7F),
            "hour": self._bcd_to_dec(data[2] & 0x3F),
            "weekday": self._bcd_to_dec(data[3] & 0x07) - 1,  # Convert to 0-6
            "day": self._bcd_to_dec(data[4] & 0x3F),
            "month": self._bcd_to_dec(data[5] & 0x1F),
            "year": self._bcd_to_dec(data[6]) + 2000
        }
