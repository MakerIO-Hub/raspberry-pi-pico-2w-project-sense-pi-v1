"""
Google Calendar Driver for SensePi
Fetches daily agenda from a Google Apps Script Web App (JSON Proxy).
"""

class GoogleCalendarDriver:
    def __init__(self, wifi_manager, script_url):
        self.wifi_manager = wifi_manager
        self.script_url = script_url
        
    def get_daily_agenda(self):
        """
        Fetches today's events from the Google Apps Script URL.
        
        Returns:
            list: [
                {
                    "title": "Meeting",
                    "time": "14:30", (or "All Day")
                    "location": "Room 101",
                    "description": "..."
                },
                ...
            ]
            or None on error.
        """
        if not self.wifi_manager.is_connected():
            print("GoogleCalendar: WiFi baglantisi yok!")
            return None
            
        if not self.script_url or self.script_url == "":
            print("GoogleCalendar: Script URL tanimli degil!")
            return None
            
        try:
            print("GoogleCalendar: Ajanda cekiliyor...")
            # Follow redirects is crucial for Google Apps Script URLs
            # But simple http_get might handle it if using requests or urequests
            # WiFiManager.http_get implementation needs to support redirects or the URL must be the final one.
            # Google Apps Script Web App URLs usually redirect.
            # Let's assume standard urequests behavior (usually follows redirects).
            
            data = self.wifi_manager.http_get(self.script_url, timeout=5, parse_json=True)
            
            # Print raw data regardless of check
            print(f"DEBUG: Calendar Raw Data -> {data}")
            
            if data is not None:
                # Check if data is list (new format) or dict (old format error)
                if not isinstance(data, list):
                    print("GoogleCalendar: HATA! Beklenen foat liste degil.")
                    return None
                    
                events = []
                events = []
                for item in data:
                    # Daily format: t=Title, tm=Time
                    events.append({
                        "time": item.get("tm", "??:??"),
                        "title": item.get("t", "No Title")
                    })
                
                print(f"GoogleCalendar: {len(events)} etkinlik alindi.")
                return events
            else:
                print("GoogleCalendar: Veri alinamadi veya bos.")
                return None
                
        except Exception as e:
            print(f"GoogleCalendar: Hata - {e}")
            return None
