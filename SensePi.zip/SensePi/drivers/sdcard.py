from machine import Pin
import time

class SDCard:
    def __init__(self, spi, cs):
        self.spi = spi
        self.cs = cs

        self.cmdbuf = bytearray(6)
        self.dummybuf = bytearray(512)
        self.tokenbuf = bytearray(1)
        for i in range(512):
            self.dummybuf[i] = 0xFF
        self.dummybuf_v = memoryview(self.dummybuf)

        self.init_card()

    def init_card(self):
        self.cs.init(Pin.OUT, value=1)
        # Kartı düşük hızda başlat (Kritik: < 400kHz)
        self.spi.init(baudrate=100000)
        
        # clock card at least 100 cycles with cs high
        for i in range(16):
            self.spi.write(b"\xff")

        # CMD0: go idle state
        if self.cmd(0, 0, 0x95) != 1:
            # Tekrar sına
            time.sleep_ms(100)
            if self.cmd(0, 0, 0x95) != 1:
                raise OSError("no SD card")

        # CMD8: confirm voltage range
        r = self.cmd(8, 0x01AA, 0x87, 4)
        if r == 1:
            self.init_card_v2()
        else:
            self.init_card_v1()

        # fast speed
        self.spi.init(baudrate=13200000)

    def init_card_v1(self):
        for i in range(100):
            self.cmd(55, 0, 0)
            if self.cmd(41, 0, 0) == 0:
                self.cdv = 512
                return
        raise OSError("SD card init failed")

    def init_card_v2(self):
        for i in range(100):
            time.sleep_ms(50)
            self.cmd(55, 0, 0)
            if self.cmd(41, 0x40000000, 0) == 0:
                # CMD58: Read OCR (Operation Conditions Register)
                # Kartın SDHC/SDXC olup olmadığını anlamak için bu şart!
                self.cmd(58, 0, 0, 4)
                
                # Yanıtı tokenbuf'a aldık (ilk byte R1, sonraki 4 byte OCR)
                # OCR register'ının 30. biti (CCS) 1 ise kart block-addressed (SDHC/SDXC) demektir.
                # Bizim spi.read() metodumuz CMD fonksiyonunda, final=4 ile OCR'ı okuyor.
                # Ancak burada self.tokenbuf sadece 1 byte, OCR verisi CMD fonksiyon dönüşünde.
                
                # Bu yüzden cmd metodunu tekrar çağırıp veriyi alalım ya da logic'i revize edelim.
                # Basit çözüm: CMD58'i tekrar çağırıp veriyi alalım.
                ocr = self.read_ocr()
                
                # OCR'ın 30. biti (0x40000000) CCS bitidir.
                # SDHC/SDXC kartlarda bu 1 olur.
                if (ocr[0] & 0x40): 
                    self.cdv = 1 # Block addressing (32GB+ için gerekli)
                    print("SD Kart Tipi: SDHC/SDXC (Block Addressing)")
                else: 
                    self.cdv = 512 # Byte addressing (Eski kartlar)
                    print("SD Kart Tipi: SDSC (Byte Addressing)")
                return
        raise OSError("SD card init failed")

    def read_ocr(self):
        # CMD58 gönder ve 4 byte OCR verisini oku
        self.cs(0)
        self.spi.write(bytearray([0x40 | 58, 0, 0, 0, 0, 0]))
        
        # R1 yanıtını bekle
        for i in range(128):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if not (self.tokenbuf[0] & 0x80):
                break
        
        # 4 Byte OCR oku
        ocr = self.spi.read(4, 0xFF)
        self.cs(1)
        self.spi.write(b"\xff")
        return ocr

    def cmd(self, cmd, arg, crc, final=0):
        self.cs(0)

        # create and send the command
        buf = self.cmdbuf
        buf[0] = 0x40 | cmd
        buf[1] = arg >> 24
        buf[2] = arg >> 16
        buf[3] = arg >> 8
        buf[4] = arg
        buf[5] = crc
        self.spi.write(buf)

        # wait for the response (R1 byte)
        for i in range(128):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if not (self.tokenbuf[0] & 0x80):
                break

        # receive more bytes if needed
        res = self.tokenbuf[0]
        if final > 0:
            res = self.spi.read(final, 0xFF)

        self.cs(1)
        self.spi.write(b"\xff")
        return res

    def readblocks(self, block_num, buf):
        nblocks = len(buf) // 512
        assert len(buf) % 512 == 0, "Buffer size must be multiple of 512"
        if nblocks == 1:
            # CMD17: read single block
            if self.cmd(17, block_num * self.cdv, 0) != 0:
                return 1
            # receive the data
            if self.read_data(buf):
                return 1
        else:
            # CMD18: read multiple blocks
            if self.cmd(18, block_num * self.cdv, 0) != 0:
                return 1
            offset = 0
            while nblocks > 0:
                if self.read_data(memoryview(buf)[offset : offset + 512]):
                    return 1
                offset += 512
                nblocks -= 1
            # CMD12: stop transmission
            self.cmd(12, 0, 0)
        return 0

    def writeblocks(self, block_num, buf):
        nblocks = len(buf) // 512
        assert len(buf) % 512 == 0, "Buffer size must be multiple of 512"
        if nblocks == 1:
            # CMD24: write single block
            if self.cmd(24, block_num * self.cdv, 0) != 0:
                return 1
            # send the data
            if self.write_data(0xFE, buf):
                return 1
        else:
            # CMD25: write multiple blocks
            if self.cmd(25, block_num * self.cdv, 0) != 0:
                return 1
            offset = 0
            while nblocks > 0:
                if self.write_data(0xFC, memoryview(buf)[offset : offset + 512]):
                    return 1
                offset += 512
                nblocks -= 1
            # end token
            self.write_data(0xFD, None)
        return 0

    def read_data(self, buf):
        self.cs(0)
        # wait for start token
        for i in range(1000):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if self.tokenbuf[0] == 0xFE:
                break
        else:
            self.cs(1)
            return 1
        # read data
        self.spi.readinto(buf, 0xFF)
        # read CRC (2 bytes)
        self.spi.read(2, 0xFF)
        self.cs(1)
        self.spi.write(b"\xff")
        return 0

    def write_data(self, token, buf):
        self.cs(0)
        # send start token
        self.spi.write(bytearray([token]))
        if buf:
            # send data and dummy CRC
            self.spi.write(buf)
            self.spi.write(b"\xff\xff")
            # get response
            self.spi.readinto(self.tokenbuf, 0xFF)
            if (self.tokenbuf[0] & 0x1F) != 0x05:
                self.cs(1)
                return 1
            # wait for end of write
            while True:
                self.spi.readinto(self.tokenbuf, 0xFF)
                if self.tokenbuf[0] != 0:
                    break
        self.cs(1)
        self.spi.write(b"\xff")
        return 0

    def ioctl(self, op, arg):
        if op == 4: # count
            return 32 * 1024 * 1024 * 1024 // 512 # Simplified count
        if op == 5: # block size
            return 512
