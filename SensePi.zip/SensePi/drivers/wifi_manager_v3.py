"""
WiFi Manager for SensePi - V3 (Force Update)
Handles WiFi connection and HTTP requests for internet-dependent modules
"""

import network
import time
import urequests
import ujson

class WiFiManager:
    def __init__(self, ssid=None, password=None):
        print("DEBUG: WiFiManager (Drivers V3 - Force Loaded) Initialized")
        self.ssid = ssid
        self.password = password
        self.wlan = network.WLAN(network.STA_IF)
        self.wlan.active(True)
        
    def connect(self, ssid=None, password=None):
        """Connect to WiFi network"""
        if ssid:
            self.ssid = ssid
        if password:
            self.password = password
            
        if not self.ssid or not self.password:
            print("WiFi: SSID ve Password gerekli!")
            return False
            
        if self.is_connected():
            print(f"WiFi: Zaten bağlı ({self.wlan.ifconfig()[0]})")
            return True
            
        print(f"WiFi: Bağlanılıyor -> {self.ssid}")
        self.wlan.connect(self.ssid, self.password)
        
        # 10 saniye bekle
        max_wait = 10
        while max_wait > 0:
            if self.wlan.status() < 0 or self.wlan.status() >= 3:
                break
            max_wait -= 1
            print("WiFi: Bekleniyor...")
            time.sleep(1)
            
        if self.wlan.status() != 3:
            print(f"WiFi: Bağlantı başarısız! Status: {self.wlan.status()}")
            return False
        else:
            status = self.wlan.ifconfig()
            print(f"WiFi: Bağlandı! IP: {status[0]}")
            return True
            
    def disconnect(self):
        """Disconnect from WiFi"""
        if self.wlan.isconnected():
            self.wlan.disconnect()
            print("WiFi: Bağlantı kesildi")
            
    def is_connected(self):
        """Check if WiFi is connected"""
        return self.wlan.isconnected()
        
    def get_ip(self):
        """Get current IP address"""
        if self.is_connected():
            return self.wlan.ifconfig()[0]
        return None
        
    def http_get(self, url, timeout=10, parse_json=True, headers=None, stream=False):
        """
        HTTP GET request helper with Redirect support and Memory Efficiency
        Returns: dict (JSON) or str (Text) or None on error
        If stream=True, returns the urequests.Response object (Caller MUST close it)
        """
        if not self.is_connected():
            print("WiFi: Baglanti yok, HTTP request yapilamiyor")
            return None
            
        # Default Headers (Browser-like User-Agent for better compatibility)
        req_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Accept": "*/*"
        }
        if headers:
            req_headers.update(headers)
            
        try:
            print(f"HTTP GET: {url}")
            import gc
            gc.collect()
            
            # Simple redirect handling loop (max 3 redirects)
            for _ in range(3):
                print(f"HTTP: Sending request (Timeout={timeout}s)...")
                try:
                    response = urequests.get(url, timeout=timeout, headers=req_headers)
                except OSError as e:
                    print(f"HTTP: Request timeout or error: {e}")
                    continue
                
                print(f"HTTP: Response received (Status: {response.status_code})")
                
                # Handle Redirects
                if response.status_code in [301, 302, 303, 307, 308]:
                    if "Location" in response.headers:
                        new_url = response.headers["Location"]
                        print(f"HTTP: Redirecting to -> {new_url}")
                        response.close()
                        url = new_url
                        continue 
                    else:
                        print("HTTP: Redirect status but no Location header")
                        break
                
                # Success
                if response.status_code == 200:
                    try:
                        if stream:
                            print("HTTP: Streaming mode active. Returning response object.")
                            return response
                            
                        print(f"HTTP: Reading stream (JSON={parse_json})...")
                        gc.collect()
                        
                        chunks = []
                        response_size = 0
                        max_size = 49152 # 48KB Limit (TCMB XML is around 30KB)
                        chunk_size = 512
                        aborted = False
                        
                        while True:
                            try:
                                chunk = response.raw.read(chunk_size)
                                if not chunk: 
                                    break
                                
                                # HTML Check on First Chunk (If expecting JSON)
                                if parse_json and response_size == 0:
                                    start_str = chunk.strip()[:20]
                                    if start_str.startswith(b"<") or start_str.startswith(b"<!ODC"):
                                        print("HTTP: Warning - HTML Content detected instead of JSON!")
                                        aborted = True
                                        break
                                
                                chunks.append(chunk)
                                response_size += len(chunk)
                                
                                if response_size > max_size:
                                    print(f"HTTP: Data too large (> {max_size} bytes), aborting.")
                                    aborted = True
                                    break
                                    
                                if len(chunks) % 10 == 0:
                                    gc.collect()
                                    
                            except Exception as e:
                                print(f"HTTP: Read Error: {e}")
                                aborted = True
                                break
                                
                        response.close()
                        
                        if aborted:
                            return None
                            
                        print(f"HTTP: Read {response_size} bytes. Concatenating...")
                        gc.collect()
                        
                        raw_data = b"".join(chunks)
                        chunks = None 
                        gc.collect()
                        
                        if parse_json:
                            print("HTTP: Parsing JSON...")
                            try:
                                return ujson.loads(raw_data) 
                            except ValueError as e:
                                print(f"HTTP: JSON Decode Error: {e}")
                                return None
                        else:
                            # Return as text (decode from bytes)
                            try:
                                return raw_data.decode('utf-8')
                            except:
                                # Fallback to latin-1 if utf-8 fails (sometimes useful for XMLs)
                                return raw_data.decode('latin-1')
                                
                    except Exception as ex:
                        print(f"HTTP: Process Error: {ex}")
                        response.close()
                        return None
                else:
                    print(f"HTTP Error: {response.status_code}")
                    response.close()
                    return None
            
            print("HTTP: Too many redirects or failed")
            return None

        except OSError as e:
            print(f"HTTP Timeout/OS Error: {e}")
            return None
        except Exception as e:
            print(f"HTTP Request General Error: {e}")
            return None
            
    def scan_networks(self):
        """Scan for available WiFi networks"""
        print("WiFi: Ağlar taranıyor...")
        networks = self.wlan.scan()
        
        print(f"Bulunan ağ sayısı: {len(networks)}")
        for net in networks:
            ssid = net[0].decode('utf-8')
            rssi = net[3]
            print(f"  - {ssid} (Sinyal: {rssi} dBm)")
            
        return networks
