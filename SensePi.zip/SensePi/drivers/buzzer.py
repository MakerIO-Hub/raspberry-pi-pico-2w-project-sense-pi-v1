from machine import Pin, PWM
import time

class BuzzerDriver:
    def __init__(self, pin_num=14):
        self.pin_num = pin_num
        self.pwm = PWM(Pin(pin_num))
        self.pwm.duty_u16(0) # Start silence
        self.active = False
        self.volume = 100 # Default 100%
        
    def set_volume(self, vol_percent):
        """Set volume 0-100 (using a simple squared curve for better perception)"""
        v = max(0, min(vol_percent, 100))
        # Quadratic scaling: (vol/100)^2 * 32768
        self.volume_duty = int(32768 * (v * v) / 10000)
        self.volume = v

    def beep(self, freq=2000, duration=0.1):
        """Single melodic beep"""
        self.pwm.freq(freq)
        self.pwm.duty_u16(self.volume_duty)
        time.sleep(duration)
        self.pwm.duty_u16(0)
        
    def play_alarm_step(self, step):
        """
        High-volume resonant frequency melody.
        Optimized for 3.3V maximum loudness.
        """
        # Small buzzers are loudest between 2000Hz and 4000Hz
        notes = [2700, 3100, 3500] 
        for note in notes:
            self.pwm.freq(note)
            self.pwm.duty_u16(self.volume_duty) 
            time.sleep(0.12)
        
        self.pwm.duty_u16(0)
        time.sleep(0.15)
        
    def start(self):
        """Ultra-loud alert tone"""
        self.pwm.freq(3000) # Resonant peak
        self.pwm.duty_u16(self.volume_duty)
        self.active = True

        
    def stop(self):
        """Stop sound"""
        self.pwm.duty_u16(0)
        self.active = False
        
    def click(self):
        """Very short high-pitch click for UI"""
        self.pwm.freq(4000)
        self.pwm.duty_u16(10000)
        time.sleep(0.005)
        self.pwm.duty_u16(0)

