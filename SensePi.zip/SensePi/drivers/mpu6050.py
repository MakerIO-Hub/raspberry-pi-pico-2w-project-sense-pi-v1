from machine import I2C
import time

class MPU6050:
    """MPU-6050 Accelerometer & Gyroscope Driver"""
    
    # MPU-6050 Registers
    PWR_MGMT_1 = 0x6B
    ACCEL_XOUT_H = 0x3B
    GYRO_XOUT_H = 0x43
    TEMP_OUT_H = 0x41
    
    def __init__(self, i2c, address=0x68):
        self.i2c = i2c
        self.address = address
        
        # Wake up the MPU-6050 (it starts in sleep mode)
        self.i2c.writeto_mem(self.address, self.PWR_MGMT_1, b'\x00')
        time.sleep(0.1)
        
        # Calibration offsets (can be adjusted)
        self.accel_offset = [0, 0, 0]
        
    def read_raw_data(self, addr):
        """Read 2 bytes from register and convert to signed 16-bit value"""
        high = self.i2c.readfrom_mem(self.address, addr, 1)[0]
        low = self.i2c.readfrom_mem(self.address, addr + 1, 1)[0]
        
        # Combine bytes
        value = (high << 8) | low
        
        # Convert to signed
        if value > 32768:
            value = value - 65536
            
        return value
    
    def get_accel_data(self):
        """
        Read accelerometer data (X, Y, Z)
        Returns: (x, y, z) in G units (1G = 9.8 m/s²)
        """
        # Read raw values
        x = self.read_raw_data(self.ACCEL_XOUT_H)
        y = self.read_raw_data(self.ACCEL_XOUT_H + 2)
        z = self.read_raw_data(self.ACCEL_XOUT_H + 4)
        
        # Convert to G (default sensitivity: ±2g, scale factor: 16384 LSB/g)
        ax = x / 16384.0
        ay = y / 16384.0
        az = z / 16384.0
        
        return (ax, ay, az)
    
    def get_gyro_data(self):
        """
        Read gyroscope data (X, Y, Z)
        Returns: (x, y, z) in degrees/second
        """
        # Read raw values
        x = self.read_raw_data(self.GYRO_XOUT_H)
        y = self.read_raw_data(self.GYRO_XOUT_H + 2)
        z = self.read_raw_data(self.GYRO_XOUT_H + 4)
        
        # Convert to degrees/second (default sensitivity: ±250°/s, scale factor: 131 LSB/°/s)
        gx = x / 131.0
        gy = y / 131.0
        gz = z / 131.0
        
        return (gx, gy, gz)
    
    def get_temp(self):
        """
        Read temperature sensor
        Returns: Temperature in Celsius
        """
        raw_temp = self.read_raw_data(self.TEMP_OUT_H)
        # Convert to Celsius: Temp = (TEMP_OUT / 340) + 36.53
        temp = (raw_temp / 340.0) + 36.53
        return temp
    
    def calibrate(self, samples=100):
        """
        Simple calibration: measure average offset when sensor is at rest
        Call this when sensor is stationary and level
        """
        print("Calibrating MPU-6050... Keep sensor still!")
        
        sum_x, sum_y, sum_z = 0, 0, 0
        
        for _ in range(samples):
            ax, ay, az = self.get_accel_data()
            sum_x += ax
            sum_y += ay
            sum_z += az - 1.0  # Z should be ~1G when level
            time.sleep(0.01)
        
        self.accel_offset[0] = sum_x / samples
        self.accel_offset[1] = sum_y / samples
        self.accel_offset[2] = sum_z / samples
        
        print(f"Calibration complete: Offsets = {self.accel_offset}")
