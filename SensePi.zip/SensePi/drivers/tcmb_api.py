"""
TCMB (Merkez Bankasi) API Surucusu
SensePi icin ozel olarak hazirlanmistir.
XML parsing islemi basit string operasyonlari ile yapilir (MicroPython uyumlu).
"""

class TCMBDriver:
    def __init__(self, wifi_manager):
        self.wifi_manager = wifi_manager
        self.url = "https://www.tcmb.gov.tr/kurlar/today.xml"
        
    def get_rates(self):
        """
        TCMB'den guncel kurlari ceker.
        Donus:
        {
            "USD": {"alis": 30.50, "satis": 30.60},
            "EUR": {"alis": 33.10, "satis": 33.20},
            "GBP": {"alis": 38.50, "satis": 38.70},
            "tarih": "09.02.2026"
        }
        veya None (hata durumunda)
        """
        if not self.wifi_manager.is_connected():
            print("TCMB: No WiFi connection!")
            return None
            
        print("TCMB: Requesting rates (Stream Mode V2)...")
        import gc
        gc.collect()
        
        # Stream request to save memory
        response = self.wifi_manager.http_get(self.url, parse_json=False, stream=True)
        
        if not response:
            print("TCMB: No data received!")
            return None
            
        try:
            # Memory efficient stream parsing
            # We will read chunks and search for patterns in a sliding window
            # Window size needs to be large enough to contain a full <Currency> block or at least the fields we need
            
            result = {}
            currencies = ["USD", "EUR", "GBP", "CHF", "JPY", "CAD", "AUD", "RUB"]
            
            # Temporary storage
            buffer = ""
            date_found = False
            
            # Helper to extract value between tags
            def extract(text, start_tag, end_tag):
                s = text.find(start_tag)
                if s == -1: return None
                e = text.find(end_tag, s)
                if e == -1: return None
                return text[s+len(start_tag):e]

            while True:
                chunk = response.raw.read(512) # Read small chunks
                if not chunk:
                    break
                    
                # Decode chunk (careful with multibyte chars split across chunks, but for XML tags it's usually fine)
                try:
                    text_chunk = chunk.decode('utf-8')
                except:
                    text_chunk = chunk.decode('latin-1')
                    
                buffer += text_chunk
                
                # Keep buffer size manageable, but keep enough overlap for cross-chunk patterns
                # Structure: <Currency ... Kod="USD" ...> ... </Currency>
                # Typical block is ~500 chars. 
                if len(buffer) > 2048:
                    # Keep last 1024 chars for overlap
                    buffer = buffer[-1024:]
                
                # 1. Find Date (only once)
                if not date_found:
                    # <Tarih_Date Tarih="06.02.2026"
                    t_val = extract(buffer, 'Tarih="', '"')
                    if t_val:
                        result["tarih"] = t_val
                        date_found = True
                
                # 2. Process Currencies
                # We look for completed <Currency ...> ... </Currency> blocks?
                # Faster: Just look for pattern Kod="USD".*?</Currency> (regex style but manual)
                # Since buffer slides, we might catch partials.
                
                for code in currencies:
                    if code in result: continue # Already found
                    
                    search_str = f'Kod="{code}"'
                    pos = buffer.find(search_str)
                    
                    if pos != -1:
                        # We found the start of this currency
                        # Now check if we have enough data for Buying/Selling
                        # We need <ForexBuying> and <ForexSelling> and <CrossRateUSD>
                        # These come AFTER Kod="...".
                        
                        # Optimization: Extract substring starting from pos
                        sub = buffer[pos:]
                        
                        buy = extract(sub, "<ForexBuying>", "</ForexBuying>")
                        sell = extract(sub, "<ForexSelling>", "</ForexSelling>")
                        cross = extract(sub, "<CrossRateUSD>", "</CrossRateUSD>")
                        
                        # Check if we have what we need (Buying/Selling usually mandatory)
                        # NOTE: If buffer ends before </ForexSelling>, buy/sell will be None.
                        # In that case we wait for more data (continue loop).
                        # But loop changes buffer.
                        # Actually, if we found matches, we save them. If not, we hope next chunk completes it.
                        
                        if buy and sell:
                            item = {
                                "alis": float(buy) if buy and buy.strip() else 0.0,
                                "satis": float(sell) if sell and sell.strip() else 0.0
                            }
                            if cross and cross.strip():
                                try:
                                    item["cross"] = float(cross)
                                except: pass
                                
                            result[code] = item
                            print(f"TCMB: Found {code}")
                            
                gc.collect()

            response.close()
            
            if "tarih" not in result:
                result["tarih"] = "Unknown"
                
            print(f"TCMB: Processed (Found {len(result) - 1} currencies)")
            return result
            
        except Exception as e:
            print(f"TCMB: Parsing error - {e}")
            if response: response.close()
            return None
