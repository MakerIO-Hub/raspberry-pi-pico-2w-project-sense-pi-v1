import time
import gc

class QuakeEvent:
    def __init__(self, magnitude, location, depth, timestamp, lat, lon, country_code="TR"):
        self.magnitude = float(magnitude)
        self.location = str(location)
        self.depth = float(depth)
        self.timestamp = int(timestamp)
        self.lat = float(lat)
        self.lon = float(lon)
        self.country_code = country_code
        self.time_str = self._format_time(timestamp)

    def _format_time(self, timestamp):
        t = time.localtime(timestamp)
        return "{:02d}:{:02d}".format(t[3], t[4])

class QuakeAPI:
    def __init__(self, wifi_manager):
        self.wifi = wifi_manager
        # USGS FDSNWS API (Dynamic Query)
        # limit=10: Sadece son 10 deprem (Hafiza dostu)
        # minmagnitude=2.5: Kucuk depremleri ele (Gurultuyu azalt)
        self.api_url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&limit=10&orderby=time&minmagnitude=2.5"
        print("DEBUG: QuakeAPI (USGS FDSNWS) Initialized")

    def get_quakes(self, country_code="GL", limit=10):
        gc.collect()
        
        print(f"QuakeAPI: Fetching USGS data... (Global Last {limit})")
        # USGS'den veriyi cek
        data = self.wifi.http_get(self.api_url, timeout=15)
        
        events = []
        if data and isinstance(data, dict) and "features" in data:
            features = data["features"]
            print(f"DEBUG: Total features received: {len(features)}")
            
            for item in features:
                # API zaten limit=10 ve sirali donuyor, donguyu kirmaya gerek yok
                # API zaten minmagnitude=2.5 donuyor (URL parametresi)
                
                try:
                    props = item["properties"]
                    geometry = item["geometry"]
                    
                    # Veri Cikarimi
                    place = props.get("place", "Unknown")
                    mag = props.get("mag", 0)

                    coords = geometry["coordinates"] # [lon, lat, depth]
                    depth = coords[2]
                    lon = coords[0]
                    lat = coords[1]
                    
                    # Zaman (USGS ms cinsinden verir, saniyeye cevir)
                    timestamp = int(props["time"] / 1000)
                    
                    # Event Olustur
                    event = QuakeEvent(
                        magnitude=mag,
                        location=place,
                        depth=depth,
                        timestamp=timestamp, # Now int
                        lat=lat,
                        lon=lon,
                        country_code=country_code
                    )
                    
                    events.append(event)
                    
                    
                except Exception as e:
                    print(f"QuakeAPI Parse Error: {e}")
                    continue
        else:
            print("QuakeAPI: Invalid data format or empty response")
            
        print(f"QuakeAPI: Found {len(events)} events for {country_code}")
        return events
