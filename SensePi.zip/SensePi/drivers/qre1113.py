from machine import Pin, ADC

class QRE1113:
    """
    QRE1113 Reflective Object Sensor Driver
    """
    def __init__(self, pin_num, is_analog=False, inverted=False):
        self.is_analog = is_analog
        self.inverted = inverted
        if self.is_analog:
            self.sensor = ADC(Pin(pin_num))
        else:
            self.sensor = Pin(pin_num, Pin.IN)
        
        self.threshold = 30000 if self.is_analog else 1 # Hand must be much closer (lower value)
        self.last_state = False

    def read(self):
        """Returns True if object (hand) is detected, False otherwise."""
        if self.is_analog:
            val = self.sensor.read_u16()
            # If inverted, lower value means NO reflection
            return val < self.threshold if not self.inverted else val > self.threshold
        else:
            # Digital reading
            val = self.sensor.value()
            # If not inverted: 1 = Detected, 0 = Not Detected
            # If inverted:     0 = Detected, 1 = Not Detected
            if self.inverted:
                return val == 0
            else:
                return val == 1

    def get_value(self):
        return self.sensor.read_u16() if self.is_analog else self.sensor.value()
