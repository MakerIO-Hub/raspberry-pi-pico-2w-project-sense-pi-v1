import time
import gc

class QuakeEvent:
    def __init__(self, magnitude, location, depth, timestamp, lat, lon, country_code="GL"):
        self.magnitude = float(magnitude)
        self.location = self._clean_location(location)
        self.depth = float(depth)
        self.timestamp = int(timestamp)
        self.lat = float(lat)
        self.lon = float(lon)
        self.country_code = country_code
        self.time_str = self._format_time(timestamp)

    def _clean_location(self, loc):
        if isinstance(loc, str):
            # Clean up common text issues if any
            return loc.strip()
        return "Unknown"

    def _format_time(self, timestamp):
        # Local time conversion handled in UI usually, but keeping this helper
        t = time.localtime(timestamp)
        return "{:02d}:{:02d}".format(t[3], t[4])

class QuakeAPI:
    def __init__(self, wifi_manager):
        self.wifi = wifi_manager
        self.api_url = "https://earthquake.usgs.gov/fdsnws/event/1/query" 
        print("DEBUG: QuakeAPI Initialized (Optimized - Limit 10)")

    def get_quakes(self, country_code="GL", limit=10):
        gc.collect()
        
        # Force limit to 10 as requested by user, ignore argument if higher
        actual_limit = 10
        
        # Construct dynamic URL 
        # format=geojson, limit=10, minmag=2.5, orderby=time
        url = f"{self.api_url}?format=geojson&limit={actual_limit}&minmagnitude=2.5&orderby=time"
        
        print(f"QuakeAPI: Fetching data... (Limit: {actual_limit})")
        
        # Explicit GC before request
        gc.collect()
        
        # Use http_get from wifi_manager which handles JSON parsing
        data = self.wifi.http_get(url, timeout=15)
        
        events = []
        if data:
            if isinstance(data, dict):
                # JSON parsed successfully
                if "features" in data:
                    features = data["features"]
                    print(f"DEBUG: Features received: {len(features)}")
                    
                    for item in features:
                        try:
                            props = item["properties"]
                            geometry = item["geometry"]
                            coords = geometry["coordinates"] # [lon, lat, depth]
                            
                            # Extract data
                            place = props.get("place", "Unknown")
                            mag = props.get("mag", 0)
                            ts_ms = props.get("time", 0)
                            ts = int(ts_ms / 1000)
                            
                            depth = coords[2]
                            lon = coords[0]
                            lat = coords[1]
                            
                            # Create Event Object
                            events.append(QuakeEvent(
                                magnitude=mag,
                                location=place,
                                depth=depth,
                                timestamp=ts,
                                lat=lat,
                                lon=lon,
                                country_code="GL"
                            ))
                        except Exception as e:
                            print(f"QuakeAPI Parse Item Error: {e}")
                            continue
                else:
                    print("QuakeAPI: JSON valid but no 'features' key.")
            else:
                print("QuakeAPI: Response is not a dict")
        else:
            print("QuakeAPI: No data returned")
                    
        return events
