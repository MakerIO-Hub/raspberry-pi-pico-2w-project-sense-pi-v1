"""
Timezone Detector for SensePi
Automatically detects timezone based on IP address geolocation
"""

class TimezoneDetector:
    def __init__(self, wifi_manager):
        self.wifi_manager = wifi_manager
        # IP-based geolocation API (free, no key required)
        self.api_url = "http://ip-api.com/json/"
        
        # Timezone offset mapping (UTC offset in seconds)
        self.timezone_offsets = {
            "Europe/Istanbul": 3 * 3600,
            "America/New_York": -5 * 3600,
            "America/Los_Angeles": -8 * 3600,
            "Europe/London": 0,
            "Europe/Paris": 1 * 3600,
            "Asia/Tokyo": 9 * 3600,
            "Asia/Dubai": 4 * 3600,
            "Australia/Sydney": 11 * 3600,
            "Asia/Shanghai": 8 * 3600,
            "UTC": 0
        }
        
    def detect(self):
        """
        Detect timezone, country, and city from IP address
        
        Returns:
            dict: {
                "timezone": "Europe/Istanbul",
                "country": "Turkey",
                "city": "Istanbul",
                "offset": 10800,  # seconds
                "country_code": "TR"
            }
            or None on error
        """
        if not self.wifi_manager.is_connected():
            print("Timezone: WiFi bağlantısı yok!")
            return None
            
        try:
            data = self.wifi_manager.http_get(self.api_url)
            
            if data and data.get("status") == "success":
                timezone = data.get("timezone", "UTC")
                country = data.get("country", "Unknown")
                city = data.get("city", "Unknown")
                country_code = data.get("countryCode", "??")
                
                # Get timezone offset
                offset = self.get_offset(timezone)
                
                result = {
                    "timezone": timezone,
                    "country": country,
                    "city": city,
                    "offset": offset,
                    "country_code": country_code
                }
                
                print(f"Timezone: {timezone} ({country}, {city}) UTC{offset//3600:+d}")
                return result
            else:
                print("Timezone: API hatası")
                return None
                
        except Exception as e:
            print(f"Timezone detection hatası: {e}")
            return None
            
    def get_offset(self, timezone_name):
        """
        Get UTC offset for a timezone
        
        Args:
            timezone_name: e.g., "Europe/Istanbul"
            
        Returns:
            int: Offset in seconds
        """
        return self.timezone_offsets.get(timezone_name, 0)
        
    def add_timezone(self, name, offset_hours):
        """
        Add custom timezone
        
        Args:
            name: Timezone name
            offset_hours: UTC offset in hours (e.g., 3 for UTC+3)
        """
        self.timezone_offsets[name] = offset_hours * 3600
        print(f"Timezone eklendi: {name} (UTC{offset_hours:+d})")
