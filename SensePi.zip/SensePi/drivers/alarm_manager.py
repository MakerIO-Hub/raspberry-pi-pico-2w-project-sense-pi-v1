import ujson
import time

class AlarmManager:
    def __init__(self, rtc_driver, buzzer_driver):
        self.rtc = rtc_driver
        self.buzzer = buzzer_driver
        self.alarms_file = "data/alarms.json"
        
        # Dynamic alarm list (0-3 alarms)
        self.alarms = []
        self.next_id = 1000  # Starting ID for new alarms
        
        self.load_alarms()
        self.triggered_alarm = None
        self.last_check = 0
        
    def load_alarms(self):
        """Load alarms from file"""
        try:
            with open(self.alarms_file, "r") as f:
                data = ujson.load(f)
                self.alarms = data.get("alarms", [])
                self.next_id = data.get("next_id", 1000)
            print(f"AlarmManager: {len(self.alarms)} alarms loaded")
        except:
            print("AlarmManager: No saved alarms, starting fresh")
            self.save_alarms()
            
    def save_alarms(self):
        """Save alarms to file"""
        try:
            data = {
                "alarms": self.alarms,
                "next_id": self.next_id
            }
            with open(self.alarms_file, "w") as f:
                ujson.dump(data, f)
            print("AlarmManager: Alarms saved")
        except Exception as e:
            print(f"AlarmManager: Save error: {e}")
            
    def get_alarms(self):
        """Get all alarms"""
        return self.alarms
        
    def get_alarm_count(self):
        """Get number of alarms"""
        return len(self.alarms)
        
    def get_alarm_by_id(self, alarm_id):
        """Get alarm by ID"""
        for alarm in self.alarms:
            if alarm["id"] == alarm_id:
                return alarm
        return None
        
    def add_alarm(self, hour, minute):
        """Add a new alarm, returns alarm ID or None if limit reached"""
        if len(self.alarms) >= 3:
            print("AlarmManager: Alarm limit reached (max 3)")
            return None
            
        new_alarm = {
            "id": self.next_id,
            "hour": hour,
            "minute": minute,
            "enabled": True  # New alarms are enabled by default
        }
        
        self.alarms.append(new_alarm)
        self.next_id += 1
        self.save_alarms()
        
        print(f"AlarmManager: Added alarm {new_alarm['id']} at {hour:02d}:{minute:02d}")
        return new_alarm["id"]
        
    def delete_alarm(self, alarm_id):
        """Delete alarm by ID"""
        for i, alarm in enumerate(self.alarms):
            if alarm["id"] == alarm_id:
                deleted = self.alarms.pop(i)
                self.save_alarms()
                print(f"AlarmManager: Deleted alarm {alarm_id}")
                return True
        
        print(f"AlarmManager: Alarm {alarm_id} not found")
        return False
        
    def update_alarm(self, alarm_id, hour, minute):
        """Update alarm time"""
        alarm = self.get_alarm_by_id(alarm_id)
        if alarm:
            alarm["hour"] = hour
            alarm["minute"] = minute
            self.save_alarms()
            print(f"AlarmManager: Updated alarm {alarm_id} to {hour:02d}:{minute:02d}")
            return True
        return False
        
    def toggle_alarm(self, alarm_id):
        """Toggle alarm enabled state"""
        alarm = self.get_alarm_by_id(alarm_id)
        if alarm:
            alarm["enabled"] = not alarm["enabled"]
            self.save_alarms()
            return alarm["enabled"]
        return None
        
    def check_alarms(self):
        """Check if any alarm should trigger (call this every second)"""
        # Limit check frequency to once per second
        now = time.time()
        if now - self.last_check < 1:
            return None
            
        self.last_check = now
        
        # Get current time
        t = self.rtc.get_time()
        curr_h = t["hour"]
        curr_m = t["minute"]
        curr_s = t["second"]
        
        # Check only at 00 seconds to trigger once per minute
        if curr_s != 0:
            return None
            
        for alarm in self.alarms:
            if alarm["enabled"]:
                if alarm["hour"] == curr_h and alarm["minute"] == curr_m:
                    print(f"ALARM TRIGGERED: ID {alarm['id']} at {curr_h:02d}:{curr_m:02d}")
                    self.triggered_alarm = alarm
                    return alarm
                    
        return None
