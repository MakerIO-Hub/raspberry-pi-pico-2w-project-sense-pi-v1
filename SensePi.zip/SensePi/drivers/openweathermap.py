"""
OpenWeatherMap API Client for SensePi
Premium weather data with API key
https://openweathermap.org/api
"""

class OpenWeatherMapClient:
    def __init__(self, wifi_manager, api_key):
        self.wifi_manager = wifi_manager
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5"
        
        # Weather condition codes to description
        self.weather_descriptions = {
            # Thunderstorm
            200: "Thunderstorm with light rain",
            201: "Thunderstorm with rain",
            202: "Thunderstorm with heavy rain",
            210: "Light thunderstorm",
            211: "Thunderstorm",
            212: "Heavy thunderstorm",
            221: "Ragged thunderstorm",
            230: "Thunderstorm with light drizzle",
            231: "Thunderstorm with drizzle",
            232: "Thunderstorm with heavy drizzle",
            # Drizzle
            300: "Light drizzle",
            301: "Drizzle",
            302: "Heavy drizzle",
            310: "Light drizzle rain",
            311: "Drizzle rain",
            312: "Heavy drizzle rain",
            313: "Shower rain and drizzle",
            314: "Heavy shower rain and drizzle",
            321: "Shower drizzle",
            # Rain
            500: "Light rain",
            501: "Moderate rain",
            502: "Heavy rain",
            503: "Very heavy rain",
            504: "Extreme rain",
            511: "Freezing rain",
            520: "Light shower rain",
            521: "Shower rain",
            522: "Heavy shower rain",
            531: "Ragged shower rain",
            # Snow
            600: "Light snow",
            601: "Snow",
            602: "Heavy snow",
            611: "Sleet",
            612: "Light shower sleet",
            613: "Shower sleet",
            615: "Light rain and snow",
            616: "Rain and snow",
            620: "Light shower snow",
            621: "Shower snow",
            622: "Heavy shower snow",
            # Atmosphere
            701: "Mist",
            711: "Smoke",
            721: "Haze",
            731: "Sand/dust whirls",
            741: "Fog",
            751: "Sand",
            761: "Dust",
            762: "Volcanic ash",
            771: "Squalls",
            781: "Tornado",
            # Clear
            800: "Clear sky",
            # Clouds
            801: "Few clouds",
            802: "Scattered clouds",
            803: "Broken clouds",
            804: "Overcast clouds"
        }
        
        # Weather code to icon mapping
        self.code_to_icon = {
            # Thunderstorm (2xx)
            200: "weather_thunder.bin", 201: "weather_thunder.bin", 202: "weather_thunder.bin",
            210: "weather_thunder.bin", 211: "weather_thunder.bin", 212: "weather_thunder.bin",
            221: "weather_thunder.bin", 230: "weather_thunder.bin", 231: "weather_thunder.bin",
            232: "weather_thunder.bin",
            # Drizzle (3xx)
            300: "weather_rain.bin", 301: "weather_rain.bin", 302: "weather_rain.bin",
            310: "weather_rain.bin", 311: "weather_rain.bin", 312: "weather_rain.bin",
            313: "weather_rain.bin", 314: "weather_rain.bin", 321: "weather_rain.bin",
            # Rain (5xx)
            500: "weather_rain.bin", 501: "weather_rain.bin", 502: "weather_rain.bin",
            503: "weather_rain.bin", 504: "weather_rain.bin", 511: "weather_rain.bin",
            520: "weather_rain.bin", 521: "weather_rain.bin", 522: "weather_rain.bin",
            531: "weather_rain.bin",
            # Snow (6xx)
            600: "weather_snow.bin", 601: "weather_snow.bin", 602: "weather_snow.bin",
            611: "weather_snow.bin", 612: "weather_snow.bin", 613: "weather_snow.bin",
            615: "weather_snow.bin", 616: "weather_snow.bin", 620: "weather_snow.bin",
            621: "weather_snow.bin", 622: "weather_snow.bin",
            # Atmosphere (7xx)
            701: "weather_fog.bin", 711: "weather_fog.bin", 721: "weather_fog.bin",
            731: "weather_fog.bin", 741: "weather_fog.bin", 751: "weather_fog.bin",
            761: "weather_fog.bin", 762: "weather_fog.bin", 771: "weather_fog.bin",
            781: "weather_thunder.bin",
            # Clear (800)
            800: "weather_clear.bin",
            # Clouds (80x)
            801: "weather_partly_cloudy.bin", 802: "weather_partly_cloudy.bin",
            803: "weather_cloudy.bin", 804: "weather_cloudy.bin"
        }
        
    def get_weather_description(self, weather_code):
        """Get weather description from code"""
        return self.weather_descriptions.get(weather_code, "Unknown")
        
    def get_weather_icon(self, weather_code):
        """Get weather icon filename from code"""
        return self.code_to_icon.get(weather_code, "weather_clear.bin")
        
    def get_current_weather(self, lat, lon):
        """
        Get current weather for location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            dict: {
                "temperature": 28.5,
                "weather_code": 800,
                "wind_speed": 12.5,
                "wind_direction": 180,
                "humidity": 65,
                "pressure": 1013
            }
            or None on error
        """
        if not self.wifi_manager.is_connected():
            print("OpenWeatherMap: WiFi bağlantısı yok!")
            return None
            
        try:
            # Build URL
            url = f"{self.base_url}/weather?lat={lat}&lon={lon}&appid={self.api_key}&units=metric"
            
            print(f"OpenWeatherMap: Current weather isteği... (lat={lat}, lon={lon})")
            data = self.wifi_manager.http_get(url, timeout=10)
            
            if data:
                # Extract weather data
                result = {
                    "temperature": data["main"]["temp"],
                    "weather_code": data["weather"][0]["id"],
                    "wind_speed": data["wind"]["speed"] * 3.6,  # m/s to km/h
                    "wind_direction": data["wind"].get("direction", 0),
                    "humidity": data["main"]["humidity"],
                    "pressure": data["main"]["pressure"],
                    "time": ""
                }
                
                print(f"OpenWeatherMap: Current weather alındı - {result['temperature']}°C")
                return result
            else:
                print("OpenWeatherMap: Current weather verisi bulunamadı")
                return None
                
        except Exception as e:
            print(f"OpenWeatherMap: Current weather hatası - {e}")
            return None
            
    def get_daily_forecast(self, lat, lon, days=7):
        """
        Get daily weather forecast
        
        Args:
            lat: Latitude
            lon: Longitude
            days: Number of forecast days (max 5 for free tier, 8 for paid)
            
        Returns:
            list: [
                {
                    "date": "2026-02-09",
                    "temp_max": 30,
                    "temp_min": 18,
                    "weather_code": 800
                },
                ...
            ]
            or None on error
        """
        if not self.wifi_manager.is_connected():
            print("OpenWeatherMap: WiFi bağlantısı yok!")
            return None
            
        # Free tier only supports 5-day forecast
        # For 7-8 days, we'll use 5-day/3-hour forecast and extract daily data
        days = min(days, 5)
            
        try:
            # Use 5-day/3-hour forecast (free tier)
            url = f"{self.base_url}/forecast?lat={lat}&lon={lon}&appid={self.api_key}&units=metric"
            
            print(f"OpenWeatherMap: {days}-day forecast isteği...")
            data = self.wifi_manager.http_get(url, timeout=10)
            
            if data and "list" in data:
                # Group by date and find min/max
                daily_data = {}
                
                for item in data["list"]:
                    # Date format: "2026-02-09 12:00:00"
                    date = item["dt_txt"].split(" ")[0]
                    
                    if date not in daily_data:
                        daily_data[date] = {
                            "date": date,
                            "temp_max": item["main"]["temp_max"],
                            "temp_min": item["main"]["temp_min"],
                            "weather_code": item["weather"][0]["id"]
                        }
                    else:
                        # Update max/min
                        daily_data[date]["temp_max"] = max(daily_data[date]["temp_max"], item["main"]["temp_max"])
                        daily_data[date]["temp_min"] = min(daily_data[date]["temp_min"], item["main"]["temp_min"])
                        
                # Convert to list
                result = list(daily_data.values())[:days]
                
                print(f"OpenWeatherMap: {len(result)}-day forecast alındı")
                return result
            else:
                print("OpenWeatherMap: Daily forecast verisi bulunamadı")
                return None
                
        except Exception as e:
            print(f"OpenWeatherMap: Daily forecast hatası - {e}")
            return None
