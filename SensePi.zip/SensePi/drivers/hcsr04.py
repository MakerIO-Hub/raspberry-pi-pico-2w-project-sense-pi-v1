import machine
import time

class HCSR04:
    """
    Driver for HC-SR04 Ultrasonic Distance Sensor.
    """
    def __init__(self, trigger_pin, echo_pin, echo_timeout_us=30000):
        """
        trigger_pin: Output pin to trigger sensor
        echo_pin: Input pin to read echo
        echo_timeout_us: Timeout in microseconds (30ms = ~5m max range)
        """
        self.trigger = machine.Pin(trigger_pin, machine.Pin.OUT)
        self.trigger.value(0)
        self.echo = machine.Pin(echo_pin, machine.Pin.IN)
        self.echo_timeout_us = echo_timeout_us

    def measure_cm(self):
        """
        Trigger a measurement and return distance in cm.
        Returns -1 if timeout or error.
        """
        # Trigger pulse (10us)
        self.trigger.value(0)
        time.sleep_us(2)
        self.trigger.value(1)
        time.sleep_us(10)
        self.trigger.value(0)
        
        # Wait for echo to go high (start of travel)
        try:
            pulse_time = machine.time_pulse_us(self.echo, 1, self.echo_timeout_us)
            
            if pulse_time < 0:
                return -1 # Timeout
            
            # Calculate distance
            # Sound speed at sea level = 343 m/s
            # cm = (pulse_time / 2) * 0.0343
            dist_cm = (pulse_time / 2) / 29.1
            return dist_cm
            
        except OSError as e:
            return -1

    def deinit(self):
        self.trigger.value(0)
