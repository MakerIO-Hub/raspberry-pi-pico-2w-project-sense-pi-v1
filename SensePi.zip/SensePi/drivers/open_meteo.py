"""
Open-Meteo API Client for SensePi
Free weather API - no API key required
https://open-meteo.com/en/docs
"""

class OpenMeteoClient:
    def __init__(self, wifi_manager):
        self.wifi_manager = wifi_manager
        self.base_url = "https://api.open-meteo.com/v1/forecast"
        
        # WMO Weather Code to description mapping
        self.wmo_codes = {
            0: "Clear sky",
            1: "Mainly clear",
            2: "Partly cloudy",
            3: "Overcast",
            45: "Fog",
            48: "Depositing rime fog",
            51: "Light drizzle",
            53: "Moderate drizzle",
            55: "Dense drizzle",
            61: "Slight rain",
            63: "Moderate rain",
            65: "Heavy rain",
            71: "Slight snow",
            73: "Moderate snow",
            75: "Heavy snow",
            77: "Snow grains",
            80: "Slight rain showers",
            81: "Moderate rain showers",
            82: "Violent rain showers",
            85: "Slight snow showers",
            86: "Heavy snow showers",
            95: "Thunderstorm",
            96: "Thunderstorm with slight hail",
            99: "Thunderstorm with heavy hail"
        }
        
        # WMO Code to icon filename mapping
        self.wmo_to_icon = {
            0: "weather_clear.bin",
            1: "weather_clear.bin",
            2: "weather_partly_cloudy.bin",
            3: "weather_cloudy.bin",
            45: "weather_fog.bin",
            48: "weather_fog.bin",
            51: "weather_rain.bin",
            53: "weather_rain.bin",
            55: "weather_rain.bin",
            61: "weather_rain.bin",
            63: "weather_rain.bin",
            65: "weather_rain.bin",
            71: "weather_snow.bin",
            73: "weather_snow.bin",
            75: "weather_snow.bin",
            77: "weather_snow.bin",
            80: "weather_rain.bin",
            81: "weather_rain.bin",
            82: "weather_rain.bin",
            85: "weather_snow.bin",
            86: "weather_snow.bin",
            95: "weather_thunder.bin",
            96: "weather_thunder.bin",
            99: "weather_thunder.bin"
        }
        
    def get_weather_description(self, wmo_code):
        """Get weather description from WMO code"""
        return self.wmo_codes.get(wmo_code, "Unknown")
        
    def get_weather_icon(self, wmo_code):
        """Get weather icon filename from WMO code"""
        return self.wmo_to_icon.get(wmo_code, "weather_clear.bin")
        
    def get_current_weather(self, lat, lon):
        """
        Get current weather for location including humidity and pressure
        """
        if not self.wifi_manager.is_connected():
            print("OpenMeteo: WiFi bağlantısı yok!")
            return None
            
        try:
            # Build URL with current weather parameters (Newer API format)
            # Fetch temp, humidity, pressure, wind, code
            url = f"{self.base_url}?latitude={lat}&longitude={lon}"
            url += "&current=temperature_2m,relative_humidity_2m,surface_pressure,wind_speed_10m,weather_code"
            url += "&timezone=auto"
            
            print(f"OpenMeteo: Current weather isteği... (lat={lat}, lon={lon})")
            data = self.wifi_manager.http_get(url, timeout=10)
            
            if data and "current" in data:
                current = data["current"]
                
                result = {
                    "temperature": current.get("temperature_2m", 0),
                    "weather_code": current.get("weather_code", 0),
                    "wind_speed": current.get("wind_speed_10m", 0),
                    "wind_direction": 0, # Not fetched to save bandwidth/url length
                    "humidity": current.get("relative_humidity_2m", 0),
                    "pressure": current.get("surface_pressure", 0),
                    "time": current.get("time", "")
                }
                
                print(f"OpenMeteo: Current weather alındı - {result['temperature']}°C")
                return result
            else:
                print("OpenMeteo: Current weather verisi bulunamadı")
                return None
                
        except Exception as e:
            print(f"OpenMeteo: Current weather hatası - {e}")
            return None
            
    def get_daily_forecast(self, lat, lon, days=7):
        """
        Get daily weather forecast
        
        Args:
            lat: Latitude
            lon: Longitude
            days: Number of forecast days (1-16)
            
        Returns:
            list: [
                {
                    "date": "2026-02-09",
                    "temp_max": 30,
                    "temp_min": 18,
                    "weather_code": 0
                },
                ...
            ]
            or None on error
        """
        if not self.wifi_manager.is_connected():
            print("OpenMeteo: WiFi bağlantısı yok!")
            return None
            
        if days < 1 or days > 16:
            days = 7
            
        try:
            # Build URL with daily forecast parameters
            url = f"{self.base_url}?latitude={lat}&longitude={lon}"
            # Added precipitation_probability_max
            url += "&daily=temperature_2m_max,temperature_2m_min,weathercode,precipitation_probability_max"
            url += f"&forecast_days={days}"
            url += "&timezone=auto"
            
            print(f"OpenMeteo: {days}-day forecast isteği...")
            data = self.wifi_manager.http_get(url, timeout=10)
            
            if data and "daily" in data:
                daily = data["daily"]
                dates = daily.get("time", [])
                temp_max = daily.get("temperature_2m_max", [])
                temp_min = daily.get("temperature_2m_min", [])
                # Restore missing variable
                weather_codes = daily.get("weathercode", [])
                
                # Get rain probs - specific check with default
                precip_probs = daily.get("precipitation_probability_max", [])
                # Ensure it's a list
                if not isinstance(precip_probs, list):
                    precip_probs = []
                
                result = []
                for i in range(min(len(dates), days)):
                    # Safe access for precip_prob
                    p_prob = 0
                    if i < len(precip_probs) and precip_probs[i] is not None:
                        p_prob = precip_probs[i]
                        
                    result.append({
                        "date": dates[i],
                        "temp_max": temp_max[i] if i < len(temp_max) else 0,
                        "temp_min": temp_min[i] if i < len(temp_min) else 0,
                        "weather_code": weather_codes[i] if i < len(weather_codes) else 0,
                        "precip_prob": p_prob
                    })
                    
                print(f"OpenMeteo: {len(result)}-day forecast alındı")
                return result
            else:
                print("OpenMeteo: Daily forecast verisi bulunamadı")
                return None
                
        except Exception as e:
            print(f"OpenMeteo: Daily forecast hatası - {e}")
            return None
            
    def get_hourly_forecast(self, lat, lon, hours=24):
        """
        Get hourly weather forecast (optional - for future use)
        
        Args:
            lat: Latitude
            lon: Longitude
            hours: Number of forecast hours (max 168 = 7 days)
            
        Returns:
            list of hourly data or None on error
        """
        if not self.wifi_manager.is_connected():
            print("OpenMeteo: WiFi bağlantısı yok!")
            return None
            
        try:
            url = f"{self.base_url}?latitude={lat}&longitude={lon}"
            url += "&hourly=temperature_2m,weathercode,relativehumidity_2m"
            url += "&timezone=auto"
            
            print(f"OpenMeteo: Hourly forecast isteği...")
            data = self.wifi_manager.http_get(url, timeout=10)
            
            if data and "hourly" in data:
                hourly = data["hourly"]
                times = hourly.get("time", [])
                temps = hourly.get("temperature_2m", [])
                codes = hourly.get("weathercode", [])
                humidity = hourly.get("relativehumidity_2m", [])
                
                result = []
                for i in range(min(len(times), hours)):
                    result.append({
                        "time": times[i],
                        "temperature": temps[i] if i < len(temps) else 0,
                        "weather_code": codes[i] if i < len(codes) else 0,
                        "humidity": humidity[i] if i < len(humidity) else 0
                    })
                    
                print(f"OpenMeteo: {len(result)}-hour forecast alındı")
                return result
            else:
                print("OpenMeteo: Hourly forecast verisi bulunamadı")
                return None
                
        except Exception as e:
            print(f"OpenMeteo: Hourly forecast hatası - {e}")
            return None
