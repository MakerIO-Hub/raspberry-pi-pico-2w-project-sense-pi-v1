"""
NTP Manager for SensePi
Synchronizes time from NTP servers (pool.ntp.org)
"""

import socket
import struct
import time

class NTPManager:
    def __init__(self, wifi_manager, ntp_server="pool.ntp.org"):
        self.wifi_manager = wifi_manager
        self.ntp_server = ntp_server
        self.ntp_delta = 2208988800  # Offset between 1900-1970
        
    def get_time(self, timezone_offset=0):
        """
        Get current time from NTP server
        
        Args:
            timezone_offset: Offset in seconds (e.g., Turkey: 3*3600 = 10800)
            
        Returns:
            dict: {"year": int, "month": int, "day": int, "hour": int, "minute": int, "second": int, "weekday": int}
            or None on error
        """
        if not self.wifi_manager.is_connected():
            print("NTP: WiFi bağlantısı yok!")
            return None
            
        try:
            print(f"NTP: Saat alınıyor -> {self.ntp_server}")
            
            # NTP query
            ntp_query = bytearray(48)
            ntp_query[0] = 0x1B  # NTP version 3, mode 3
            
            addr = socket.getaddrinfo(self.ntp_server, 123)[0][-1]
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(3)
            
            s.sendto(ntp_query, addr)
            msg = s.recv(48)
            s.close()
            
            # Parse NTP response
            val = struct.unpack("!I", msg[40:44])[0]
            ntp_time = val - self.ntp_delta
            
            # Apply timezone offset
            ntp_time += timezone_offset
            
            # Convert to readable format
            timestamp = time.gmtime(ntp_time)
            
            result = {
                "year": timestamp[0],
                "month": timestamp[1],
                "day": timestamp[2],
                "hour": timestamp[3],
                "minute": timestamp[4],
                "second": timestamp[5],
                "weekday": timestamp[6]
            }
            
            print(f"NTP: Saat alındı -> {result['year']}-{result['month']:02d}-{result['day']:02d} {result['hour']:02d}:{result['minute']:02d}:{result['second']:02d}")
            return result
            
        except Exception as e:
            print(f"NTP hatası: {e}")
            return None
            
    def sync_rtc(self, rtc_driver, timezone_offset=0):
        """
        Sync RTC from NTP
        
        Args:
            rtc_driver: RTCDriver instance
            timezone_offset: Timezone offset in seconds
            
        Returns:
            bool: True if successful
        """
        ntp_time = self.get_time(timezone_offset)
        if ntp_time:
            rtc_driver.sync_from_ntp(ntp_time)
            return True
        return False
