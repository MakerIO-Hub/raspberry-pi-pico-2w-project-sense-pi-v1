import os

class Dashboard:
    def __init__(self, lcd):
        self.lcd = lcd
        self.selected_index = 0 # 0-8 arası (9 modül)
        self.modules = [
            {"name": "Clock", "color": 0x039F, "icon": "icons/clock.bin"},      # Parlak Mavi
            {"name": "Date", "color": 0xF81F, "icon": "icons/date.bin"},        # Magenta
            {"name": "Alarm", "color": 0xF800, "icon": "icons/alarm.bin"},      # Kırmızı
            {"name": "Weather", "color": 0xCF9F, "icon": "icons/weather.bin"},  # Beyaz-Mavi (Bulut)
            {"name": "Currency", "color": 0xFE60, "icon": "icons/currency.bin"},# Altın
            {"name": "Quake", "color": 0xA81F, "icon": "icons/quake.bin"},      # Elektrik Mor
            {"name": "Sensors", "color": 0x07E0, "icon": "icons/sensors.bin"},  # Yeşil
            {"name": "Calendar", "color": 0x8010, "icon": "icons/calendar.bin"},# Mor
            {"name": "Settings", "color": 0x39E7, "icon": "icons/settings.bin"} # Koyu Gri
        ]
        
        # Grid Ayarları
        self.cols = 3
        self.rows = 3
        self.cell_width = 320 // self.cols
        self.cell_height = 240 // self.rows
        
    def draw_grid(self):
        # Arka plan temizle (Turuncu 0xdd22)
        self.lcd.fill(0xdd22)
        
        for i, mod in enumerate(self.modules):
            self.draw_cell(i)
            
        self.lcd.show()

    def draw_cell(self, index):
        # Satır ve Sütun hesapla
        row = index // self.cols
        col = index % self.cols
        
        x = col * self.cell_width
        y = row * self.cell_height
        
        # Koordinatları biraz ortalayalım
        center_x = x + (self.cell_width // 2)
        center_y = y + (self.cell_height // 2)
        
        # Seçili ise Vurgula
        is_selected = (index == self.selected_index)
        
        if is_selected:
            # Seçili kutu çerçevesi - Modülün kendi renginde
            color = self.modules[index]["color"]
            self.lcd.rect(x+2, y+2, self.cell_width-4, self.cell_height-4, color)
            self.lcd.rect(x+3, y+3, self.cell_width-6, self.cell_height-6, color)
        else:
            # Seçili değilse temizle (Turuncu 0xdd22 ile kapat)
            self.lcd.rect(x+2, y+2, self.cell_width-4, self.cell_height-4, 0xdd22)
            self.lcd.rect(x+3, y+3, self.cell_width-6, self.cell_height-6, 0xdd22)

        # ICON CIZIMI (50x50 piksel)
        icon_path = self.modules[index]["icon"]
        # Ikonu cizmeye calis, basarisiz olursa (dosya yoksa) placeholder ciz
        if not self.draw_bitmap(icon_path, center_x - 25, center_y - 30):
            # Placeholder Daire (Dosya yoksa) - 50x50
            self.lcd.fill_rect(center_x - 25, center_y - 30, 50, 50, self.modules[index]["color"])
        
        # Metin (Yazı aşağı kaydırıldı)
        text = self.modules[index]["name"]
        text_w = len(text) * 8
        self.lcd.text(text, center_x - (text_w // 2), center_y + 25, 0xFFFF if is_selected else 0x0000)

    def draw_bitmap(self, filename, x, y):
        try:
            stat = os.stat(filename)
        except OSError:
            return False # Dosya yok
            
        filesize = stat[6]
        side = int((filesize / 2) ** 0.5) # Kare varsayimi
        
        # Basit kirpma (Ekrandan tasiyorsa cizme)
        if x < 0 or y < 0 or x+side > 320 or y+side > 240:
            # Yine de cizmeye calisabiliriz ama simdilik guvenli olsun
            pass

        screen_width = 320
        
        try:
            with open(filename, "rb") as f:
                for row in range(side):
                    screen_y = y + row
                    if screen_y >= 240: break
                    
                    start_index = ((screen_y * screen_width) + x) * 2
                    row_data = f.read(side * 2)
                    if not row_data: break
                    
                    end_index = start_index + len(row_data)
                    if end_index <= len(self.lcd.buffer):
                        self.lcd.buffer[start_index : end_index] = row_data
            return True
        except:
            return False

    def move_selection(self, direction):
        # direction: +1 (İleri), -1 (Geri)
        prev_index = self.selected_index
        self.selected_index = (self.selected_index + direction) % len(self.modules)
        
        # Sadece değişen hücreleri yeniden çiz (Performans)
        self.draw_cell(prev_index)       # Eskiyi 'unselect' çiz
        self.draw_cell(self.selected_index) # Yeniyi 'select' çiz
        self.lcd.show()
        
    def get_selected_module(self):
        return self.modules[self.selected_index]

    def get_module_index_at(self, x, y):
        # Dokunulan koordinatin hangi hucrede oldugunu bul
        if x < 0 or x >= 320 or y < 0 or y >= 240:
            return None
            
        col = x // self.cell_width
        row = y // self.cell_height
        
        index = (row * self.cols) + col
        
        if 0 <= index < len(self.modules):
            return index
        return None
