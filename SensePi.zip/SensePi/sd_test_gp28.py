
import machine
import os
import time

# --- GÖMÜLÜ SDCARD SÜRÜCÜSÜ (Tam ve Eksiksiz) ---
# Bu kisim drivers/sdcard.py'den alinmistir.
class SDCard:
    def __init__(self, spi, cs, baudrate=1320000):
        self.spi = spi
        self.cs = cs

        self.cmdbuf = bytearray(6)
        self.dummybuf = bytearray(512)
        self.tokenbuf = bytearray(1)
        for i in range(512):
            self.dummybuf[i] = 0xFF
        self.dummybuf_v = memoryview(self.dummybuf)

        self.init_card(baudrate)

    def init_card(self, baudrate):
        self.cs.init(machine.Pin.OUT, value=1)
        self.spi.init(baudrate=100000)
        # clock card at least 100 cycles with cs high
        for i in range(16):
            self.spi.write(b"\xff")

        # CMD0: go idle state
        if self.cmd(0, 0, 0x95) != 1:
            time.sleep_ms(100)
            if self.cmd(0, 0, 0x95) != 1:
                raise OSError("no SD card")

        # CMD8: confirm voltage range
        r = self.cmd(8, 0x01AA, 0x87, 4)
        if r == 1:
            self.init_card_v2()
        else:
            self.init_card_v1()

        # fast speed
        self.spi.init(baudrate=baudrate)

    def init_card_v1(self):
        for i in range(100):
            self.cmd(55, 0, 0)
            if self.cmd(41, 0, 0) == 0:
                self.cdv = 512
                # print("[SDCard] Init V1 OK")
                return
        raise OSError("timeout waiting for v1 card")

    def init_card_v2(self):
        for i in range(100):
            time.sleep_ms(50)
            self.cmd(55, 0, 0)
            if self.cmd(41, 0x40000000, 0) == 0:
                self.cmd(58, 0, 0, 4)
                if (self.tokenbuf[0] & 0x40):
                    self.cdv = 1
                    print("[SDCard] Init V2 (Block Access) OK")
                else:
                    self.cdv = 512
                    print("[SDCard] Init V2 (Byte Access) OK")
                return
        raise OSError("timeout waiting for v2 card")

    def cmd(self, cmd, arg, crc, final=0, release=True, skip1=False):
        self.cs(0)
        buf = self.cmdbuf
        buf[0] = 0x40 | cmd
        buf[1] = arg >> 24
        buf[2] = arg >> 16
        buf[3] = arg >> 8
        buf[4] = arg
        buf[5] = crc
        self.spi.write(buf)

        if skip1:
            self.spi.readinto(self.tokenbuf, 0xFF)

        for i in range(128):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if not (self.tokenbuf[0] & 0x80):
                break
        else:
            self.cs(1)
            return -1

        res = self.tokenbuf[0]
        if final > 0:
            self.spi.readinto(self.tokenbuf, 0xFF) #(self.spi.read(final, 0xFF)) logic simplified
            # Note: For strict compliance we should read 'final' bytes properly
            # But usually CMD8/58 just check existence.

        if release:
            self.cs(1)
            self.spi.write(b"\xff")
        return res

    def readblocks(self, block_num, buf):
        nblocks = len(buf) // 512
        assert len(buf) % 512 == 0, "Buffer length must be multiple of 512"
        if nblocks == 1:
            if self.cmd(17, block_num * self.cdv, 0) != 0:
                return 1
            if self.read_data(buf):
                return 1
        else:
            if self.cmd(18, block_num * self.cdv, 0) != 0:
                return 1
            offset = 0
            while nblocks > 0:
                if self.read_data(memoryview(buf)[offset : offset + 512]):
                    return 1
                offset += 512
                nblocks -= 1
            if self.cmd(12, 0, 0, skip1=True):
                return 1
        return 0

    def writeblocks(self, block_num, buf):
        nblocks = len(buf) // 512
        assert len(buf) % 512 == 0, "Buffer length must be multiple of 512"
        if nblocks == 1:
            if self.cmd(24, block_num * self.cdv, 0) != 0:
                return 1
            if self.write_data(0xFE, buf):
                return 1
        else:
            if self.cmd(25, block_num * self.cdv, 0) != 0:
                return 1
            offset = 0
            while nblocks > 0:
                if self.write_data(0xFC, memoryview(buf)[offset : offset + 512]):
                    return 1
                offset += 512
                nblocks -= 1
            if self.write_data(0xFD, None):
                return 1
        return 0

    def ioctl(self, op, arg):
        if op == 4:  # get number of blocks
            return 32 * 1024 * 1024 * 1024 // 512 # Approx
        if op == 5:  # get block size
            return 512
            
    def read_data(self, buf):
        self.cs(0)
        for i in range(1000):
            self.spi.readinto(self.tokenbuf, 0xFF)
            if self.tokenbuf[0] == 0xFE:
                break
        else:
            self.cs(1)
            return 1
        self.spi.readinto(buf, 0xFF)
        self.spi.read(2, 0xFF) # CRC
        self.cs(1)
        self.spi.write(b"\xff")
        return 0

    def write_data(self, token, buf):
        self.cs(0)
        self.spi.write(bytearray([token]))
        if buf is not None:
            self.spi.write(buf)
            self.spi.write(b"\xff\xff") # dummy CRC
            self.spi.readinto(self.tokenbuf, 0xFF)
            if (self.tokenbuf[0] & 0x1F) != 0x05:
                self.cs(1)
                return 1
            while True:
                self.spi.readinto(self.tokenbuf, 0xFF)
                if self.tokenbuf[0] != 0:
                    break
        self.cs(1)
        self.spi.write(b"\xff")
        return 0


# --- TEST KODU ---
def run_test():
    PIN_CS_SD = 18
    PIN_CS_LCD = 9
    
    print("=== SD KART TEST BAŞLATILIYOR (Gömülü Sürücü) ===")
    
    # 1. LCD Sustur
    try:
        lcd_cs = machine.Pin(PIN_CS_LCD, machine.Pin.OUT)
        lcd_cs.value(1)
        print(f"LCD CS (GP{PIN_CS_LCD}) High yapıldı.")
    except Exception as e:
        print(f"Uyarı: LCD CS ayarlanamadı: {e}")

    try:
        # 2. SPI Başlat
        # Önemli: Baudrate'i yüksek seçebilirsiniz (40MHz'e kadar destekler ama 10MHz güvenli)
        spi = machine.SPI(1,
                          baudrate=10000, 
                          polarity=0,
                          phase=0,
                          sck=machine.Pin(10),
                          mosi=machine.Pin(11),
                          miso=machine.Pin(12))
        print("SPI Başlatıldı.")
        
        # 3. SD Kart Başlat
        print(f"SD Kart CS Pini: {PIN_CS_SD}")
        sd = SDCard(spi, machine.Pin(PIN_CS_SD))
        print("SD Kart Nesnesi Başarıyla Oluşturuldu!")
        
        # 4. Dosya Sistemi
        vfs = os.VfsFat(sd)
        os.mount(vfs, "/sd")
        print("MOUNT OK: /sd klasörüne bağlandı.")
        
        # 5. Yazma Testi
        fname = "/sd/test_write.txt"
        with open(fname, "w") as f:
            f.write(f"Test Yazisi {time.ticks_ms()}")
        print(f"Dosya Yazildi: {fname}")
        
        with open(fname, "r") as f:
            print("Okunan:", f.read())
            
        print("=== TEST BAŞARILI ===")
        
    except OSError as e:
        print("\n!!! DONANIM HATASI (OSError) !!!")
        print(f"Hata Kodu: {e}")
        print("Anlamı: SD Kart cevap vermedi veya bağlantı kopuk.")
        print("Kontrol Edin:")
        print("1. MISO/MOSI ters mi?")
        print("2. CS pini (28) yerine takili mi?")
        print("3. Kart yuvaya tam oturdu mu?")
        
    except Exception as e:
        print(f"\n!!! HATA: {e}")
        import sys
        sys.print_exception(e)

if __name__ == "__main__":
    run_test()
